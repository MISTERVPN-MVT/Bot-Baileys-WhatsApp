const path = require('path')
require('dotenv').config({ path: path.resolve(__dirname, '../.env') })

function required(value, name) {
  if (!value) throw new Error(`${name} is required in .env`)
  return value
}

function formatBotNumber(number) {
  const digits = (number || '').replace(/\D/g, '')
  if (!digits.startsWith('55')) return digits
  const ddd = digits.slice(2, 4)
  const rest = digits.slice(4)
  if (rest.length === 8) return `55${ddd}9${rest}`
  return digits
}

const config = {
  panelDomain: required(process.env.PANEL_DOMAIN, 'PANEL_DOMAIN'),
  panelToken: required(process.env.PANEL_TOKEN, 'PANEL_TOKEN'),
  adminNumber: required(process.env.ADMIN_NUMBER, 'ADMIN_NUMBER'),
  botNumber: formatBotNumber(required(process.env.BOT_NUMBER, 'BOT_NUMBER')),
  appLink: required(process.env.APP_LINK, 'APP_LINK'),
  mpAccessToken: required(process.env.MP_ACCESS_TOKEN, 'MP_ACCESS_TOKEN'),
  mpWebhookUrl: process.env.MP_WEBHOOK_URL || '',
  testMinutes: parseInt(process.env.TEST_MINUTES, 10) || 300,
  testType: process.env.TEST_TYPE || 'xray'
}

module.exports = config
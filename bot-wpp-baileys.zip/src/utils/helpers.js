const crypto = require('crypto')

function randomDigits(length) {
  return String(crypto.randomInt(10 ** (length - 1), 10 ** length))
}

function generateUuid() {
  if (crypto.randomUUID) return crypto.randomUUID()
  const bytes = crypto.randomBytes(16).toString('hex')
  return [bytes.slice(0, 8), bytes.slice(8, 12), bytes.slice(12, 16), bytes.slice(16, 20), bytes.slice(20, 32)].join('-')
}

function formatSpDate(dateInput) {
  const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput
  const formatter = new Intl.DateTimeFormat('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
    day: '2-digit',
    month: '2-digit',
    year: '2-digit'
  })
  const parts = formatter.formatToParts(date)
  const map = parts.reduce((acc, part) => ({ ...acc, [part.type]: part.value }), {})
  return `${map.hour}:${map.minute} ${map.day}-${map.month}-${map.year}`
}

function formatTimeOnly(dateInput) {
  const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput
  const formatter = new Intl.DateTimeFormat('pt-BR', {
    timeZone: 'America/Sao_Paulo',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23'
  })
  return formatter.format(date)
}

function formatMoney(value) {
  const amount = Number(value || 0)
  return `R$ ${amount.toFixed(2).replace('.', ',')}`
}

function formatDuration(minutes) {
  const hours = Math.floor(minutes / 60)
  const remainingMinutes = minutes % 60
  const parts = []
  if (hours) parts.push(`${hours} horas`)
  if (remainingMinutes) parts.push(`${remainingMinutes} minutos`)
  return parts.length ? parts.join(' ') : `${minutes} minutos`
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function normalizeText(text) {
  return (text || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9\s]/g, ' ').trim()
}

function baseJid(jid) {
  return jid ? jid.split(':')[0] : ''
}

function numericJid(jid) {
  return baseJid(jid).replace(/@.*$/, '').replace(/\D/g, '')
}

function extractPhoneDigits(value) {
  return (value || '').replace('@s.whatsapp.net', '').replace('@lid', '').replace(/\D/g, '')
}

function isValidPhone(phone) {
  return phone && phone.length >= 10 && phone.length <= 15
}

function isLidJid(jid) {
  return jid?.includes('@lid')
}

function extractLid(jid) {
  return isLidJid(jid) ? jid.split('@')[0] : null
}

function formatPhoneLink(phone) {
  const cleaned = String(phone || '').replace(/\D/g, '')
  const withCountry = cleaned.startsWith('55') ? cleaned : `55${cleaned}`
  return `wa.me/${withCountry}`
}

function formatNumberLink(jid) {
  const source = jid || ''
  const cleaned = source.includes('@') ? numericJid(source) : source.replace(/\D/g, '')
  if (!cleaned) return { number: '', link: '' }
  const withCountry = cleaned.startsWith('55') ? cleaned : `55${cleaned}`
  return { number: withCountry, link: `wa.me/${withCountry}` }
}

function daysDiff(date1, date2) {
  const d1 = new Date(date1)
  const d2 = new Date(date2)
  const diffMs = Math.abs(d2 - d1)
  return Math.floor(diffMs / (1000 * 60 * 60 * 24))
}

module.exports = {
  randomDigits,
  generateUuid,
  formatSpDate,
  formatTimeOnly,
  formatMoney,
  formatDuration,
  delay,
  normalizeText,
  baseJid,
  numericJid,
  extractPhoneDigits,
  isValidPhone,
  isLidJid,
  extractLid,
  formatPhoneLink,
  formatNumberLink,
  daysDiff
}

const https = require('https')

function extractJson(text) {
  const raw = String(text || '').trim()
  if (!raw) return null
  try { return JSON.parse(raw) } catch {}

  const startCurly = raw.indexOf('{')
  const startSquare = raw.indexOf('[')
  const starts = [startCurly, startSquare].filter(i => i !== -1)
  if (!starts.length) return null
  const start = Math.min(...starts)

  const endCurly = raw.lastIndexOf('}')
  const endSquare = raw.lastIndexOf(']')
  const ends = [endCurly, endSquare].filter(i => i !== -1)
  if (!ends.length) return null
  const end = Math.max(...ends)
  if (end <= start) return null
  try {
    return JSON.parse(raw.slice(start, end + 1))
  } catch {
    return null
  }
}

function requestJson({ method, url, headers, body }) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, { method, headers }, res => {
      let data = ''
      res.on('data', chunk => { data += chunk })
      res.on('end', () => {
        const statusCode = res.statusCode || 0
        const parsed = extractJson(data)
        
        if (!parsed) {
          const cleanMsg = data.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 150)
          const error = new Error(cleanMsg || 'Resposta inválida')
          error.statusCode = statusCode
          return reject(error)
        }
        
        if (parsed.error) {
          const error = new Error(parsed.error)
          error.statusCode = statusCode
          error.response = parsed
          return reject(error)
        }
        
        if (statusCode >= 400 && !parsed.success) {
          const msg = parsed.message || `Status ${statusCode}`
          const error = new Error(msg)
          error.statusCode = statusCode
          error.response = parsed
          return reject(error)
        }
        
        resolve(parsed)
      })
    })
    req.on('error', reject)
    if (body) req.write(body)
    req.end()
  })
}

function createPanelApi(domain, token) {
  function request(endpoint, method, payload) {
    const url = new URL(endpoint, domain)
    const body = payload ? JSON.stringify(payload) : null
    const headers = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    }
    if (body) headers['Content-Length'] = Buffer.byteLength(body)
    return requestJson({ method, url, headers, body })
  }

  function createTest(data) {
    const payload = {
      login: data.login,
      senha: data.senha,
      minutos: data.minutos,
      nome: data.nome || data.login,
      tipo: data.tipo || 'v2ray'
    }
    if (data.uuid) payload.uuid = data.uuid
    if (data.contato) payload.contato = data.contato
    return request('/api/usuario/criar_teste.php', 'POST', payload)
  }

  function createUser(data) {
    const payload = {
      login: String(data.login || ''),
      senha: String(data.senha || ''),
      dias: Number(data.dias) || 30,
      limite: Number(data.limite) || 1,
      nome: String(data.nome || data.login || ''),
      tipo: String(data.tipo || 'v2ray')
    }
    if (data.uuid) payload.uuid = String(data.uuid)
    if (data.contato) payload.contato = String(data.contato)
    if (data.valor) payload.valor = String(data.valor)
    console.log('[PANEL API] createUser payload:', JSON.stringify(payload))
    return request('/api/usuario/criar.php', 'POST', payload)
  }

  function renewUser(data) {
    return request('/api/usuario/renovar.php', 'POST', data)
  }

  function deleteUser(login) {
    return request('/api/usuario/excluir.php', 'POST', { login })
  }

  function getUser(login) {
    const url = new URL('/api/usuario/listarusuarios.php', domain)
    url.searchParams.set('searchName', login)
    return requestJson({
      method: 'GET',
      url,
      headers: { Authorization: `Bearer ${token}` }
    })
  }

  function listOnline() {
    const url = new URL('/api/online/listall.php', domain)
    return requestJson({
      method: 'GET',
      url,
      headers: { Authorization: `Bearer ${token}` }
    })
  }

  return { createTest, createUser, renewUser, deleteUser, getUser, listOnline }
}

function createMercadoPagoApi(accessToken, webhookUrl) {
  function createPixPayment({ amount, description, email, externalReference, idempotencyKey }) {
    const expiresAt = new Date(Date.now() + 30 * 60000).toISOString()
    const payload = {
      transaction_amount: amount,
      description,
      payment_method_id: 'pix',
      payer: { email },
      date_of_expiration: expiresAt
    }
    if (webhookUrl) payload.notification_url = webhookUrl
    if (externalReference) payload.external_reference = externalReference
    
    const body = JSON.stringify(payload)
    const headers = {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(body),
      'X-Idempotency-Key': idempotencyKey || require('crypto').randomUUID()
    }
    
    return requestJson({
      method: 'POST',
      url: new URL('https://api.mercadopago.com/v1/payments'),
      headers,
      body
    }).then(result => ({
      id: String(result.id),
      status: result.status,
      qrCode: result?.point_of_interaction?.transaction_data?.qr_code || '',
      ticketUrl: result?.point_of_interaction?.transaction_data?.ticket_url || '',
      expiresAt
    }))
  }

  function fetchPayment(paymentId) {
    const id = String(paymentId).replace(/\.0$/, '')
    return requestJson({
      method: 'GET',
      url: new URL(`https://api.mercadopago.com/v1/payments/${id}`),
      headers: { Authorization: `Bearer ${accessToken}` }
    })
  }

  return { createPixPayment, fetchPayment }
}

module.exports = { requestJson, createPanelApi, createMercadoPagoApi }

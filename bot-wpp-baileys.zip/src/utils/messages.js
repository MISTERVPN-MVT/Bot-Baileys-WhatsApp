const { delay } = require('./helpers')

function unwrapMessage(msg) {
  let current = msg
  let next = current?.ephemeralMessage?.message || current?.viewOnceMessage?.message || current?.viewOnceMessageV2?.message
  while (next) {
    current = next
    next = current?.ephemeralMessage?.message || current?.viewOnceMessage?.message || current?.viewOnceMessageV2?.message
  }
  return current || msg
}

function extractText(message) {
  const candidates = [
    message?.conversation,
    message?.extendedTextMessage?.text,
    message?.imageMessage?.caption,
    message?.videoMessage?.caption
  ].filter(Boolean)
  return (candidates[0] || '').trim()
}

function parseParamsJson(value) {
  if (!value) return null
  try { return JSON.parse(value) } catch { return null }
}

function extractButton(message) {
  const tpl = message?.templateButtonReplyMessage
  if (tpl) return { id: tpl.selectedId, label: tpl.selectedDisplayText }
  
  const buttons = message?.buttonsResponseMessage
  if (buttons) return { id: buttons.selectedButtonId, label: buttons.selectedDisplayText }
  
  const native = message?.interactiveResponseMessage?.nativeFlowResponseMessage
  const params = parseParamsJson(native?.paramsJson)
  const id = params?.id || native?.name
  if (id) return { id, label: params?.display_text || id }
  
  return null
}

function messageTimestampMs(message) {
  const raw = message?.messageTimestamp
  if (!raw) return null
  let value = null
  if (typeof raw === 'number') value = raw
  else if (typeof raw === 'bigint') value = Number(raw)
  else if (typeof raw === 'string') value = Number(raw)
  else if (typeof raw?.toNumber === 'function') value = raw.toNumber()
  else if (typeof raw?.toString === 'function') value = Number(raw.toString())
  if (value == null || Number.isNaN(value)) return null
  if (value < 1e12) value = value * 1000
  return value
}

async function sendText(sock, jid, text, typing = true) {
  const update = sock.sendPresenceUpdate
  if (!update || !typing) return sock.sendMessage(jid, { text })
  await update('composing', jid)
  await delay(700)
  await update('paused', jid)
  return sock.sendMessage(jid, { text })
}

async function sendImage(sock, jid, image, caption = '') {
  const update = sock.sendPresenceUpdate
  if (update) {
    await update('composing', jid)
    await delay(500)
    await update('paused', jid)
  }
  return sock.sendMessage(jid, { image, caption })
}

async function sendVideo(sock, jid, video, caption = '') {
  const update = sock.sendPresenceUpdate
  if (update) {
    await update('composing', jid)
    await delay(500)
    await update('paused', jid)
  }
  return sock.sendMessage(jid, { video, caption })
}

async function sendAudio(sock, jid, audio) {
  return sock.sendMessage(jid, { audio, mimetype: 'audio/mpeg' })
}

async function sendDocument(sock, jid, document, fileName, caption = '') {
  return sock.sendMessage(jid, { document, fileName, caption })
}

async function markRead(sock, key) {
  const read = sock.readMessages
  if (!read) return
  await read([key])
}

module.exports = {
  unwrapMessage,
  extractText,
  extractButton,
  messageTimestampMs,
  sendText,
  sendImage,
  sendVideo,
  sendAudio,
  sendDocument,
  markRead
}

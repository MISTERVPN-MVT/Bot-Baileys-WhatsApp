const db = require('./init')
const crypto = require('crypto')

const STATUS = { OPEN: 'open', CLOSED: 'closed' }

const stmts = {
  insert: db.prepare(`
    INSERT INTO supports (id, phone, jid, name, status, created_at, updated_at)
    VALUES (@id, @phone, @jid, @name, @status, @createdAt, @updatedAt)
  `),
  update: db.prepare(`
    UPDATE supports SET status = @status, updated_at = @updatedAt, closed_at = @closedAt
    WHERE id = @id
  `),
  findById: db.prepare(`SELECT * FROM supports WHERE id = ?`),
  findOpenByPhone: db.prepare(`SELECT * FROM supports WHERE phone = ? AND status = 'open'`),
  getOpen: db.prepare(`SELECT * FROM supports WHERE status = 'open' ORDER BY created_at DESC`),
  getAll: db.prepare(`SELECT * FROM supports ORDER BY created_at DESC`)
}

function generateId(existing) {
  const taken = new Set(existing.map(s => s.id))
  for (let i = 0; i < 6; i++) {
    const id = String(crypto.randomInt(100, 9999))
    if (!taken.has(id)) return id
  }
  return String(crypto.randomInt(1000, 9999))
}

function nowIso() {
  return new Date().toISOString()
}

function mapRow(row) {
  if (!row) return null
  return {
    id: row.id,
    phone: row.phone,
    jid: row.jid,
    name: row.name,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    closedAt: row.closed_at
  }
}

function create(data) {
  const existing = getOpen()
  const hasOpen = existing.some(s => s.phone === data.phone)
  if (hasOpen) return null
  
  const now = nowIso()
  const id = generateId(existing)
  stmts.insert.run({
    id,
    phone: data.phone,
    jid: data.jid,
    name: data.name || '',
    status: STATUS.OPEN,
    createdAt: now,
    updatedAt: now
  })
  return findById(id)
}

function findById(id) {
  return mapRow(stmts.findById.get(id))
}

function findOpenByPhone(phone) {
  return mapRow(stmts.findOpenByPhone.get(phone))
}

function getOpen() {
  return stmts.getOpen.all().map(mapRow)
}

function getAll() {
  return stmts.getAll.all().map(mapRow)
}

function close(id) {
  const support = findById(id)
  if (!support) return null
  if (support.status !== STATUS.OPEN) return null
  
  const now = nowIso()
  stmts.update.run({ id, status: STATUS.CLOSED, updatedAt: now, closedAt: now })
  return findById(id)
}

function hasOpen(phone) {
  return !!findOpenByPhone(phone)
}

module.exports = { create, findById, findOpenByPhone, getOpen, getAll, close, hasOpen, STATUS }

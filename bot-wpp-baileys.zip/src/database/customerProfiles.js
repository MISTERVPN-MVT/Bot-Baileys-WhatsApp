const db = require('./init')

const stmts = {
  insert: db.prepare(`
    INSERT OR IGNORE INTO customer_profiles (phone, tutorial_seen_at, suspicious_score, created_at, updated_at)
    VALUES (@phone, @tutorialSeenAt, @suspiciousScore, @createdAt, @updatedAt)
  `),
  update: db.prepare(`
    UPDATE customer_profiles SET
      tutorial_seen_at = @tutorialSeenAt,
      suspicious_score = @suspiciousScore,
      updated_at = @updatedAt
    WHERE phone = @phone
  `),
  findByPhone: db.prepare(`SELECT * FROM customer_profiles WHERE phone = ?`)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return {
    phone: row.phone,
    tutorialSeenAt: row.tutorial_seen_at || null,
    suspiciousScore: row.suspicious_score || 0,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

function findByPhone(phone) {
  return mapRow(stmts.findByPhone.get(phone))
}

function ensure(phone) {
  const now = nowIso()
  stmts.insert.run({
    phone,
    tutorialSeenAt: null,
    suspiciousScore: 0,
    createdAt: now,
    updatedAt: now
  })
  return findByPhone(phone)
}

function patch(phone, changes) {
  const current = findByPhone(phone) || ensure(phone)
  const updatedAt = nowIso()
  const updated = {
    phone,
    tutorialSeenAt: changes?.tutorialSeenAt ?? current.tutorialSeenAt,
    suspiciousScore: changes?.suspiciousScore ?? current.suspiciousScore,
    createdAt: current.createdAt,
    updatedAt
  }
  stmts.update.run({
    phone: updated.phone,
    tutorialSeenAt: updated.tutorialSeenAt || null,
    suspiciousScore: updated.suspiciousScore || 0,
    updatedAt: updated.updatedAt
  })
  return findByPhone(phone)
}

function setTutorialSeen(phone, at = null) {
  const value = at || nowIso()
  return patch(phone, { tutorialSeenAt: value })
}

function incrementSuspicious(phone, delta = 1) {
  const current = findByPhone(phone) || ensure(phone)
  const nextScore = (current.suspiciousScore || 0) + Number(delta || 0)
  return patch(phone, { suspiciousScore: nextScore })
}

module.exports = {
  findByPhone,
  ensure,
  patch,
  setTutorialSeen,
  incrementSuspicious
}

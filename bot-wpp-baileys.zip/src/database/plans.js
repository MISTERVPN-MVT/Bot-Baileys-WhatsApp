const db = require('./init')

const stmts = {
  insert: db.prepare(`
    INSERT OR REPLACE INTO plans (id, label, amount, limit_count, days)
    VALUES (@id, @label, @amount, @limitCount, @days)
  `),
  findById: db.prepare(`SELECT * FROM plans WHERE id = ?`),
  getAll: db.prepare(`SELECT * FROM plans ORDER BY amount ASC`),
  remove: db.prepare(`DELETE FROM plans WHERE id = ?`),
  count: db.prepare(`SELECT COUNT(1) AS total FROM plans`)
}

function create(data) {
  stmts.insert.run({
    id: data.id,
    label: data.label,
    amount: data.amount,
    limitCount: data.limit || data.limit_count || data.limitCount,
    days: data.days
  })
  return findById(data.id)
}

function findById(id) {
  const row = stmts.findById.get(id)
  if (!row) return null
  return { id: row.id, label: row.label, amount: row.amount, limit: row.limit_count, days: row.days }
}

function getAll() {
  return stmts.getAll.all().map(row => ({
    id: row.id,
    label: row.label,
    amount: row.amount,
    limit: row.limit_count,
    days: row.days
  }))
}

function remove(id) {
  const res = stmts.remove.run(id)
  return res.changes > 0
}

function count() {
  const row = stmts.count.get()
  return row?.total || 0
}

function seedDefaults() {
  const total = count()
  if (total > 0) return
  const defaults = [
    { id: 'plan_1', label: '1 Login 18.00R$  / 30 Dias ', amount: 18, limit: 1, days: 30 },
    { id: 'plan_2', label: '1 Login 30.00R$  / 60 Dias', amount: 30, limit: 1, days: 60 },
    { id: 'plan_3', label: '1 Login 40.00R$  / 90 Dias', amount: 40, limit: 1, days: 90 }
  ]
  defaults.forEach(plan => create(plan))
}

module.exports = { create, findById, getAll, remove, count, seedDefaults }

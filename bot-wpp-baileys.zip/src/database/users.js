const db = require('./init')

const stmts = {
  insert: db.prepare(`
    INSERT OR IGNORE INTO users (jid, phone, name, first_seen_at)
    VALUES (@jid, @phone, @name, @firstSeenAt)
  `),
  findByJid: db.prepare(`SELECT * FROM users WHERE jid = ?`),
  findByPhone: db.prepare(`SELECT * FROM users WHERE phone = ?`),
  deleteByPhone: db.prepare(`DELETE FROM users WHERE phone = ?`),
  deleteByJid: db.prepare(`DELETE FROM users WHERE jid = ?`),
  getAll: db.prepare(`SELECT * FROM users ORDER BY first_seen_at DESC`),
  getAllPhones: db.prepare(`SELECT DISTINCT phone FROM users WHERE phone IS NOT NULL AND phone != ''`),
  count: db.prepare(`SELECT COUNT(*) as total FROM users`)
}

function create(data) {
  const firstSeenAt = data.firstSeenAt || new Date().toISOString()
  stmts.insert.run({ jid: data.jid, phone: data.phone || null, name: data.name || null, firstSeenAt })
  return findByJid(data.jid)
}

function findByJid(jid) {
  return stmts.findByJid.get(jid) || null
}

function findByPhone(phone) {
  return stmts.findByPhone.get(phone) || null
}

function deleteByPhone(phone) {
  const result = stmts.deleteByPhone.run(phone)
  return result.changes > 0
}

function deleteByJid(jid) {
  const result = stmts.deleteByJid.run(jid)
  return result.changes > 0
}

function getAll() {
  return stmts.getAll.all()
}

function getAllPhones() {
  return stmts.getAllPhones.all().map(row => row.phone)
}

function count() {
  return stmts.count.get()?.total || 0
}

function exists(jid, phone) {
  const byJid = findByJid(jid)
  if (byJid) return true
  if (!phone) return false
  return !!findByPhone(phone)
}

function remember(data) {
  const found = exists(data.jid, data.phone)
  if (found) return null
  return create(data)
}

module.exports = { create, findByJid, findByPhone, deleteByPhone, deleteByJid, getAll, getAllPhones, count, exists, remember }

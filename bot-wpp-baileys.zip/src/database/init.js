const Database = require('better-sqlite3')
const path = require('path')
const fs = require('fs')

const DB_PATH = path.join(__dirname, '..', '..', 'data', 'bot.db')
const DB_DIR = path.dirname(DB_PATH)

if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true })

const db = new Database(DB_PATH)
db.pragma('journal_mode = WAL')

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    jid TEXT UNIQUE NOT NULL,
    phone TEXT,
    name TEXT,
    first_seen_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS plans (
    id TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    amount REAL NOT NULL,
    limit_count INTEGER NOT NULL,
    days INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS purchases (
    id TEXT PRIMARY KEY,
    phone TEXT NOT NULL,
    jid TEXT NOT NULL,
    name TEXT,
    plan_id TEXT NOT NULL,
    plan_label TEXT NOT NULL,
    amount REAL NOT NULL,
    original_amount REAL,
    discount_amount REAL,
    coupon_code TEXT,
    referrer_phone TEXT,
    payment_method TEXT,
    limit_count INTEGER NOT NULL,
    days INTEGER NOT NULL,
    status TEXT NOT NULL,
    stage TEXT NOT NULL,
    email TEXT,
    payment_id TEXT,
    payment_status TEXT,
    expires_at TEXT,
    qr_code TEXT,
    ticket_url TEXT,
    login TEXT,
    password TEXT,
    uuid TEXT,
    completed_at TEXT,
    notified TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS accesses (
    login TEXT PRIMARY KEY,
    phone TEXT NOT NULL,
    jid TEXT NOT NULL,
    plan_id TEXT,
    plan_label TEXT,
    limit_count INTEGER NOT NULL DEFAULT 1,
    days INTEGER NOT NULL,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS access_notifications (
    login TEXT PRIMARY KEY,
    before_3d_at TEXT,
    expires_day_at TEXT,
    after_7d_at TEXT,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS customer_profiles (
    phone TEXT PRIMARY KEY,
    notes TEXT,
    tutorial_seen_at TEXT,
    suspicious_score INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS coupons (
    code TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    value REAL NOT NULL,
    max_uses INTEGER,
    expires_at TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS coupon_usages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL,
    phone TEXT NOT NULL,
    purchase_id TEXT,
    used_at TEXT NOT NULL,
    UNIQUE(code, phone)
  );

  CREATE TABLE IF NOT EXISTS promo_plans (
    id TEXT PRIMARY KEY,
    label TEXT NOT NULL,
    amount REAL NOT NULL,
    limit_count INTEGER NOT NULL,
    days INTEGER NOT NULL,
    starts_at TEXT,
    ends_at TEXT,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS referral_config (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    active INTEGER NOT NULL DEFAULT 0,
    required_count INTEGER NOT NULL DEFAULT 1,
    reward_days INTEGER NOT NULL DEFAULT 3,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS referrals (
    id TEXT PRIMARY KEY,
    referrer_phone TEXT NOT NULL,
    referee_phone TEXT NOT NULL,
    purchase_id TEXT,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(referee_phone)
  );

  CREATE TABLE IF NOT EXISTS referral_rewards (
    id TEXT PRIMARY KEY,
    referrer_phone TEXT NOT NULL,
    login TEXT,
    reward_days INTEGER NOT NULL,
    awarded_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS message_templates (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    text TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS broadcast_jobs (
    id TEXT PRIMARY KEY,
    segment TEXT NOT NULL,
    type TEXT NOT NULL,
    text TEXT,
    media BLOB,
    media_type TEXT,
    mimetype TEXT,
    template_id TEXT,
    scheduled_at TEXT NOT NULL,
    status TEXT NOT NULL,
    error_message TEXT,
    total INTEGER NOT NULL DEFAULT 0,
    sent INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    started_at TEXT,
    finished_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS system_state (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS bot_texts (
    key TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS menu_standby (
    phone TEXT PRIMARY KEY,
    until_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS renewals (
    id TEXT PRIMARY KEY,
    phone TEXT NOT NULL,
    login TEXT NOT NULL,
    days INTEGER NOT NULL,
    amount REAL NOT NULL,
    plan_label TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS broadcast_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    broadcast_id TEXT NOT NULL,
    phone TEXT NOT NULL,
    kind TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS broadcast_message_map (
    message_id TEXT PRIMARY KEY,
    broadcast_id TEXT NOT NULL,
    phone TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS tests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    jid TEXT NOT NULL,
    phone TEXT,
    login TEXT NOT NULL,
    senha TEXT NOT NULL,
    uuid TEXT NOT NULL,
    minutos INTEGER NOT NULL,
    tipo TEXT NOT NULL,
    nome TEXT,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS supports (
    id TEXT PRIMARY KEY,
    phone TEXT NOT NULL,
    jid TEXT NOT NULL,
    name TEXT,
    status TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    closed_at TEXT
  );

  CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT UNIQUE NOT NULL,
    name TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS broadcast_numbers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT UNIQUE NOT NULL,
    jid TEXT,
    name TEXT,
    added_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    message TEXT NOT NULL,
    data TEXT,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS notification_templates (
    key TEXT PRIMARY KEY,
    text TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS lid_map (
    lid TEXT PRIMARY KEY,
    phone TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS blocked (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT UNIQUE NOT NULL,
    reason TEXT,
    blocked_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_purchases_phone ON purchases(phone);
  CREATE INDEX IF NOT EXISTS idx_blocked_phone ON blocked(phone);
  CREATE INDEX IF NOT EXISTS idx_purchases_stage ON purchases(stage);
  CREATE INDEX IF NOT EXISTS idx_tests_jid ON tests(jid);
  CREATE INDEX IF NOT EXISTS idx_tests_phone ON tests(phone);
  CREATE INDEX IF NOT EXISTS idx_supports_phone ON supports(phone);
  CREATE INDEX IF NOT EXISTS idx_supports_status ON supports(status);
  CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
  CREATE INDEX IF NOT EXISTS idx_accesses_phone ON accesses(phone);
  CREATE INDEX IF NOT EXISTS idx_accesses_expires_at ON accesses(expires_at);
  CREATE INDEX IF NOT EXISTS idx_coupons_active ON coupons(active);
  CREATE INDEX IF NOT EXISTS idx_coupon_usages_code ON coupon_usages(code);
  CREATE INDEX IF NOT EXISTS idx_coupon_usages_phone ON coupon_usages(phone);
  CREATE INDEX IF NOT EXISTS idx_promo_plans_active ON promo_plans(active);
  CREATE INDEX IF NOT EXISTS idx_broadcast_jobs_status ON broadcast_jobs(status);
  CREATE INDEX IF NOT EXISTS idx_broadcast_jobs_scheduled_at ON broadcast_jobs(scheduled_at);
  CREATE INDEX IF NOT EXISTS idx_broadcast_events_broadcast_id ON broadcast_events(broadcast_id);
  CREATE INDEX IF NOT EXISTS idx_broadcast_events_phone ON broadcast_events(phone);
  CREATE INDEX IF NOT EXISTS idx_broadcast_events_kind ON broadcast_events(kind);
  CREATE INDEX IF NOT EXISTS idx_broadcast_message_map_broadcast_id ON broadcast_message_map(broadcast_id);
  CREATE INDEX IF NOT EXISTS idx_broadcast_message_map_phone ON broadcast_message_map(phone);
  CREATE INDEX IF NOT EXISTS idx_referrals_referrer_phone ON referrals(referrer_phone);
  CREATE INDEX IF NOT EXISTS idx_referral_rewards_referrer_phone ON referral_rewards(referrer_phone);
  CREATE INDEX IF NOT EXISTS idx_renewals_phone ON renewals(phone);
`)

const tableColumns = (table) => {
  const rows = db.prepare(`PRAGMA table_info(${table})`).all()
  return new Set(rows.map(r => r.name))
}

const ensureColumn = (table, columnName, columnDef) => {
  const cols = tableColumns(table)
  if (cols.has(columnName)) return false
  db.exec(`ALTER TABLE ${table} ADD COLUMN ${columnDef}`)
  return true
}

ensureColumn('purchases', 'original_amount', 'original_amount REAL')
ensureColumn('purchases', 'discount_amount', 'discount_amount REAL')
ensureColumn('purchases', 'coupon_code', 'coupon_code TEXT')
ensureColumn('purchases', 'referrer_phone', 'referrer_phone TEXT')
ensureColumn('purchases', 'payment_method', 'payment_method TEXT')

ensureColumn('accesses', 'limit_count', 'limit_count INTEGER NOT NULL DEFAULT 1')
ensureColumn('broadcast_jobs', 'error_message', 'error_message TEXT')

const ensureReferralConfig = () => {
  const exists = db.prepare(`SELECT id FROM referral_config WHERE id = 1`).get()
  if (exists) return
  const now = new Date().toISOString()
  db.prepare(`
    INSERT INTO referral_config (id, active, required_count, reward_days, updated_at)
    VALUES (1, 0, 1, 3, ?)
  `).run(now)
}

ensureReferralConfig()

module.exports = db

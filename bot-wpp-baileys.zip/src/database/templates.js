const db = require('./init')
const crypto = require('crypto')

const stmts = {
  insert: db.prepare(`
    INSERT INTO message_templates (id, name, text, created_at, updated_at)
    VALUES (@id, @name, @text, @createdAt, @updatedAt)
  `),
  update: db.prepare(`
    UPDATE message_templates SET
      name = @name,
      text = @text,
      updated_at = @updatedAt
    WHERE id = @id
  `),
  remove: db.prepare(`DELETE FROM message_templates WHERE id = ?`),
  findById: db.prepare(`SELECT * FROM message_templates WHERE id = ?`),
  listAll: db.prepare(`SELECT * FROM message_templates ORDER BY created_at DESC`)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return {
    id: row.id,
    name: row.name,
    text: row.text,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

const generateId = () => crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex')

function create({ name, text }) {
  const now = nowIso()
  const id = generateId()
  stmts.insert.run({ id, name, text, createdAt: now, updatedAt: now })
  return findById(id)
}

function update(id, changes) {
  const current = findById(id)
  if (!current) return null
  const updated = { ...current, ...changes, updatedAt: nowIso() }
  stmts.update.run({ id, name: updated.name, text: updated.text, updatedAt: updated.updatedAt })
  return findById(id)
}

function remove(id) {
  const res = stmts.remove.run(id)
  return res.changes > 0
}

function findById(id) {
  return mapRow(stmts.findById.get(id))
}

function listAll() {
  return stmts.listAll.all().map(mapRow)
}

module.exports = { create, update, remove, findById, listAll }


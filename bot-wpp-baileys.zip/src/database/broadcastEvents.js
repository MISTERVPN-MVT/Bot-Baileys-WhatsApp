const db = require('./init')

const stmts = {
  insert: db.prepare(`
    INSERT INTO broadcast_events (broadcast_id, phone, kind, created_at)
    VALUES (@broadcastId, @phone, @kind, @createdAt)
  `),
  countByKind: db.prepare(`
    SELECT COUNT(*) as total FROM broadcast_events
    WHERE broadcast_id = ? AND kind = ?
  `),
  findLatestSent: db.prepare(`
    SELECT * FROM broadcast_events
    WHERE phone = ? AND kind = 'sent' AND created_at >= ?
    ORDER BY created_at DESC LIMIT 1
  `),
  hasReply: db.prepare(`
    SELECT 1 as v FROM broadcast_events
    WHERE broadcast_id = ? AND phone = ? AND kind = 'reply'
    LIMIT 1
  `),
  hasKind: db.prepare(`
    SELECT 1 as v FROM broadcast_events
    WHERE broadcast_id = ? AND phone = ? AND kind = ?
    LIMIT 1
  `)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return {
    id: row.id,
    broadcastId: row.broadcast_id,
    phone: row.phone,
    kind: row.kind,
    createdAt: row.created_at
  }
}

function add({ broadcastId, phone, kind, createdAt }) {
  stmts.insert.run({ broadcastId, phone, kind, createdAt: createdAt || nowIso() })
}

function countByKind(broadcastId, kind) {
  return stmts.countByKind.get(broadcastId, kind)?.total || 0
}

function findLatestSentForPhone(phone, sinceIso) {
  return mapRow(stmts.findLatestSent.get(phone, sinceIso))
}

function hasReply(broadcastId, phone) {
  return Boolean(stmts.hasReply.get(broadcastId, phone))
}

function hasKind(broadcastId, phone, kind) {
  return Boolean(stmts.hasKind.get(broadcastId, phone, kind))
}

module.exports = { add, countByKind, findLatestSentForPhone, hasReply, hasKind }

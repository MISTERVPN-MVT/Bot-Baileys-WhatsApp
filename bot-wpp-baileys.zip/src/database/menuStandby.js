const db = require('./init')

const stmts = {
  upsert: db.prepare(`
    INSERT INTO menu_standby (phone, until_at, updated_at)
    VALUES (@phone, @untilAt, @updatedAt)
    ON CONFLICT(phone) DO UPDATE SET
      until_at = excluded.until_at,
      updated_at = excluded.updated_at
  `),
  findByPhone: db.prepare(`SELECT * FROM menu_standby WHERE phone = ? LIMIT 1`),
  remove: db.prepare(`DELETE FROM menu_standby WHERE phone = ?`)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return {
    phone: row.phone,
    untilAt: row.until_at,
    updatedAt: row.updated_at
  }
}

function upsert({ phone, untilAt }) {
  const key = String(phone || '').trim()
  const until = String(untilAt || '').trim()
  if (!key) return null
  if (!until) return null
  stmts.upsert.run({ phone: key, untilAt: until, updatedAt: nowIso() })
  return findByPhone(key)
}

function findByPhone(phone) {
  const key = String(phone || '').trim()
  if (!key) return null
  return mapRow(stmts.findByPhone.get(key))
}

function remove(phone) {
  const key = String(phone || '').trim()
  if (!key) return false
  const res = stmts.remove.run(key)
  return res.changes > 0
}

module.exports = { upsert, findByPhone, remove }

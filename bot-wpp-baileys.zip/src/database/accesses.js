const db = require('./init')

const stmts = {
  upsert: db.prepare(`
    INSERT INTO accesses (login, phone, jid, plan_id, plan_label, limit_count, days, expires_at, created_at, updated_at)
    VALUES (@login, @phone, @jid, @planId, @planLabel, @limitCount, @days, @expiresAt, @createdAt, @updatedAt)
    ON CONFLICT(login) DO UPDATE SET
      phone = excluded.phone,
      jid = excluded.jid,
      plan_id = excluded.plan_id,
      plan_label = excluded.plan_label,
      limit_count = excluded.limit_count,
      days = excluded.days,
      expires_at = excluded.expires_at,
      updated_at = excluded.updated_at
  `),
  findByLogin: db.prepare(`SELECT * FROM accesses WHERE login = ?`),
  findLatestByPhone: db.prepare(`
    SELECT * FROM accesses WHERE phone = ?
    ORDER BY expires_at DESC, updated_at DESC LIMIT 1
  `),
  listByPhone: db.prepare(`SELECT * FROM accesses WHERE phone = ? ORDER BY expires_at DESC`),
  listAll: db.prepare(`SELECT * FROM accesses ORDER BY expires_at ASC`),
  updateExpiresAt: db.prepare(`UPDATE accesses SET expires_at = @expiresAt, updated_at = @updatedAt WHERE login = @login`),
  deleteByLogin: db.prepare(`DELETE FROM accesses WHERE login = ?`),
  deleteNotifications: db.prepare(`DELETE FROM access_notifications WHERE login = ?`),
  notifBefore3d: db.prepare(`
    INSERT INTO access_notifications (login, before_3d_at, updated_at)
    VALUES (@login, @at, @updatedAt)
    ON CONFLICT(login) DO UPDATE SET
      before_3d_at = excluded.before_3d_at,
      updated_at = excluded.updated_at
  `),
  notifExpiresDay: db.prepare(`
    INSERT INTO access_notifications (login, expires_day_at, updated_at)
    VALUES (@login, @at, @updatedAt)
    ON CONFLICT(login) DO UPDATE SET
      expires_day_at = excluded.expires_day_at,
      updated_at = excluded.updated_at
  `),
  notifAfter7d: db.prepare(`
    INSERT INTO access_notifications (login, after_7d_at, updated_at)
    VALUES (@login, @at, @updatedAt)
    ON CONFLICT(login) DO UPDATE SET
      after_7d_at = excluded.after_7d_at,
      updated_at = excluded.updated_at
  `),
  getNotifications: db.prepare(`SELECT * FROM access_notifications WHERE login = ?`)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return {
    login: row.login,
    phone: row.phone,
    jid: row.jid,
    planId: row.plan_id || null,
    planLabel: row.plan_label || null,
    limitCount: row.limit_count ?? 1,
    days: row.days,
    expiresAt: row.expires_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

const mapNotifRow = (row) => {
  if (!row) return null
  return {
    login: row.login,
    before3dAt: row.before_3d_at || null,
    expiresDayAt: row.expires_day_at || null,
    after7dAt: row.after_7d_at || null,
    updatedAt: row.updated_at
  }
}

function upsertAccess(data) {
  const prev = findByLogin(data.login)
  const now = nowIso()
  stmts.upsert.run({
    login: data.login,
    phone: data.phone,
    jid: data.jid,
    planId: data.planId || null,
    planLabel: data.planLabel || null,
    limitCount: data.limitCount ?? 1,
    days: data.days,
    expiresAt: data.expiresAt,
    createdAt: data.createdAt || now,
    updatedAt: now
  })
  const next = findByLogin(data.login)
  const prevExpiresAt = prev?.expiresAt || null
  const nextExpiresAt = next?.expiresAt || null
  const changed = prevExpiresAt && nextExpiresAt && prevExpiresAt !== nextExpiresAt
  if (changed) clearNotifications(data.login)
  return next
}

function findByLogin(login) {
  return mapRow(stmts.findByLogin.get(login))
}

function findLatestByPhone(phone) {
  return mapRow(stmts.findLatestByPhone.get(phone))
}

function listByPhone(phone) {
  return stmts.listByPhone.all(phone).map(mapRow)
}

function listAll() {
  return stmts.listAll.all().map(mapRow)
}

function updateExpiresAt(login, expiresAt) {
  const prev = findByLogin(login)
  stmts.updateExpiresAt.run({ login, expiresAt, updatedAt: nowIso() })
  const next = findByLogin(login)
  const changed = prev?.expiresAt && next?.expiresAt && prev.expiresAt !== next.expiresAt
  if (changed) clearNotifications(login)
  return next
}

function removeByLogin(login) {
  const value = String(login || '').trim()
  if (!value) return false
  stmts.deleteNotifications.run(value)
  const res = stmts.deleteByLogin.run(value)
  return res.changes > 0
}

function clearNotifications(login) {
  const value = String(login || '').trim()
  if (!value) return false
  stmts.deleteNotifications.run(value)
  return true
}

const markNotification = (stmt, login, at = null) => {
  const now = nowIso()
  stmt.run({ login, at: at || now, updatedAt: now })
  return getNotifications(login)
}

function markBefore3d(login, at = null) {
  return markNotification(stmts.notifBefore3d, login, at)
}

function markExpiresDay(login, at = null) {
  return markNotification(stmts.notifExpiresDay, login, at)
}

function markAfter7d(login, at = null) {
  return markNotification(stmts.notifAfter7d, login, at)
}

function getNotifications(login) {
  return mapNotifRow(stmts.getNotifications.get(login))
}

module.exports = {
  upsertAccess,
  findByLogin,
  findLatestByPhone,
  listByPhone,
  listAll,
  updateExpiresAt,
  removeByLogin,
  clearNotifications,
  markBefore3d,
  markExpiresDay,
  markAfter7d,
  getNotifications
}

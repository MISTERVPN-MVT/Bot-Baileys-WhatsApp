const db = require('./init')

const stmts = {
  insert: db.prepare(`INSERT OR IGNORE INTO blocked (phone, reason, blocked_at) VALUES (@phone, @reason, @blockedAt)`),
  remove: db.prepare(`DELETE FROM blocked WHERE phone = ?`),
  findByPhone: db.prepare(`SELECT * FROM blocked WHERE phone = ?`),
  getAll: db.prepare(`SELECT * FROM blocked ORDER BY blocked_at DESC`)
}

function block(phone, reason = null) {
  const blockedAt = new Date().toISOString()
  stmts.insert.run({ phone, reason, blockedAt })
  return findByPhone(phone)
}

function unblock(phone) {
  const result = stmts.remove.run(phone)
  return result.changes > 0
}

function findByPhone(phone) {
  return stmts.findByPhone.get(phone) || null
}

function isBlocked(phone) {
  return !!findByPhone(phone)
}

function getAll() {
  return stmts.getAll.all()
}

module.exports = { block, unblock, findByPhone, isBlocked, getAll }

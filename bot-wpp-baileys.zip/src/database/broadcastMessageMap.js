const db = require('./init')

const stmts = {
  insert: db.prepare(`
    INSERT OR IGNORE INTO broadcast_message_map (message_id, broadcast_id, phone, created_at)
    VALUES (@messageId, @broadcastId, @phone, @createdAt)
  `),
  findByMessageId: db.prepare(`SELECT * FROM broadcast_message_map WHERE message_id = ? LIMIT 1`),
  deleteBefore: db.prepare(`DELETE FROM broadcast_message_map WHERE created_at < ?`)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return {
    messageId: row.message_id,
    broadcastId: row.broadcast_id,
    phone: row.phone,
    createdAt: row.created_at
  }
}

function add({ messageId, broadcastId, phone, createdAt }) {
  if (!messageId) return false
  stmts.insert.run({
    messageId: String(messageId),
    broadcastId,
    phone,
    createdAt: createdAt || nowIso()
  })
  return true
}

function findByMessageId(messageId) {
  if (!messageId) return null
  return mapRow(stmts.findByMessageId.get(String(messageId)))
}

function pruneOlderThan(days = 7) {
  const cutoff = new Date(Date.now() - Number(days || 0) * 24 * 60 * 60 * 1000).toISOString()
  return stmts.deleteBefore.run(cutoff).changes || 0
}

module.exports = { add, findByMessageId, pruneOlderThan }


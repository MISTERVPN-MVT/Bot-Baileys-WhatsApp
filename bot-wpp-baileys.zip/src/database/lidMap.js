const db = require('./init')

const stmts = {
  insert: db.prepare(`INSERT OR REPLACE INTO lid_map (lid, phone) VALUES (@lid, @phone)`),
  findByLid: db.prepare(`SELECT phone FROM lid_map WHERE lid = ?`),
  getAll: db.prepare(`SELECT * FROM lid_map`)
}

function save(lid, phone) {
  if (!lid || !phone || phone.length < 10) return false
  stmts.insert.run({ lid, phone })
  return true
}

function getPhone(lid) {
  const row = stmts.findByLid.get(lid)
  return row ? row.phone : null
}

function getAll() {
  return stmts.getAll.all()
}

module.exports = { save, getPhone, getAll }

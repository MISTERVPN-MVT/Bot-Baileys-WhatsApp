const db = require('./init')

const stmts = {
  upsert: db.prepare(`
    INSERT INTO coupons (code, kind, value, max_uses, expires_at, active, created_at, updated_at)
    VALUES (@code, @kind, @value, @maxUses, @expiresAt, @active, @createdAt, @updatedAt)
    ON CONFLICT(code) DO UPDATE SET
      kind = excluded.kind,
      value = excluded.value,
      max_uses = excluded.max_uses,
      expires_at = excluded.expires_at,
      active = excluded.active,
      updated_at = excluded.updated_at
  `),
  findByCode: db.prepare(`SELECT * FROM coupons WHERE code = ?`),
  listAll: db.prepare(`SELECT * FROM coupons ORDER BY created_at DESC`),
  listActive: db.prepare(`SELECT * FROM coupons WHERE active = 1 ORDER BY created_at DESC`),
  insertUsage: db.prepare(`
    INSERT INTO coupon_usages (code, phone, purchase_id, used_at)
    VALUES (@code, @phone, @purchaseId, @usedAt)
  `),
  countUsages: db.prepare(`SELECT COUNT(*) as total FROM coupon_usages WHERE code = ?`),
  hasPhoneUsed: db.prepare(`SELECT 1 as v FROM coupon_usages WHERE code = ? AND phone = ? LIMIT 1`),
  deleteCoupon: db.prepare(`DELETE FROM coupons WHERE code = ?`),
  deleteUsages: db.prepare(`DELETE FROM coupon_usages WHERE code = ?`)
}

const nowIso = () => new Date().toISOString()

const normalizeCode = (code) => String(code || '').trim().toUpperCase()

const mapRow = (row) => {
  if (!row) return null
  return {
    code: row.code,
    kind: row.kind,
    value: row.value,
    maxUses: row.max_uses ?? null,
    expiresAt: row.expires_at || null,
    active: Boolean(row.active),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

function upsert(data) {
  const code = normalizeCode(data.code)
  const now = nowIso()
  stmts.upsert.run({
    code,
    kind: data.kind,
    value: data.value,
    maxUses: data.maxUses ?? null,
    expiresAt: data.expiresAt || null,
    active: data.active ? 1 : 0,
    createdAt: data.createdAt || now,
    updatedAt: now
  })
  return findByCode(code)
}

function findByCode(code) {
  return mapRow(stmts.findByCode.get(normalizeCode(code)))
}

function listAll() {
  return stmts.listAll.all().map(mapRow)
}

function listActive() {
  return stmts.listActive.all().map(mapRow)
}

function countUsages(code) {
  return stmts.countUsages.get(normalizeCode(code))?.total || 0
}

function hasPhoneUsed(code, phone) {
  return Boolean(stmts.hasPhoneUsed.get(normalizeCode(code), phone))
}

function insertUsage({ code, phone, purchaseId }) {
  stmts.insertUsage.run({ code: normalizeCode(code), phone, purchaseId: purchaseId || null, usedAt: nowIso() })
}

function remove(code) {
  const normalized = normalizeCode(code)
  stmts.deleteUsages.run(normalized)
  const result = stmts.deleteCoupon.run(normalized)
  return result.changes > 0
}

module.exports = {
  normalizeCode,
  upsert,
  findByCode,
  listAll,
  listActive,
  countUsages,
  hasPhoneUsed,
  insertUsage,
  remove
}

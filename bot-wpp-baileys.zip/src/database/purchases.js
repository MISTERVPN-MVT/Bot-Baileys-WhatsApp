const db = require('./init')
const crypto = require('crypto')

const ACTIVE_STAGES = ['awaiting_email', 'pending_payment', 'awaiting_username']

const stmts = {
  insert: db.prepare(`
    INSERT INTO purchases (
      id, phone, jid, name, plan_id, plan_label, amount, limit_count, days,
      original_amount, discount_amount, coupon_code, referrer_phone, payment_method,
      status, stage, email, payment_id, payment_status, expires_at,
      qr_code, ticket_url, login, password, uuid, completed_at, notified,
      created_at, updated_at
    ) VALUES (
      @id, @phone, @jid, @name, @planId, @planLabel, @amount, @limitCount, @days,
      @originalAmount, @discountAmount, @couponCode, @referrerPhone, @paymentMethod,
      @status, @stage, @email, @paymentId, @paymentStatus, @expiresAt,
      @qrCode, @ticketUrl, @login, @password, @uuid, @completedAt, @notified,
      @createdAt, @updatedAt
    )
  `),
  update: db.prepare(`
    UPDATE purchases SET
      amount = @amount,
      original_amount = @originalAmount,
      discount_amount = @discountAmount,
      coupon_code = @couponCode,
      referrer_phone = @referrerPhone,
      payment_method = @paymentMethod,
      status = @status, stage = @stage, email = @email,
      payment_id = @paymentId, payment_status = @paymentStatus,
      expires_at = @expiresAt, qr_code = @qrCode, ticket_url = @ticketUrl,
      login = @login, password = @password, uuid = @uuid,
      completed_at = @completedAt, notified = @notified, updated_at = @updatedAt
    WHERE id = @id
  `),
  findById: db.prepare(`SELECT * FROM purchases WHERE id = ?`),
  findActiveByPhone: db.prepare(`
    SELECT * FROM purchases 
    WHERE phone = ? AND stage IN ('awaiting_email', 'pending_payment', 'awaiting_username')
    ORDER BY created_at DESC LIMIT 1
  `),
  findCompletedByPhone: db.prepare(`
    SELECT * FROM purchases 
    WHERE phone = ? AND stage = 'completed'
    ORDER BY completed_at DESC LIMIT 1
  `),
  listByPhone: db.prepare(`
    SELECT * FROM purchases
    WHERE phone = ?
    ORDER BY created_at DESC LIMIT ?
  `),
  listCompletedByPhone: db.prepare(`
    SELECT * FROM purchases
    WHERE phone = ? AND stage = 'completed'
    ORDER BY completed_at DESC, created_at DESC LIMIT ?
  `),
  findPendingPayments: db.prepare(`
    SELECT * FROM purchases 
    WHERE stage = 'pending_payment' AND payment_id IS NOT NULL
  `),
  deleteById: db.prepare(`DELETE FROM purchases WHERE id = ?`),
  deleteCouponUsagesByPurchaseId: db.prepare(`DELETE FROM coupon_usages WHERE purchase_id = ?`),
  getAll: db.prepare(`SELECT * FROM purchases ORDER BY created_at DESC`)
}

function generateId() {
  return crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex')
}

function nowIso() {
  return new Date().toISOString()
}

function mapRow(row) {
  if (!row) return null
  return {
    id: row.id,
    phone: row.phone,
    jid: row.jid,
    name: row.name,
    planId: row.plan_id,
    planLabel: row.plan_label,
    amount: row.amount,
    originalAmount: row.original_amount ?? row.amount,
    discountAmount: row.discount_amount ?? 0,
    couponCode: row.coupon_code || null,
    referrerPhone: row.referrer_phone || null,
    paymentMethod: row.payment_method || null,
    limit: row.limit_count,
    days: row.days,
    status: row.status,
    stage: row.stage,
    email: row.email,
    paymentId: row.payment_id,
    paymentStatus: row.payment_status,
    expiresAt: row.expires_at,
    qrCode: row.qr_code,
    ticketUrl: row.ticket_url,
    login: row.login,
    password: row.password,
    uuid: row.uuid,
    completedAt: row.completed_at,
    notified: row.notified ? JSON.parse(row.notified) : {},
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

function create(data) {
  const now = nowIso()
  const id = data.id || generateId()
  const originalAmount = Number.isFinite(data.originalAmount) ? data.originalAmount : data.amount
  const discountAmount = Number.isFinite(data.discountAmount) ? data.discountAmount : 0
  stmts.insert.run({
    id,
    phone: data.phone,
    jid: data.jid,
    name: data.name || '',
    planId: data.planId,
    planLabel: data.planLabel,
    amount: data.amount,
    limitCount: data.limit,
    days: data.days,
    originalAmount,
    discountAmount,
    couponCode: data.couponCode || null,
    referrerPhone: data.referrerPhone || null,
    paymentMethod: data.paymentMethod || 'pix',
    status: data.status || 'draft',
    stage: data.stage || 'awaiting_email',
    email: data.email || null,
    paymentId: data.paymentId ? String(data.paymentId) : null,
    paymentStatus: data.paymentStatus || null,
    expiresAt: data.expiresAt || null,
    qrCode: data.qrCode || null,
    ticketUrl: data.ticketUrl || null,
    login: data.login || null,
    password: data.password || null,
    uuid: data.uuid || null,
    completedAt: data.completedAt || null,
    notified: JSON.stringify(data.notified || {}),
    createdAt: now,
    updatedAt: now
  })
  return findById(id)
}

function update(purchase) {
  stmts.update.run({
    id: purchase.id,
    amount: purchase.amount,
    originalAmount: purchase.originalAmount ?? purchase.amount,
    discountAmount: purchase.discountAmount ?? 0,
    couponCode: purchase.couponCode || null,
    referrerPhone: purchase.referrerPhone || null,
    paymentMethod: purchase.paymentMethod || null,
    status: purchase.status,
    stage: purchase.stage,
    email: purchase.email || null,
    paymentId: purchase.paymentId ? String(purchase.paymentId) : null,
    paymentStatus: purchase.paymentStatus || null,
    expiresAt: purchase.expiresAt || null,
    qrCode: purchase.qrCode || null,
    ticketUrl: purchase.ticketUrl || null,
    login: purchase.login || null,
    password: purchase.password || null,
    uuid: purchase.uuid || null,
    completedAt: purchase.completedAt || null,
    notified: JSON.stringify(purchase.notified || {}),
    updatedAt: nowIso()
  })
  return findById(purchase.id)
}

function patch(purchase, changes) {
  const updated = { ...purchase, ...changes, updatedAt: nowIso() }
  return update(updated)
}

function findById(id) {
  return mapRow(stmts.findById.get(id))
}

function findActiveByPhone(phone) {
  return mapRow(stmts.findActiveByPhone.get(phone))
}

function findCompletedByPhone(phone) {
  return mapRow(stmts.findCompletedByPhone.get(phone))
}

function listByPhone(phone, limit = 20) {
  return stmts.listByPhone.all(phone, limit).map(mapRow)
}

function listCompletedByPhone(phone, limit = 20) {
  return stmts.listCompletedByPhone.all(phone, limit).map(mapRow)
}

function findPendingPayments() {
  return stmts.findPendingPayments.all().map(mapRow)
}

function getAll() {
  return stmts.getAll.all().map(mapRow)
}

function hasPurchased(phone) {
  return !!findCompletedByPhone(phone)
}

function removeById(id) {
  const value = String(id || '').trim()
  if (!value) return null
  const found = findById(value)
  if (!found) return null
  stmts.deleteCouponUsagesByPurchaseId.run(value)
  const res = stmts.deleteById.run(value)
  const ok = res.changes > 0
  return ok ? found : null
}

module.exports = {
  create, update, patch, findById, findActiveByPhone,
  findCompletedByPhone,
  listByPhone,
  listCompletedByPhone,
  findPendingPayments,
  getAll,
  hasPurchased,
  generateId,
  removeById
}

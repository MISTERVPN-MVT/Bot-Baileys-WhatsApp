const db = require('./init')

const stmts = {
  upsert: db.prepare(`
    INSERT INTO system_state (key, value, updated_at)
    VALUES (@key, @value, @updatedAt)
    ON CONFLICT(key) DO UPDATE SET
      value = excluded.value,
      updated_at = excluded.updated_at
  `),
  get: db.prepare(`SELECT * FROM system_state WHERE key = ?`)
}

const nowIso = () => new Date().toISOString()

function get(key) {
  const row = stmts.get.get(key)
  if (!row) return null
  return row.value ?? null
}

function set(key, value) {
  stmts.upsert.run({ key, value: value == null ? null : String(value), updatedAt: nowIso() })
  return get(key)
}

function getJson(key) {
  const raw = get(key)
  if (!raw) return null
  try { return JSON.parse(raw) } catch { return null }
}

function setJson(key, value) {
  const raw = value == null ? null : JSON.stringify(value)
  return set(key, raw)
}

module.exports = { get, set, getJson, setJson }


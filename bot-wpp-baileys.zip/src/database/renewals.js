const db = require('./init')
const crypto = require('crypto')

const stmts = {
  insert: db.prepare(`
    INSERT INTO renewals (id, phone, login, days, amount, plan_label, created_at)
    VALUES (@id, @phone, @login, @days, @amount, @planLabel, @createdAt)
  `),
  listByPhone: db.prepare(`
    SELECT * FROM renewals WHERE phone = ?
    ORDER BY created_at DESC LIMIT ?
  `),
  listRecent: db.prepare(`SELECT * FROM renewals ORDER BY created_at DESC LIMIT ?`)
}

const nowIso = () => new Date().toISOString()

const generateId = () => crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex')

const mapRow = (row) => {
  if (!row) return null
  return {
    id: row.id,
    phone: row.phone,
    login: row.login,
    days: row.days,
    amount: row.amount,
    planLabel: row.plan_label || '',
    createdAt: row.created_at
  }
}

function create(data) {
  const createdAt = data.createdAt || nowIso()
  const id = data.id || generateId()
  stmts.insert.run({
    id,
    phone: data.phone,
    login: data.login,
    days: data.days,
    amount: data.amount,
    planLabel: data.planLabel || null,
    createdAt
  })
  return { ...data, id, createdAt }
}

function listByPhone(phone, limit = 20) {
  return stmts.listByPhone.all(phone, limit).map(mapRow)
}

function listRecent(limit = 20) {
  return stmts.listRecent.all(limit).map(mapRow)
}

module.exports = { create, listByPhone, listRecent }


const db = require('./init')

const stmts = {
  upsert: db.prepare(`
    INSERT INTO notification_templates (key, text, updated_at)
    VALUES (@key, @text, @updatedAt)
    ON CONFLICT(key) DO UPDATE SET
      text = excluded.text,
      updated_at = excluded.updated_at
  `),
  findByKey: db.prepare(`SELECT * FROM notification_templates WHERE key = ? LIMIT 1`),
  listAll: db.prepare(`SELECT * FROM notification_templates ORDER BY key ASC`)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return { key: row.key, text: row.text, updatedAt: row.updated_at }
}

function upsert({ key, text }) {
  const normalizedKey = String(key || '').trim()
  const body = String(text || '').trim()
  if (!normalizedKey) return null
  if (!body) return null
  stmts.upsert.run({ key: normalizedKey, text: body, updatedAt: nowIso() })
  return findByKey(normalizedKey)
}

function findByKey(key) {
  return mapRow(stmts.findByKey.get(String(key || '').trim()))
}

function listAll() {
  return stmts.listAll.all().map(mapRow)
}

module.exports = { upsert, findByKey, listAll }


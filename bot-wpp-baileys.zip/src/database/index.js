const db = require('./init')
const users = require('./users')
const plans = require('./plans')
const purchases = require('./purchases')
const tests = require('./tests')
const supports = require('./supports')
const broadcast = require('./broadcast')
const lidMap = require('./lidMap')
const logs = require('./logs')
const blocked = require('./blocked')
const coupons = require('./coupons')
const accesses = require('./accesses')
const customerProfiles = require('./customerProfiles')
const templates = require('./templates')
const broadcastJobs = require('./broadcastJobs')
const broadcastEvents = require('./broadcastEvents')
const broadcastMessageMap = require('./broadcastMessageMap')
const systemState = require('./systemState')
const renewals = require('./renewals')
const notificationTemplates = require('./notificationTemplates')
const botTexts = require('./botTexts')
const menuStandby = require('./menuStandby')

module.exports = {
  db,
  users,
  plans,
  purchases,
  tests,
  supports,
  broadcast,
  lidMap,
  logs,
  blocked,
  coupons,
  accesses,
  customerProfiles,
  templates,
  broadcastJobs,
  broadcastEvents,
  broadcastMessageMap,
  systemState,
  renewals,
  notificationTemplates,
  botTexts,
  menuStandby
}

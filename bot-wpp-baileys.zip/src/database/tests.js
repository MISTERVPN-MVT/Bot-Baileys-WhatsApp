const db = require('./init')

const stmts = {
  insert: db.prepare(`
    INSERT INTO tests (jid, phone, login, senha, uuid, minutos, tipo, nome, created_at, expires_at)
    VALUES (@jid, @phone, @login, @senha, @uuid, @minutos, @tipo, @nome, @createdAt, @expiresAt)
  `),
  findByJidOrPhone: db.prepare(`
    SELECT * FROM tests 
    WHERE jid = @jid OR (@phone IS NOT NULL AND phone = @phone)
    ORDER BY created_at DESC LIMIT 1
  `),
  findByLogin: db.prepare(`SELECT * FROM tests WHERE login = ?`),
  findByPhone: db.prepare(`SELECT * FROM tests WHERE phone = ?`),
  getAll: db.prepare(`SELECT * FROM tests ORDER BY created_at DESC`),
  deleteById: db.prepare(`DELETE FROM tests WHERE id = ?`),
  deleteByLogin: db.prepare(`DELETE FROM tests WHERE login = ?`),
  deleteByPhone: db.prepare(`DELETE FROM tests WHERE phone = ?`),
  deleteAll: db.prepare(`DELETE FROM tests`),
  getAllWithPhone: db.prepare(`SELECT * FROM tests WHERE phone IS NOT NULL AND phone != ''`)
}

function mapRow(row) {
  if (!row) return null
  return {
    id: row.id,
    jid: row.jid,
    phone: row.phone,
    login: row.login,
    senha: row.senha,
    uuid: row.uuid,
    minutos: row.minutos,
    tipo: row.tipo,
    nome: row.nome,
    createdAt: row.created_at,
    expiresAt: row.expires_at
  }
}

function create(data) {
  const createdAt = new Date()
  const expiresAt = new Date(createdAt.getTime() + data.minutos * 60000)
  stmts.insert.run({
    jid: data.jid,
    phone: data.phone || null,
    login: data.login,
    senha: data.senha,
    uuid: data.uuid,
    minutos: data.minutos,
    tipo: data.tipo,
    nome: data.nome || null,
    createdAt: createdAt.toISOString(),
    expiresAt: expiresAt.toISOString()
  })
  return { ...data, createdAt: createdAt.toISOString(), expiresAt: expiresAt.toISOString() }
}

function latestFor(jid, phone) {
  return mapRow(stmts.findByJidOrPhone.get({ jid, phone: phone || null }))
}

function findByLogin(login) {
  return mapRow(stmts.findByLogin.get(login))
}

function findByPhone(phone) {
  return mapRow(stmts.findByPhone.get(phone))
}

function getAll() {
  return stmts.getAll.all().map(mapRow)
}

function getAllWithPhone() {
  return stmts.getAllWithPhone.all().map(mapRow)
}

function deleteById(id) {
  const info = stmts.deleteById.run(id)
  return info.changes > 0
}

function deleteByLogin(login) {
  const test = findByLogin(login)
  if (!test) return null
  stmts.deleteByLogin.run(login)
  return test
}

function deleteByPhone(phone) {
  const test = findByPhone(phone)
  if (!test) return null
  stmts.deleteByPhone.run(phone)
  return test
}

function deleteAll() {
  const all = getAllWithPhone()
  stmts.deleteAll.run()
  return all
}

function isExpired(test) {
  if (!test) return true
  return new Date(test.expiresAt).getTime() <= Date.now()
}

module.exports = {
  create, latestFor, findByLogin, findByPhone, getAll,
  getAllWithPhone, deleteById, deleteByLogin, deleteByPhone, deleteAll, isExpired
}

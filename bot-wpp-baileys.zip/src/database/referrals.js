const db = require('./init')
const crypto = require('crypto')

const stmts = {
  getConfig: db.prepare(`SELECT * FROM referral_config WHERE id = 1`),
  updateConfig: db.prepare(`
    UPDATE referral_config SET
      active = @active,
      required_count = @requiredCount,
      reward_days = @rewardDays,
      updated_at = @updatedAt
    WHERE id = 1
  `),
  insertReferral: db.prepare(`
    INSERT INTO referrals (id, referrer_phone, referee_phone, purchase_id, status, created_at, updated_at)
    VALUES (@id, @referrerPhone, @refereePhone, @purchaseId, @status, @createdAt, @updatedAt)
  `),
  countApproved: db.prepare(`
    SELECT COUNT(*) as total FROM referrals
    WHERE referrer_phone = ? AND status = 'approved'
  `),
  countRewards: db.prepare(`
    SELECT COUNT(*) as total FROM referral_rewards
    WHERE referrer_phone = ?
  `),
  insertReward: db.prepare(`
    INSERT INTO referral_rewards (id, referrer_phone, login, reward_days, awarded_at)
    VALUES (@id, @referrerPhone, @login, @rewardDays, @awardedAt)
  `),
  listByReferrer: db.prepare(`
    SELECT * FROM referrals WHERE referrer_phone = ?
    ORDER BY created_at DESC LIMIT ?
  `)
}

const nowIso = () => new Date().toISOString()

const mapConfig = (row) => {
  if (!row) return null
  return {
    active: Boolean(row.active),
    requiredCount: row.required_count,
    rewardDays: row.reward_days,
    updatedAt: row.updated_at
  }
}

const mapReferral = (row) => {
  if (!row) return null
  return {
    id: row.id,
    referrerPhone: row.referrer_phone,
    refereePhone: row.referee_phone,
    purchaseId: row.purchase_id || null,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

const generateId = () => crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex')

function getConfig() {
  return mapConfig(stmts.getConfig.get())
}

function setConfig({ active, requiredCount, rewardDays }) {
  stmts.updateConfig.run({
    active: active ? 1 : 0,
    requiredCount: Number(requiredCount || 1),
    rewardDays: Number(rewardDays || 3),
    updatedAt: nowIso()
  })
  return getConfig()
}

function insertReferral({ referrerPhone, refereePhone, purchaseId, status }) {
  const now = nowIso()
  const id = generateId()
  stmts.insertReferral.run({
    id,
    referrerPhone,
    refereePhone,
    purchaseId: purchaseId || null,
    status,
    createdAt: now,
    updatedAt: now
  })
  return id
}

function countApprovedFor(referrerPhone) {
  return stmts.countApproved.get(referrerPhone)?.total || 0
}

function countRewardsFor(referrerPhone) {
  return stmts.countRewards.get(referrerPhone)?.total || 0
}

function insertReward({ referrerPhone, login, rewardDays }) {
  const id = generateId()
  const awardedAt = nowIso()
  stmts.insertReward.run({ id, referrerPhone, login: login || null, rewardDays, awardedAt })
  return { id, awardedAt }
}

function listByReferrer(referrerPhone, limit = 20) {
  return stmts.listByReferrer.all(referrerPhone, limit).map(mapReferral)
}

module.exports = {
  getConfig,
  setConfig,
  insertReferral,
  countApprovedFor,
  countRewardsFor,
  insertReward,
  listByReferrer
}


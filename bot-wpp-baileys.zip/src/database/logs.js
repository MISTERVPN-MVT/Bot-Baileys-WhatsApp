const db = require('./init')

const stmts = {
  insert: db.prepare(`
    INSERT INTO logs (type, message, data, created_at)
    VALUES (@type, @message, @data, @createdAt)
  `),
  getRecent: db.prepare(`SELECT * FROM logs ORDER BY created_at DESC LIMIT ?`),
  getByType: db.prepare(`SELECT * FROM logs WHERE type = ? ORDER BY created_at DESC LIMIT ?`),
  countByType: db.prepare(`SELECT COUNT(*) as total FROM logs WHERE type = ?`),
  clearByType: db.prepare(`DELETE FROM logs WHERE type = ?`)
}

function nowIso() {
  return new Date().toISOString()
}

function add(type, message, data = null) {
  stmts.insert.run({
    type,
    message,
    data: data ? JSON.stringify(data) : null,
    createdAt: nowIso()
  })
}

function getRecent(limit = 50) {
  return stmts.getRecent.all(limit).map(row => ({
    id: row.id,
    type: row.type,
    message: row.message,
    data: row.data ? JSON.parse(row.data) : null,
    createdAt: row.created_at
  }))
}

function getByType(type, limit = 50) {
  return stmts.getByType.all(type, limit).map(row => ({
    id: row.id,
    type: row.type,
    message: row.message,
    data: row.data ? JSON.parse(row.data) : null,
    createdAt: row.created_at
  }))
}

function countByType(type) {
  return stmts.countByType.get(type)?.total || 0
}

function clearByType(type) {
  return stmts.clearByType.run(type).changes || 0
}

module.exports = { add, getRecent, getByType, countByType, clearByType }

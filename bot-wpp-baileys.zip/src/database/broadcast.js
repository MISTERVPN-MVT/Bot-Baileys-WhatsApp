const db = require('./init')

const stmts = {
  insert: db.prepare(`
    INSERT OR IGNORE INTO broadcast_numbers (phone, jid, name, added_at)
    VALUES (@phone, @jid, @name, @addedAt)
  `),
  findByPhone: db.prepare(`SELECT * FROM broadcast_numbers WHERE phone = ?`),
  getAll: db.prepare(`SELECT * FROM broadcast_numbers ORDER BY added_at DESC`),
  deleteByPhone: db.prepare(`DELETE FROM broadcast_numbers WHERE phone = ?`),
  count: db.prepare(`SELECT COUNT(*) as total FROM broadcast_numbers`)
}

function nowIso() {
  return new Date().toISOString()
}

function mapRow(row) {
  if (!row) return null
  return {
    id: row.id,
    phone: row.phone,
    jid: row.jid,
    name: row.name,
    addedAt: row.added_at
  }
}

function add(data) {
  stmts.insert.run({
    phone: data.phone,
    jid: data.jid || null,
    name: data.name || null,
    addedAt: nowIso()
  })
  return findByPhone(data.phone)
}

function findByPhone(phone) {
  return mapRow(stmts.findByPhone.get(phone))
}

function getAll() {
  return stmts.getAll.all().map(mapRow)
}

function remove(phone) {
  const info = stmts.deleteByPhone.run(phone)
  return info.changes > 0
}

function count() {
  return stmts.count.get().total
}

function getAllPhones() {
  return getAll().map(n => n.phone)
}

module.exports = { add, findByPhone, getAll, remove, count, getAllPhones }

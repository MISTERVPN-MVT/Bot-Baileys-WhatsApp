const db = require('./init')

const stmts = {
  upsert: db.prepare(`
    INSERT INTO promo_plans (id, label, amount, limit_count, days, starts_at, ends_at, active, created_at, updated_at)
    VALUES (@id, @label, @amount, @limitCount, @days, @startsAt, @endsAt, @active, @createdAt, @updatedAt)
    ON CONFLICT(id) DO UPDATE SET
      label = excluded.label,
      amount = excluded.amount,
      limit_count = excluded.limit_count,
      days = excluded.days,
      starts_at = excluded.starts_at,
      ends_at = excluded.ends_at,
      active = excluded.active,
      updated_at = excluded.updated_at
  `),
  findById: db.prepare(`SELECT * FROM promo_plans WHERE id = ?`),
  listAll: db.prepare(`SELECT * FROM promo_plans ORDER BY created_at DESC`),
  listActiveNow: db.prepare(`
    SELECT * FROM promo_plans
    WHERE active = 1
      AND (starts_at IS NULL OR starts_at <= @now)
      AND (ends_at IS NULL OR ends_at >= @now)
    ORDER BY amount ASC
  `)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return {
    id: row.id,
    label: row.label,
    amount: row.amount,
    limit: row.limit_count,
    days: row.days,
    startsAt: row.starts_at || null,
    endsAt: row.ends_at || null,
    active: Boolean(row.active),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

function upsert(data) {
  const now = nowIso()
  stmts.upsert.run({
    id: data.id,
    label: data.label,
    amount: data.amount,
    limitCount: data.limit || data.limitCount,
    days: data.days,
    startsAt: data.startsAt || null,
    endsAt: data.endsAt || null,
    active: data.active ? 1 : 0,
    createdAt: data.createdAt || now,
    updatedAt: now
  })
  return findById(data.id)
}

function findById(id) {
  return mapRow(stmts.findById.get(id))
}

function listAll() {
  return stmts.listAll.all().map(mapRow)
}

function listActiveNow(now = null) {
  const at = now || nowIso()
  return stmts.listActiveNow.all({ now: at }).map(mapRow)
}

module.exports = { upsert, findById, listAll, listActiveNow }


const db = require('./init')
const crypto = require('crypto')

const STATUSES = {
  PENDING: 'pending',
  RUNNING: 'running',
  COMPLETED: 'completed',
  FAILED: 'failed',
  CANCELLED: 'cancelled'
}

const stmts = {
  insert: db.prepare(`
    INSERT INTO broadcast_jobs (
      id, segment, type, text, media, media_type, mimetype, template_id,
      scheduled_at, status, error_message, total, sent, failed, started_at, finished_at, created_at, updated_at
    ) VALUES (
      @id, @segment, @type, @text, @media, @mediaType, @mimetype, @templateId,
      @scheduledAt, @status, @errorMessage, @total, @sent, @failed, @startedAt, @finishedAt, @createdAt, @updatedAt
    )
  `),
  updateStatus: db.prepare(`
    UPDATE broadcast_jobs SET
      status = @status,
      error_message = @errorMessage,
      total = @total,
      sent = @sent,
      failed = @failed,
      started_at = @startedAt,
      finished_at = @finishedAt,
      updated_at = @updatedAt
    WHERE id = @id
  `),
  findById: db.prepare(`SELECT * FROM broadcast_jobs WHERE id = ?`),
  listDuePending: db.prepare(`
    SELECT * FROM broadcast_jobs
    WHERE status = 'pending' AND scheduled_at <= ?
    ORDER BY scheduled_at ASC
    LIMIT ?
  `),
  listRecent: db.prepare(`SELECT * FROM broadcast_jobs ORDER BY created_at DESC LIMIT ?`)
}

const nowIso = () => new Date().toISOString()

const mapRow = (row) => {
  if (!row) return null
  return {
    id: row.id,
    segment: row.segment,
    type: row.type,
    text: row.text || '',
    media: row.media || null,
    mediaType: row.media_type || null,
    mimetype: row.mimetype || null,
    templateId: row.template_id || null,
    scheduledAt: row.scheduled_at,
    status: row.status,
    errorMessage: row.error_message || null,
    total: row.total || 0,
    sent: row.sent || 0,
    failed: row.failed || 0,
    startedAt: row.started_at || null,
    finishedAt: row.finished_at || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  }
}

const generateId = () => crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString('hex')

function create(data) {
  const now = nowIso()
  const id = generateId()
  stmts.insert.run({
    id,
    segment: data.segment,
    type: data.type,
    text: data.text || null,
    media: data.media || null,
    mediaType: data.mediaType || null,
    mimetype: data.mimetype || null,
    templateId: data.templateId || null,
    scheduledAt: data.scheduledAt,
    status: STATUSES.PENDING,
    errorMessage: null,
    total: 0,
    sent: 0,
    failed: 0,
    startedAt: null,
    finishedAt: null,
    createdAt: now,
    updatedAt: now
  })
  return findById(id)
}

function updateStatus(id, changes) {
  const current = findById(id)
  if (!current) return null
  const updated = { ...current, ...changes, updatedAt: nowIso() }
  stmts.updateStatus.run({
    id,
    status: updated.status,
    errorMessage: updated.errorMessage || null,
    total: updated.total || 0,
    sent: updated.sent || 0,
    failed: updated.failed || 0,
    startedAt: updated.startedAt || null,
    finishedAt: updated.finishedAt || null,
    updatedAt: updated.updatedAt
  })
  return findById(id)
}

function findById(id) {
  return mapRow(stmts.findById.get(id))
}

function listDuePending(limit = 3) {
  return stmts.listDuePending.all(nowIso(), limit).map(mapRow)
}

function listRecent(limit = 10) {
  return stmts.listRecent.all(limit).map(mapRow)
}

module.exports = { STATUSES, create, updateStatus, findById, listDuePending, listRecent }


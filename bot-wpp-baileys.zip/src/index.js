const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys')
const path = require('path')
const fs = require('fs')

const config = require('./config')
const { plans, purchases, accesses, users, lidMap, blocked, customerProfiles } = require('./database')
const { sendButtons } = require('./utils/buttons')
const { sendText, unwrapMessage, extractText, extractButton, messageTimestampMs } = require('./utils/messages')
const { normalizeText, baseJid, numericJid, extractPhoneDigits, isValidPhone, isLidJid, extractLid } = require('./utils/helpers')

const testService = require('./services/testService')
const purchaseService = require('./services/purchaseService')
const supportService = require('./services/supportService')
const renewService = require('./services/renewService')
const adminService = require('./services/adminService')
const broadcastService = require('./services/broadcastService')
const broadcastReceiptService = require('./services/broadcastReceiptService')
const historyService = require('./services/historyService')
const automationService = require('./services/automationService')
const broadcastSchedulerService = require('./services/broadcastSchedulerService')
const broadcastMetricsService = require('./services/broadcastMetricsService')
const maintenanceService = require('./services/maintenanceService')
const faqService = require('./services/faqService')
const accessStatusService = require('./services/accessStatusService')
const antiAbuseService = require('./services/antiAbuseService')
const settingsService = require('./services/settingsService')
const textTemplateService = require('./services/textTemplateService')
const menuStandbyService = require('./services/menuStandbyService')

const MAX_MESSAGE_AGE_MS = 15 * 60 * 1000
const AUTH_PATH = path.join(__dirname, '..', 'auth')
const MAX_PAIRING_ATTEMPTS = 5

let pairingAttempts = 0
let currentSock = null

const BUTTON_IDS = {
  CREATE_TEST: 'create_test',
  BUY_VIP: 'buy_vip',
  BUY_RESELL: 'buy_resell',
  OTHER_OPTIONS: 'other_options',
  SUPPORT: 'support',
  BACK_MENU: 'back_menu',
  RENEW_ACCESS: 'renew_access',
  HISTORY: 'history',
  FAQ: 'faq',
  CHECK_ACCESS: 'check_access',
  DOWNLOAD_APP: 'download_app'
}

const messageQueues = new Map()

function enqueueMessage(key, task) {
  const prev = messageQueues.get(key) || Promise.resolve()
  const next = prev.then(task).catch(err => console.error(err))
  messageQueues.set(key, next)
  return next
}

function isAdmin(id) {
  const digits = (id || '').replace(/\D/g, '')
  return digits === config.adminNumber || `55${digits}` === config.adminNumber
}

function shouldAutoBlock(phone, admin) {
  if (admin) return false
  const res = antiAbuseService.recordIncoming(phone)
  if (!res?.blocked) return false
  return true
}

function resolvePhoneFromKey(key) {
  const altJid = key?.remoteJidAlt || key?.participantAlt
  const fromAlt = extractPhoneDigits(altJid)
  if (isValidPhone(fromAlt)) return fromAlt

  const participant = key?.participant
  const fromParticipant = extractPhoneDigits(participant)
  if (isValidPhone(fromParticipant) && !isLidJid(participant)) return fromParticipant

  const remote = key?.remoteJid
  const fromRemote = extractPhoneDigits(remote)
  if (isValidPhone(fromRemote) && !isLidJid(remote)) return fromRemote

  return null
}

async function resolvePhoneNumber(sock, key) {
  const fromKey = resolvePhoneFromKey(key)
  if (fromKey) return fromKey

  const lid = extractLid(key?.remoteJid)
  if (!lid) return numericJid(key?.remoteJid)

  const fromMap = lidMap.getPhone(lid)
  if (fromMap) return fromMap

  const lidMapping = sock?.signalRepository?.lidMapping
  const getPNForLID = lidMapping?.getPNForLID
  if (!getPNForLID) return numericJid(key?.remoteJid)

  try {
    const pn = await getPNForLID(key.remoteJid)
    const phone = extractPhoneDigits(pn)
    if (!isValidPhone(phone)) return numericJid(key?.remoteJid)
    lidMap.save(lid, phone)
    return phone
  } catch {
    return numericJid(key?.remoteJid)
  }
}

async function maybeSendTutorial(sock, jid, phone, admin) {
  if (admin) return false
  if (!phone) return false

  const profile = customerProfiles.findByPhone(phone) || customerProfiles.ensure(phone)
  if (profile.tutorialSeenAt) return false

  await sendText(sock, jid, [
    '👋 *Primeiro acesso*',
    '',
    '1) Envie *menu* para ver as opções',
    '2) Clique em *Criar teste* para testar',
    '3) Clique em *Comprar VIP* para adquirir',
    '4) Clique em *Comprar Revenda* para adquirir painel',
    '5) Clique em *Outras opções* para histórico, suporte, FAQ e verificação',
    '',
    '📩 Se precisar, use *Suporte*.'
  ].join('\n'))
  customerProfiles.setTutorialSeen(phone)
  return true
}

const safeTs = (value) => {
  const ts = new Date(value).getTime()
  if (!Number.isFinite(ts)) return null
  return ts
}

const computePurchaseExpiresAt = (purchase) => {
  const base = purchase?.completedAt || purchase?.createdAt
  const ts = safeTs(base)
  if (ts == null) return null
  const dt = new Date(ts)
  dt.setDate(dt.getDate() + Number(purchase.days || 0))
  return dt.toISOString()
}

const isActiveExpiresAt = (expiresAt) => {
  const ts = safeTs(expiresAt)
  if (ts == null) return false
  return ts > Date.now()
}

const hasActiveAccess = (phone) => {
  if (!phone) return false
  const accessActive = isActiveExpiresAt(accesses.findLatestByPhone(phone)?.expiresAt)
  if (accessActive) return true
  const purchaseExpiresAt = computePurchaseExpiresAt(purchases.findCompletedByPhone(phone))
  return isActiveExpiresAt(purchaseExpiresAt)
}

async function sendOtherOptionsMenu(sock, jid, phone, admin) {
  const latestPurchase = purchases.findCompletedByPhone(phone)
  const canRenew = admin || renewService.canRenew(latestPurchase)
  const buttons = [
    canRenew ? { id: BUTTON_IDS.RENEW_ACCESS, text: '🔄 RENOVAR' } : null,
    { id: BUTTON_IDS.HISTORY, text: '🧾 HISTÓRICO' },
    { id: BUTTON_IDS.FAQ, text: '❓ FAQ' },
    { id: BUTTON_IDS.SUPPORT, text: '📩 SUPORTE' },
    { id: BUTTON_IDS.CHECK_ACCESS, text: '✅ VERIFICAR ACESSO' },
    { id: BUTTON_IDS.DOWNLOAD_APP, text: '📲 BAIXAR APP' },
    { id: BUTTON_IDS.BACK_MENU, text: '◀️ VOLTAR' }
  ].filter(Boolean)

  await sendButtons(sock, jid, {
    text: [
      '📌 *OUTRAS OPÇÕES*',
      '',
      '_Este é um bot de atendimento automático, veja estas opções:_'
    ].join('\n'),
    footer: 'Author: @vpnmasternet',
    buttons
  })
}

async function sendMenu(sock, jid, name, phone, admin) {
  const displayName = name || 'usuário'

  await maybeSendTutorial(sock, jid, phone, admin)

  const text = textTemplateService.render(textTemplateService.KEYS.MENU_WELCOME, { '{name}': displayName })
  await sendButtons(sock, jid, {
    text,
    footer: 'Author: @vpnmasternet',
    buttons: [
      { id: BUTTON_IDS.CREATE_TEST, text: '🧪 CRIAR TESTE' },
      { id: BUTTON_IDS.BUY_VIP, text: '💎 COMPRAR LOGIN' },
      { id: BUTTON_IDS.BUY_RESELL, text: '🛒 COMPRAR REVENDA' },
      { id: BUTTON_IDS.OTHER_OPTIONS, text: '➕ OUTRAS OPÇÕES' }
    ]
  })

  const standbyKey = phone || jid
  menuStandbyService.setStandby(standbyKey)
}

function shouldSendMenu({ canAutoMenu, hasText, explicitMenu, standbyKey, now }) {
  if (!canAutoMenu) return false
  if (!hasText) return false
  if (explicitMenu) return true
  const inStandby = menuStandbyService.isInStandby(standbyKey, now)
  if (inStandby) return false
  return true
}

async function handleButtonClick({ sock, jid, button, name, phone, admin }) {
  const supportHandled = await supportService.handleAdminButton({ sock, button })
  if (supportHandled) return true

  const adminHandled = await adminService.handleAdminButton({ sock, buttonId: button.id })
  if (adminHandled) return true

  const faqHandled = await faqService.handleFaqButton({ sock, jid, buttonId: button.id })
  if (faqHandled) return true

  if (button.id.startsWith('renew_confirm_')) {
    const purchaseId = button.id.replace('renew_confirm_', '')
    const purchase = require('./database').purchases.findById(purchaseId)
    if (purchase) {
      await renewService.processRenewal({ sock, jid, purchase, phone })
      return true
    }
  }

  const actions = {
    [BUTTON_IDS.CREATE_TEST]: () => testService.createTest({ sock, jid, name, phone, isAdmin: admin }),
    [BUTTON_IDS.BUY_VIP]: () => purchaseService.sendPlansMenu(sock, jid, BUTTON_IDS.BACK_MENU),
    [BUTTON_IDS.BUY_RESELL]: () => sendText(sock, jid, `🛒 *COMPRAR REVENDA*\n\nAcesse nosso site e compre seu usuário ou painel da Masternet VPN.\n⚡️ Processo 100% automático e liberação imediata após o pagamento.\n🌐 vpnmasternet.com.br`),
    [BUTTON_IDS.OTHER_OPTIONS]: () => sendOtherOptionsMenu(sock, jid, phone, admin),
    [BUTTON_IDS.SUPPORT]: () => supportService.requestSupport({ sock, jid, phone, name }),
    [BUTTON_IDS.BACK_MENU]: () => sendMenu(sock, jid, name, phone, admin),
    [BUTTON_IDS.RENEW_ACCESS]: () => renewService.handleRenewButton({ sock, jid, phone, isAdmin: admin }),
    [BUTTON_IDS.HISTORY]: () => sendText(sock, jid, historyService.buildHistoryMessage(phone)),
    [BUTTON_IDS.CHECK_ACCESS]: () => accessStatusService.checkAccess({ sock, jid, phone }),
    [BUTTON_IDS.DOWNLOAD_APP]: () => sendText(sock, jid, `📲 App: ${settingsService.getAppLink()}`)
  }

  const action = actions[button.id]
  if (action) {
    const result = await action()
    if (result?.waitingForLogin) {
      adminService.setAwaitingRenewLogin(true)
    }
    return true
  }

  const planHandled = await purchaseService.handlePlanSelection({
    sock, jid, planId: button.id, name, phone, backButtonId: BUTTON_IDS.BACK_MENU
  })
  if (planHandled) return true

  return false
}

async function handleAdminCommands({ sock, text, admin }) {
  if (!admin) return false

  if (adminService.isAdminCommand(text)) {
    await adminService.showAdminPanel(sock)
    return true
  }

  const supHandled = await supportService.handleAdminCommand({ sock, text })
  if (supHandled) return true

  if (adminService.isAwaitingInput()) {
    const testHandled = await adminService.handleTestInput({ sock, text })
    if (testHandled) return true

    const vipHandled = await adminService.handleVipInput({ sock, text })
    if (vipHandled) return true

    const textHandled = await adminService.handleTextInput({ sock, text })
    if (textHandled) return true

    if (adminService.isAwaitingRenewLogin()) {
      adminService.setAwaitingRenewLogin(false)
      await renewService.handleAdminRenewLogin({ sock, jid: `${config.adminNumber}@s.whatsapp.net`, login: text.trim() })
      return true
    }
  }

  return false
}

async function handleBroadcastFlow({ sock, admin, content, trimmed, button }) {
  if (!admin) return false
  if (!broadcastService.isAwaitingInput()) return false

  const state = broadcastService.getState()

  const buttonId = button?.id || null
  const isBroadcastButton = buttonId?.startsWith('broadcast_')
  const handledButton = isBroadcastButton ? await broadcastService.handleButton({ sock, buttonId }) : false
  if (handledButton) return true

  if (state.stage === 'awaiting_media') {
    await broadcastService.handleMediaInput({ sock, message: content })
    return true
  }

  const handledText = trimmed ? await broadcastService.handleTextInput({ sock, text: trimmed }) : false
  if (handledText) return true

  return false
}

function registerLidMappingHandler(sock) {
  sock.ev.on('lid-mapping.update', mappings => {
    for (const [lid, pn] of Object.entries(mappings)) {
      const phone = extractPhoneDigits(pn)
      if (isValidPhone(phone)) {
        lidMap.save(extractLid(lid) || lid, phone)
      }
    }
  })
}

function registerReceiptHandlers(sock) {
  sock.ev.on('message-receipt.update', updates => {
    broadcastReceiptService.handleReceiptUpdates(updates)
  })
}

function registerMessageHandlers(sock) {
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify' && type !== 'append') return
    if (!Array.isArray(messages) || !messages.length) return

    const now = Date.now()

    for (const incoming of messages) {
      if (!incoming?.message) continue
      const jid = baseJid(incoming.key.remoteJid)
      if (incoming.key.fromMe) continue
      if (jid === 'status@broadcast') continue

      const timestampMs = messageTimestampMs(incoming)
      if (timestampMs && now - timestampMs > MAX_MESSAGE_AGE_MS) continue

      const phone = await resolvePhoneNumber(sock, incoming.key)
      const queueKey = phone || jid
      const name = incoming.pushName || ''

      await enqueueMessage(queueKey, async () => {
        const admin = isAdmin(phone || jid)

        if (shouldAutoBlock(phone, admin)) return

        if (phone && !admin) {
          broadcastMetricsService.recordReply(phone)
        }

        if (!admin && blocked.isBlocked(phone)) return

        const supportOpen = supportService.hasOpenSupport(phone)
        if (supportOpen && !admin) return

        users.remember({ jid, name, phone })

        const content = unwrapMessage(incoming.message)
        const text = extractText(content)
        const trimmed = (text || '').trim()
        const normalized = normalizeText(trimmed)
        const firstWord = normalized.split(' ')[0] || ''
        const explicitMenu = firstWord === 'menu'
        const hasText = normalized.length > 0
        const button = extractButton(content)

        const broadcastHandled = await handleBroadcastFlow({ sock, admin, content, trimmed, button })
        if (broadcastHandled) return

        const adminHandled = await handleAdminCommands({ sock, text: trimmed, admin })
        if (adminHandled) return

        if (button) {
          const buttonHandled = await handleButtonClick({ sock, jid, button, name, phone, admin })
          if (buttonHandled) return
        }

        const purchaseHandled = await purchaseService.handleText({ sock, jid, text: trimmed, phone })
        if (purchaseHandled) return

        const purchaseAwaiting = typeof purchaseService.isAwaitingInput === 'function'
          ? Boolean(purchaseService.isAwaitingInput(phone))
          : false

        const canAutoMenu =
          !button &&
          !adminService.isAwaitingInput() &&
          !broadcastService.isAwaitingInput() &&
          !supportService.hasOpenSupport(phone) &&
          !purchaseAwaiting

        const standbyKey = phone || jid
        const shouldMenu = shouldSendMenu({
          canAutoMenu,
          hasText,
          explicitMenu,
          standbyKey,
          now
        })

        if (shouldMenu) {
          await sendMenu(sock, jid, name, phone, admin)
          return
        }
      })
    }
  })
}

function clearAuth() {
  if (!fs.existsSync(AUTH_PATH)) return
  console.log('\n🗑️  Removendo autenticação antiga...')
  try {
    const files = fs.readdirSync(AUTH_PATH)
    for (const file of files) {
      fs.unlinkSync(path.join(AUTH_PATH, file))
    }
    console.log('✅ Autenticação removida com sucesso!')
  } catch (err) {
    console.error('❌ Erro ao remover auth:', err.message)
  }
}

function ensureAuthDir() {
  if (!fs.existsSync(AUTH_PATH)) {
    fs.mkdirSync(AUTH_PATH, { recursive: true })
  }
}

function hasValidCredentials() {
  const credsPath = path.join(AUTH_PATH, 'creds.json')
  return fs.existsSync(credsPath)
}

async function requestPairingCode(sock) {
  if (pairingAttempts >= MAX_PAIRING_ATTEMPTS) {
    console.log('\n╔════════════════════════════════════════════════════╗')
    console.log('║  ❌ MÁXIMO DE TENTATIVAS ATINGIDO (5)              ║')
    console.log('║                                                    ║')
    console.log('║  Para evitar banimento, o bot foi pausado.        ║')
    console.log('║  Aguarde alguns minutos antes de tentar novamente.║')
    console.log('╚════════════════════════════════════════════════════╝')
    process.exit(1)
  }

  pairingAttempts++

  console.log(`\n📱 Tentativa de pareamento: ${pairingAttempts}/${MAX_PAIRING_ATTEMPTS}`)
  console.log(`📞 Número do bot: ${config.botNumber}`)

  await new Promise(resolve => setTimeout(resolve, 5000))

  try {
    const code = await sock.requestPairingCode(config.botNumber)

    console.log('\n╔════════════════════════════════════════════════════╗')
    console.log('║           📲 CÓDIGO DE PAREAMENTO                  ║')
    console.log('╠════════════════════════════════════════════════════╣')
    console.log(`║                    ${code}                        ║`)
    console.log('╠════════════════════════════════════════════════════╣')
    console.log('║  1. Abra o WhatsApp no celular                    ║')
    console.log('║  2. Vá em: Configurações > Dispositivos Conectados ║')
    console.log('║  3. Toque em "Conectar um dispositivo"            ║')
    console.log('║  4. Toque em "Conectar com número de telefone"    ║')
    console.log('║  5. Digite o código acima                         ║')
    console.log('╠════════════════════════════════════════════════════╣')
    console.log('║  ⏳ Você tem 60 segundos para digitar o código    ║')
    console.log('╚════════════════════════════════════════════════════╝\n')
  } catch (error) {
    console.error('❌ Erro ao solicitar código:', error.message)
  }
}

function registerConnectionHandlers(sock) {
  sock.ev.on('connection.update', async update => {
    const { connection, lastDisconnect } = update

    if (connection === 'connecting') {
      console.log('🔌 Conectando ao WhatsApp...')
    }

    if (connection === 'close') {
      const statusCode = lastDisconnect?.error?.output?.statusCode
      const reason = lastDisconnect?.error?.output?.payload?.message || 'Desconhecido'

      console.log(`\n⚠️  Conexão fechada`)
      console.log(`   Código: ${statusCode}`)
      console.log(`   Motivo: ${reason}`)

      const isLoggedOut = statusCode === DisconnectReason.loggedOut
      const isUnauthorized = statusCode === 401 || statusCode === 403
      const isBadSession = statusCode === DisconnectReason.badSession
      const isConnectionFailure = statusCode === 405 || statusCode === 408 || statusCode === 500 || statusCode === 515

      if (isConnectionFailure) {
        console.log('\n⚠️  Código de pareamento expirou ou falha na conexão.')
        console.log('   Aguardando para tentar novamente...')

        if (pairingAttempts >= MAX_PAIRING_ATTEMPTS) {
          console.log('\n╔════════════════════════════════════════════════════╗')
          console.log('║  ❌ MÁXIMO DE TENTATIVAS ATINGIDO (5)              ║')
          console.log('║                                                    ║')
          console.log('║  Para evitar banimento, o bot foi pausado.        ║')
          console.log('║  Aguarde alguns minutos antes de tentar novamente.║')
          console.log('╚════════════════════════════════════════════════════╝')
          process.exit(1)
        }

        console.log('🔄 Tentando novamente em 10 segundos...\n')
        await new Promise(resolve => setTimeout(resolve, 10000))
        startBot()
        return
      }

      if (isLoggedOut || isUnauthorized || isBadSession) {
        console.log('\n🔒 Sessão inválida ou expirada.')
        clearAuth()
        ensureAuthDir()
        pairingAttempts = 0
        console.log('🔄 Reiniciando bot...\n')
        await new Promise(resolve => setTimeout(resolve, 3000))
        startBot()
        return
      }

      console.log('🔄 Reconectando em 5 segundos...')
      await new Promise(resolve => setTimeout(resolve, 5000))
      startBot()
      return
    }

    if (connection === 'open') {
      pairingAttempts = 0
      console.log('\n╔════════════════════════════════════════════════════╗')
      console.log('║         ✅ BOT CONECTADO COM SUCESSO!              ║')
      console.log('╠════════════════════════════════════════════════════╣')
      console.log(`║  📱 Número: ${config.botNumber.padEnd(36)} ║`)
      console.log('║  🤖 Bot está online e pronto!                      ║')
      console.log('╚════════════════════════════════════════════════════╝\n')
    }
  })
}

async function createSocket() {
  ensureAuthDir()

  const { state, saveCreds } = await useMultiFileAuthState(AUTH_PATH)

  const sock = makeWASocket({
    auth: state,
    emitOwnEvents: false,
    printQRInTerminal: false
  })

  sock.ev.on('creds.update', saveCreds)
  currentSock = sock

  return sock
}

async function startBot() {
  console.log('\n🚀 Iniciando bot...')
  console.log(`📁 Pasta de autenticação: ${AUTH_PATH}`)

  plans.seedDefaults()

  const sock = await createSocket()

  registerConnectionHandlers(sock)
  registerLidMappingHandler(sock)
  registerReceiptHandlers(sock)
  registerMessageHandlers(sock)
  purchaseService.startPaymentWatcher(sock)
  automationService.start(sock)
  broadcastSchedulerService.start(sock)
  maintenanceService.start(sock)

  const hasCredentials = hasValidCredentials()

  if (!hasCredentials) {
    console.log('\n🆕 Nenhuma credencial encontrada!')
    console.log('📲 Iniciando processo de pareamento...')
    await requestPairingCode(sock)
    return
  }

  console.log('📂 Credenciais encontradas, conectando...')
}

startBot().catch(err => {
  console.error('❌ Erro fatal:', err.message)
  process.exit(1)
})

const { broadcastJobs, broadcastEvents } = require('../database')
const { sendText } = require('../utils/messages')
const { formatSpDate } = require('../utils/helpers')
const { executeBroadcast, phonesForSegment } = require('./broadcastExecutor')
const config = require('../config')

const adminJid = `${config.adminNumber}@s.whatsapp.net`
const POLL_EVERY_MS = 60 * 1000

const nowIso = () => new Date().toISOString()

const segmentLabel = (segment) => {
  const labels = { all: 'Todos', active: 'Ativos', expired: 'Expirados' }
  return labels[segment] || 'Todos'
}

let running = false

async function runOnce(sock) {
  if (running) return
  running = true

  const due = broadcastJobs.listDuePending(3)
  for (const job of due) {
    const startedAt = nowIso()
    broadcastJobs.updateStatus(job.id, { status: broadcastJobs.STATUSES.RUNNING, startedAt })
    const total = phonesForSegment(job.segment).length

    try {
      await sendText(sock, adminJid, [
        '📅 *Broadcast agendado iniciando*',
        '',
        `> ID: *${job.id}*`,
        `> Público: *${segmentLabel(job.segment)}*`,
        `> Total: *${total}*`,
        `> Data: _${formatSpDate(job.scheduledAt)}_`
      ].join('\n'), false)

      const result = await executeBroadcast({
        sock,
        segment: job.segment,
        type: job.type,
        text: job.text,
        mediaBuffer: job.media,
        mediaType: job.mediaType,
        mimetype: job.mimetype,
        broadcastId: job.id
      })

      const finishedAt = nowIso()
      broadcastJobs.updateStatus(job.id, {
        status: broadcastJobs.STATUSES.COMPLETED,
        total: result.total,
        sent: result.sent,
        failed: result.failed,
        finishedAt
      })

      const replies = broadcastEvents.countByKind(job.id, 'reply')
      const delivered = broadcastEvents.countByKind(job.id, 'delivered')
      const read = broadcastEvents.countByKind(job.id, 'read')

      await sendText(sock, adminJid, [
        '✅ *Broadcast agendado concluído*',
        '',
        `> ID: *${job.id}*`,
        `> Público: *${segmentLabel(job.segment)}*`,
        `> 📤 Enviados: *${result.sent}*`,
        `> ❌ Falhas: *${result.failed}*`,
        `> 💬 Respostas: *${replies}*`,
        `> 📬 Entregues: *${delivered}*`,
        `> 👁️ Lidas: *${read}*`,
        `> 📊 Total: *${result.total}*`,
        `> ⏱️ Tempo: *${result.duration}s*`
      ].join('\n'), false)
    } catch (error) {
      const finishedAt = nowIso()
      broadcastJobs.updateStatus(job.id, {
        status: broadcastJobs.STATUSES.FAILED,
        errorMessage: error?.message || 'Erro desconhecido',
        finishedAt
      })

      await sendText(sock, adminJid, [
        '❌ *Broadcast agendado falhou*',
        '',
        `> ID: *${job.id}*`,
        `> Erro: _${error?.message || 'desconhecido'}_`
      ].join('\n'), false)
    }
  }

  running = false
}

function start(sock) {
  setInterval(() => runOnce(sock).catch(() => {}), POLL_EVERY_MS)
}

module.exports = { start, runOnce }

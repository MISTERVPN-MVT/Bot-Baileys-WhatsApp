const { customerProfiles, blocked, logs } = require('../database')

const WINDOW_MS = 60 * 1000
const MAX_MESSAGES_PER_WINDOW = 35
const AUTO_BLOCK_SCORE = 3

const buckets = new Map()

const nextBucket = (current, now) => {
  if (!current) return { startMs: now, count: 1 }
  const expired = now - current.startMs > WINDOW_MS
  if (expired) return { startMs: now, count: 1 }
  return { startMs: current.startMs, count: current.count + 1 }
}

function recordIncoming(phone) {
  if (!phone) return { ok: true, blocked: false }
  const now = Date.now()
  const updated = nextBucket(buckets.get(phone), now)
  buckets.set(phone, updated)
  if (updated.count <= MAX_MESSAGES_PER_WINDOW) return { ok: true, blocked: false }

  const profile = customerProfiles.incrementSuspicious(phone, 1)
  logs.add('security', 'suspicious_rate_limit', { phone, count: updated.count, score: profile.suspiciousScore })
  if (profile.suspiciousScore < AUTO_BLOCK_SCORE) return { ok: true, blocked: false }

  blocked.block(phone, 'Auto-block: spam')
  logs.add('security', 'auto_block', { phone, reason: 'spam' })
  return { ok: true, blocked: true }
}

module.exports = { recordIncoming }


const { systemState } = require('../database')
const config = require('../config')

const isNonEmpty = (value) => Boolean(String(value || '').trim())

const getText = (key) => {
  const value = systemState.get(key)
  return isNonEmpty(value) ? String(value).trim() : null
}

function getAppLink() {
  return getText('app_link') || config.appLink
}

function setAppLink(value) {
  const next = String(value || '').trim()
  if (!next) return { ok: false, error: 'Link inválido.' }
  systemState.set('app_link', next)
  return { ok: true, value: next }
}

module.exports = { getAppLink, setAppLink }


const config = require('../config')
const { createPanelApi } = require('../utils/api')

const panelApi = createPanelApi(config.panelDomain, config.panelToken)

module.exports = panelApi

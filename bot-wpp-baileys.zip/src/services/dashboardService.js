const { purchases, renewals, accesses } = require('../database')
const { formatMoney, formatPhoneLink, formatSpDate } = require('../utils/helpers')

const SP_TZ = 'America/Sao_Paulo'
const DAY_MS = 24 * 60 * 60 * 1000

const spDateKey = (date) => {
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: SP_TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  })
  return fmt.format(date)
}

const keyToMs = (key) => new Date(`${key}T00:00:00-03:00`).getTime()

const dateKeyDaysAgo = (daysAgo) => {
  const dt = new Date(Date.now() - daysAgo * DAY_MS)
  return spDateKey(dt)
}

const inLastDays = (iso, days) => {
  const ts = new Date(iso).getTime()
  if (!Number.isFinite(ts)) return false
  const cutoffKey = dateKeyDaysAgo(days - 1)
  const cutoffMs = keyToMs(cutoffKey)
  if (!Number.isFinite(cutoffMs)) return false
  return ts >= cutoffMs
}

const addSum = (map, key, amount) => {
  const prev = map.get(key) || 0
  map.set(key, prev + Number(amount || 0))
}

const buildRevenueSeries = (days) => {
  const keys = Array.from({ length: days }, (_, i) => dateKeyDaysAgo(days - 1 - i))
  const map = new Map(keys.map(k => [k, 0]))
  return { keys, map }
}

const compactKey = (key) => {
  const parts = String(key || '').split('-')
  if (parts.length !== 3) return key
  return `${parts[2]}/${parts[1]}`
}

const daysLeft = (expiresAt) => {
  const ts = new Date(expiresAt).getTime()
  if (!Number.isFinite(ts)) return null
  const nowKey = spDateKey(new Date())
  const expKey = spDateKey(new Date(ts))
  const a = keyToMs(nowKey)
  const b = keyToMs(expKey)
  if (!Number.isFinite(a) || !Number.isFinite(b)) return null
  return Math.round((b - a) / DAY_MS)
}

const sumAmounts = (rows) => rows.reduce((acc, r) => acc + Number(r.amount || 0), 0)

const mergeEvents = (sales, ren) => [
  ...sales.map(p => ({ phone: p.phone, amount: p.amount, at: p.completedAt || p.createdAt, label: p.planLabel })),
  ...ren.map(r => ({ phone: r.phone, amount: r.amount, at: r.createdAt, label: r.planLabel || 'Renovação' }))
]

function buildDashboardMessage() {
  const allPurchases = purchases.getAll()
  const sales = allPurchases.filter(p => p.stage === 'completed' && p.completedAt)
  const recentRenewals = renewals.listRecent(1000)
  const events = mergeEvents(sales, recentRenewals)

  const last7 = events.filter(e => inLastDays(e.at, 7))
  const total7 = sumAmounts(last7)
  const count7 = last7.length

  const last30 = events.filter(e => inLastDays(e.at, 30))
  const total30 = sumAmounts(last30)
  const count30 = last30.length

  const { keys, map } = buildRevenueSeries(7)
  for (const ev of last7) {
    const key = spDateKey(new Date(ev.at))
    if (!map.has(key)) continue
    addSum(map, key, ev.amount)
  }

  const values = keys.map(k => map.get(k) || 0)
  const max = Math.max(...values, 1)
  const bars = keys.map(k => {
    const v = map.get(k) || 0
    const size = Math.round((v / max) * 10)
    const bar = '█'.repeat(size).padEnd(10, '░')
    return `• ${compactKey(k)} ${bar} ${formatMoney(v)}`
  })

  const totalsByPhone = new Map()
  for (const ev of last30) {
    addSum(totalsByPhone, ev.phone, ev.amount)
  }

  const top = Array.from(totalsByPhone.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([phone, amount], idx) => `${idx + 1}. _${formatPhoneLink(phone)}_ — *${formatMoney(amount)}*`)

  const expiring = accesses.listAll()
    .filter(a => daysLeft(a.expiresAt) === 3)
    .sort((a, b) => new Date(a.expiresAt).getTime() - new Date(b.expiresAt).getTime())
    .slice(0, 10)
    .map(a => `• *${a.login}* — _${formatPhoneLink(a.phone)}_ — expira _${formatSpDate(a.expiresAt)}_`)

  const expiringBlock = expiring.length ? expiring.join('\n') : '• Nenhum acesso expirando em 3 dias.'

  return [
    '📊 *DASHBOARD ADMIN*',
    '',
    `🧾 Vendas (7d): *${count7}* — ${formatMoney(total7)}`,
    `🧾 Vendas (30d): *${count30}* — ${formatMoney(total30)}`,
    '',
    '📈 *Faturamento (últimos 7 dias)*',
    ...bars,
    '',
    '🏆 *Top clientes (30d)*',
    top.length ? top.join('\n') : '• Nenhum cliente.',
    '',
    '⏳ *Expirando em 3 dias*',
    expiringBlock
  ].join('\n')
}

module.exports = { buildDashboardMessage }


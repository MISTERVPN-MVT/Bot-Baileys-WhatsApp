const { broadcastEvents } = require('../database')

const sinceIso = (hours) => new Date(Date.now() - hours * 60 * 60 * 1000).toISOString()

function recordReply(phone) {
  const recent = broadcastEvents.findLatestSentForPhone(phone, sinceIso(24))
  if (!recent) return false
  if (broadcastEvents.hasReply(recent.broadcastId, phone)) return false
  broadcastEvents.add({ broadcastId: recent.broadcastId, phone, kind: 'reply' })
  return true
}

module.exports = { recordReply }


const { coupons } = require('../database')
const { formatMoney, formatSpDate } = require('../utils/helpers')

const parseNumber = (value) => {
  const normalized = String(value || '').replace(',', '.')
  const num = Number(normalized)
  if (!Number.isFinite(num)) return null
  return num
}

const parseMaxUses = (value) => {
  const raw = String(value || '').trim()
  if (!raw) return null
  if (raw === '-') return null
  const num = Number(raw)
  if (!Number.isFinite(num)) return null
  if (num <= 0) return null
  return Math.floor(num)
}

const parseSpDateBoundaryIso = (dateOnly, boundary) => {
  const raw = String(dateOnly || '').trim()
  if (!raw) return null
  if (raw === '-') return null
  const isDateOnly = /^\d{4}-\d{2}-\d{2}$/.test(raw)
  if (!isDateOnly) return null
  const time = boundary === 'end' ? '23:59:59' : '00:00:00'
  const dt = new Date(`${raw}T${time}-03:00`)
  const ts = dt.getTime()
  if (!Number.isFinite(ts)) return null
  return dt.toISOString()
}

const parseIsoDate = (value, boundary = null) => {
  const raw = String(value || '').trim()
  if (!raw) return null
  if (raw === '-') return null
  const dateOnly = parseSpDateBoundaryIso(raw, boundary || 'end')
  if (dateOnly) return dateOnly
  const dt = new Date(raw)
  const ts = dt.getTime()
  if (!Number.isFinite(ts)) return null
  return dt.toISOString()
}

const couponKind = (raw) => {
  const v = String(raw || '').trim().toLowerCase()
  const map = { percent: 'percent', porcento: 'percent', fixed: 'fixed', fixo: 'fixed' }
  return map[v] || null
}

function createCouponFromAdminText(text) {
  const parts = String(text || '').trim().split(/\s+/).filter(Boolean)
  const [code, kindRaw, valueRaw, maxUsesRaw, expiresRaw] = parts
  if (!code || !kindRaw || !valueRaw) {
    return { ok: false, error: 'Formato: CODIGO TIPO VALOR [MAX] [VALIDADE YYYY-MM-DD]' }
  }

  const kind = couponKind(kindRaw)
  if (!kind) return { ok: false, error: 'TIPO inválido. Use percent ou fixed.' }

  const value = parseNumber(valueRaw)
  if (value == null) return { ok: false, error: 'VALOR inválido.' }

  const maxUses = parseMaxUses(maxUsesRaw)
  const expiresAt = parseIsoDate(expiresRaw, 'end')

  if (expiresRaw && expiresAt == null && String(expiresRaw).trim() !== '-') {
    return { ok: false, error: 'VALIDADE inválida. Use YYYY-MM-DD ou -' }
  }

  const coupon = coupons.upsert({
    code,
    kind,
    value,
    maxUses,
    expiresAt,
    active: true
  })

  return { ok: true, coupon }
}

function deleteCoupon(code) {
  const found = coupons.findByCode(code)
  if (!found) return { ok: false, error: 'Cupom não encontrado.' }
  const removed = coupons.remove(code)
  if (!removed) return { ok: false, error: 'Falha ao remover cupom.' }
  return { ok: true, code: found.code }
}

function listCoupons(limit = 10) {
  const all = coupons.listAll().slice(0, limit)
  const lines = all.map(c => {
    const uses = coupons.countUsages(c.code)
    const max = c.maxUses ? `${uses}/${c.maxUses}` : `${uses}/∞`
    const kindText = c.kind === 'percent' ? `${c.value}%` : formatMoney(c.value)
    const status = c.active ? 'ativo' : 'off'
    const exp = c.expiresAt ? formatSpDate(c.expiresAt) : 'sem validade'
    return `• *${c.code}* (${status}) — ${kindText} — usos ${max} — expira ${exp}`
  })
  return lines.length ? lines.join('\n') : '📭 Nenhum cupom cadastrado.'
}

module.exports = {
  createCouponFromAdminText,
  deleteCoupon,
  listCoupons
}

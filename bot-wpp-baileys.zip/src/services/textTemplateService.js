const { botTexts } = require('../database')
const settingsService = require('./settingsService')

const KEYS = {
  MENU_WELCOME: 'menu_welcome',
  TEST_ACTIVE: 'test_active',
  TEST_EXPIRED: 'test_expired',
  TEST_ERROR: 'test_error',
  TEST_CREATED: 'test_created',
  TEST_ADMIN_NOTIFY: 'test_admin_notify',
  PURCHASE_PLANS_MENU: 'purchase_plans_menu',
  PURCHASE_PLAN_SELECTED: 'purchase_plan_selected',
  PURCHASE_PIX_GENERATED: 'purchase_pix_generated',
  PURCHASE_PAYMENT_APPROVED: 'purchase_payment_approved',
  PURCHASE_ACCESS_CREATED: 'purchase_access_created',
  PURCHASE_PIX_EXPIRED: 'purchase_pix_expired',
  PURCHASE_PAYMENT_REJECTED: 'purchase_payment_rejected',
  PURCHASE_PAYMENT_REFUNDED: 'purchase_payment_refunded',
  PURCHASE_PIX_ERROR: 'purchase_pix_error',
  PURCHASE_ACCESS_ERROR: 'purchase_access_error',
  PURCHASE_ADMIN_START: 'purchase_admin_start',
  PURCHASE_ADMIN_COMPLETED: 'purchase_admin_completed',
  PURCHASE_ADMIN_REFUNDED: 'purchase_admin_refunded',
  PURCHASE_COUPON_APPLIED: 'purchase_coupon_applied',
  PURCHASE_COUPON_ERROR: 'purchase_coupon_error',
  FAQ_Q1: 'faq_q1',
  FAQ_Q2: 'faq_q2',
  FAQ_Q3: 'faq_q3',
  FAQ_Q4: 'faq_q4',
  FAQ_Q5: 'faq_q5'
}

const CATEGORIES = {
  MENU: 'menu',
  TEST: 'test',
  PURCHASE: 'purchase',
  FAQ: 'faq'
}

const CATEGORY_KEYS = {
  [CATEGORIES.MENU]: [KEYS.MENU_WELCOME],
  [CATEGORIES.TEST]: [
    KEYS.TEST_ACTIVE,
    KEYS.TEST_EXPIRED,
    KEYS.TEST_ERROR,
    KEYS.TEST_CREATED,
    KEYS.TEST_ADMIN_NOTIFY
  ],
  [CATEGORIES.PURCHASE]: [
    KEYS.PURCHASE_PLANS_MENU,
    KEYS.PURCHASE_PLAN_SELECTED,
    KEYS.PURCHASE_PIX_GENERATED,
    KEYS.PURCHASE_PAYMENT_APPROVED,
    KEYS.PURCHASE_ACCESS_CREATED,
    KEYS.PURCHASE_PIX_EXPIRED,
    KEYS.PURCHASE_PAYMENT_REJECTED,
    KEYS.PURCHASE_PAYMENT_REFUNDED,
    KEYS.PURCHASE_PIX_ERROR,
    KEYS.PURCHASE_ACCESS_ERROR,
    KEYS.PURCHASE_ADMIN_START,
    KEYS.PURCHASE_ADMIN_COMPLETED,
    KEYS.PURCHASE_ADMIN_REFUNDED,
    KEYS.PURCHASE_COUPON_APPLIED,
    KEYS.PURCHASE_COUPON_ERROR
  ],
  [CATEGORIES.FAQ]: [
    KEYS.FAQ_Q1,
    KEYS.FAQ_Q2,
    KEYS.FAQ_Q3,
    KEYS.FAQ_Q4,
    KEYS.FAQ_Q5
  ]
}

const DEFAULTS = {
  [KEYS.MENU_WELCOME]: [
    '🚀 *Bem-vindo(a), {name}!*',
    '',
    '_Este é um bot de atendimento automático, veja estas opções:_'
  ].join('\n'),
  [KEYS.TEST_ACTIVE]: [
    '⚠️ *Você já possui um teste ativo!*',
    '',
    '> 👤 Login: *{login}*',
    '> 🔑 Senha: *{password}*',
    '> 🆔 UUID: `{uuid}`',
    '> ⏰ Expira: _{expiresAt}_',
    '',
    '📲 App: {appLink}'
  ].join('\n'),
  [KEYS.TEST_EXPIRED]: [
    '⏰ *Seu teste expirou!*',
    '',
    '> _O período de teste chegou ao fim._',
    '',
    '✨ Gostou do serviço? Adquira seu *acesso VIP*!',
    '📲 _Estamos à disposição._'
  ].join('\n'),
  [KEYS.TEST_ERROR]: [
    '❌ *Erro ao criar teste*',
    '',
    '> _{error}_',
    '',
    '_Tente novamente em alguns instantes._'
  ].join('\n'),
  [KEYS.TEST_CREATED]: [
    '✅ *Teste criado com sucesso!*',
    '',
    '> 👤 Login: *{login}*',
    '> 🔑 Senha: *{password}*',
    '> 🆔 UUID: `{uuid}`',
    '> ⏱️ Duração: _{duration}_',
    '> ⏰ Expira: _{expiresAt}_',
    '',
    '📲 *Baixe o app:* {appLink}',
    '',
    '_Aproveite seu teste! Qualquer dúvida, estamos à disposição._'
  ].join('\n'),
  [KEYS.TEST_ADMIN_NOTIFY]: [
    '🧪 *Novo teste criado*',
    '',
    '> 👤 Nome: _{name}_',
    '> 📱 Número: _{phoneLink}_',
    '> 🔑 Login: *{login}*',
    '> ⏰ Expira: _{expiresAt}_'
  ].join('\n'),
  [KEYS.PURCHASE_PLANS_MENU]: [
    '💎 *PLANOS VIP DISPONÍVEIS*',
    '',
    '> _Escolha o plano ideal para você!_',
    '',
    '🔹 Conexão ilimitada',
    '🔹 Suporte prioritário',
    '🔹 Ativação instantânea',
    '',
    '_Selecione uma opção:_'
  ].join('\n'),
  [KEYS.PURCHASE_PLAN_SELECTED]: [
    '💎 *PLANO SELECIONADO*',
    '',
    '> Plano: *{planLabel}*',
    '',
    '📧 *Digite seu e-mail* para gerar o PIX:',
    '',
    '🎟️ Se tiver cupom, envie:',
    '> *CUPOM SEUCODIGO*',
    '',
    '_Ou envie qualquer texto para continuar_'
  ].join('\n'),
  [KEYS.PURCHASE_PIX_GENERATED]: [
    '✅ *PIX GERADO COM SUCESSO!*',
    '',
    '> 💎 Plano: *{planLabel}*',
    '> 💰 Valor: *{amount}*',
    '> ⏰ Válido até: *{expiresAt}*',
    '',
    '🔗 *Link para pagamento:*',
    '{ticketUrl}',
    '',
    '📋 *Ou copie o código PIX abaixo:*'
  ].join('\n'),
  [KEYS.PURCHASE_PAYMENT_APPROVED]: [
    '✅ *PAGAMENTO APROVADO!*',
    '',
    '🎉 _Obrigado pela confiança!_',
    '',
    '👤 *Digite um nome de usuário* (3-8 letras):',
    '',
    '> _Ou envie qualquer texto para gerar automaticamente_'
  ].join('\n'),
  [KEYS.PURCHASE_ACCESS_CREATED]: [
    '🎉 *ACESSO VIP CRIADO!*',
    '',
    '> 👤 Login: *{login}*',
    '> 🔑 Senha: *{password}*',
    '> 🆔 UUID: `{uuid}`',
    '',
    '📲 *Baixe o app:* {appLink}',
    '',
    '✨ _Obrigado pela compra!_',
    '_Qualquer dúvida, estamos à disposição._'
  ].join('\n'),
  [KEYS.PURCHASE_PIX_EXPIRED]: [
    '⏰ *PIX EXPIRADO*',
    '',
    '> _O tempo para pagamento se esgotou._',
    '',
    '_Inicie uma nova compra pelo menu._'
  ].join('\n'),
  [KEYS.PURCHASE_PAYMENT_REJECTED]: [
    '❌ *PAGAMENTO NÃO APROVADO*',
    '',
    '> _O pagamento foi cancelado ou rejeitado._',
    '',
    '_Tente novamente pelo menu._'
  ].join('\n'),
  [KEYS.PURCHASE_PAYMENT_REFUNDED]: [
    '⚠️ *PAGAMENTO ESTORNADO*',
    '',
    '> _Identificamos estorno/chargeback do pagamento._',
    '',
    '📩 Se você precisar de ajuda, fale com o suporte.'
  ].join('\n'),
  [KEYS.PURCHASE_PIX_ERROR]: [
    '❌ *ERRO AO GERAR PIX*',
    '',
    '> _{error}_',
    '',
    '_Tente novamente mais tarde._'
  ].join('\n'),
  [KEYS.PURCHASE_ACCESS_ERROR]: [
    '❌ *ERRO AO CRIAR ACESSO*',
    '',
    '> _{error}_',
    '',
    '_Entre em contato com o suporte._'
  ].join('\n'),
  [KEYS.PURCHASE_ADMIN_START]: [
    '🧾 *Nova compra iniciada*',
    '',
    '> 💎 Plano: *{planLabel}*',
    '> 💰 Valor: *{amount}*',
    '> 👤 Usuário: _{phoneLink}_',
    '> 🆔 Pagamento: `{paymentId}`'
  ].join('\n'),
  [KEYS.PURCHASE_ADMIN_COMPLETED]: [
    '✅ *Venda concluída!*',
    '',
    '> 💎 Plano: *{planLabel}*',
    '> 💰 Valor: *{amount}*',
    '> 👤 Usuário: _{phoneLink}_',
    '> 🔑 Login: *{login}*',
    '> 🆔 Pagamento: `{paymentId}`'
  ].join('\n'),
  [KEYS.PURCHASE_ADMIN_REFUNDED]: [
    '⚠️ *Pagamento estornado*',
    '',
    '> 💎 Plano: *{planLabel}*',
    '> 💰 Valor: *{amount}*',
    '> 👤 Usuário: _{phoneLink}_',
    '> 🆔 Pagamento: `{paymentId}`'
  ].join('\n'),
  [KEYS.PURCHASE_COUPON_APPLIED]: [
    '✅ *Cupom aplicado!*',
    '',
    '> 🎟️ Cupom: *{couponCode}*',
    '> 💰 De: *{originalAmount}*',
    '> 🏷️ Desconto: *{discountAmount}*',
    '> ✅ Por: *{amount}*',
    '',
    '⏰ Válido até: *{expiresAt}*',
    '',
    '📧 Agora digite seu e-mail para gerar o PIX:'
  ].join('\n'),
  [KEYS.PURCHASE_COUPON_ERROR]: [
    '❌ {error}',
    '',
    '📧 Agora digite seu e-mail para gerar o PIX:'
  ].join('\n'),
  [KEYS.FAQ_Q1]: [
    '[APP] *Baixar e instalar o app*',
    '',
    'Use a opção *BAIXAR APP* no menu.',
    '',
    'Se você já comprou e perdeu o link, solicite novamente pelo menu.',
    '',
    'Dica: mantenha o app atualizado para evitar erros de conexão.'
  ].join('\n'),
  [KEYS.FAQ_Q2]: [
    '[RENOVAÇÃO] *Como renovar meu acesso?*',
    '',
    'Acesse: *MENU* → *OUTRAS OPÇÕES* → *RENOVAR*.',
    '',
    'Se o seu acesso estiver expirado há muitos dias, será necessário fazer uma nova compra.'
  ].join('\n'),
  [KEYS.FAQ_Q3]: [
    '[PAGAMENTO] *Paguei via PIX e não liberou*',
    '',
    'Alguns pagamentos podem levar alguns minutos para atualizar.',
    '',
    'Acesse: *OUTRAS OPÇÕES* → *VERIFICAR ACESSO*.',
    '',
    'Se continuar, abra *SUPORTE* e envie o comprovante do pagamento.'
  ].join('\n'),
  [KEYS.FAQ_Q4]: [
    '[CONEXÃO] *Acesso instável ou lento*',
    '',
    '1) Feche e abra o app',
    '2) Troque de rede (Wi‑Fi/4G) e teste novamente',
    '3) Use *VERIFICAR ACESSO* para confirmar o status',
    '',
    'Se persistir, abra *SUPORTE* e informe seu login e o horário do problema.'
  ].join('\n'),
  [KEYS.FAQ_Q5]: [
    '[ACESSO] *Como saber se está tudo funcionando?*',
    '',
    'Acesse: *OUTRAS OPÇÕES* → *VERIFICAR ACESSO*.',
    '',
    'Você verá o status, validade e se está online.'
  ].join('\n')
}

const TOKENS = {
  [KEYS.MENU_WELCOME]: ['{name}', '{appLink}'],
  [KEYS.TEST_ACTIVE]: ['{login}', '{password}', '{uuid}', '{expiresAt}', '{appLink}'],
  [KEYS.TEST_EXPIRED]: ['{appLink}'],
  [KEYS.TEST_ERROR]: ['{error}', '{appLink}'],
  [KEYS.TEST_CREATED]: ['{login}', '{password}', '{uuid}', '{duration}', '{expiresAt}', '{appLink}'],
  [KEYS.TEST_ADMIN_NOTIFY]: ['{name}', '{phone}', '{phoneLink}', '{login}', '{expiresAt}'],
  [KEYS.PURCHASE_PLANS_MENU]: ['{appLink}'],
  [KEYS.PURCHASE_PLAN_SELECTED]: ['{planLabel}', '{appLink}'],
  [KEYS.PURCHASE_PIX_GENERATED]: ['{planLabel}', '{amount}', '{expiresAt}', '{ticketUrl}', '{appLink}'],
  [KEYS.PURCHASE_PAYMENT_APPROVED]: ['{appLink}'],
  [KEYS.PURCHASE_ACCESS_CREATED]: ['{login}', '{password}', '{uuid}', '{appLink}'],
  [KEYS.PURCHASE_PIX_EXPIRED]: ['{appLink}'],
  [KEYS.PURCHASE_PAYMENT_REJECTED]: ['{appLink}'],
  [KEYS.PURCHASE_PAYMENT_REFUNDED]: ['{appLink}'],
  [KEYS.PURCHASE_PIX_ERROR]: ['{error}', '{appLink}'],
  [KEYS.PURCHASE_ACCESS_ERROR]: ['{error}', '{appLink}'],
  [KEYS.PURCHASE_ADMIN_START]: ['{planLabel}', '{amount}', '{phoneLink}', '{paymentId}'],
  [KEYS.PURCHASE_ADMIN_COMPLETED]: ['{planLabel}', '{amount}', '{phoneLink}', '{login}', '{paymentId}'],
  [KEYS.PURCHASE_ADMIN_REFUNDED]: ['{planLabel}', '{amount}', '{phoneLink}', '{paymentId}'],
  [KEYS.PURCHASE_COUPON_APPLIED]: ['{couponCode}', '{originalAmount}', '{discountAmount}', '{amount}', '{expiresAt}'],
  [KEYS.PURCHASE_COUPON_ERROR]: ['{error}'],
  [KEYS.FAQ_Q1]: ['{appLink}'],
  [KEYS.FAQ_Q2]: ['{appLink}'],
  [KEYS.FAQ_Q3]: ['{appLink}'],
  [KEYS.FAQ_Q4]: ['{appLink}'],
  [KEYS.FAQ_Q5]: ['{appLink}']
}

const normalizeKey = (key) => String(key || '').trim()

const applyTokens = (text, tokens) => {
  const entries = Object.entries(tokens || {})
  return entries.reduce((acc, [from, to]) => acc.split(from).join(String(to)), String(text || ''))
}

function getTemplate(key) {
  const normalized = normalizeKey(key)
  const row = botTexts.findByKey(normalized)
  const fallback = DEFAULTS[normalized] || ''
  return row?.text || fallback
}

function render(key, tokens = {}) {
  const normalized = normalizeKey(key)
  const base = getTemplate(normalized)
  const appLink = settingsService.getAppLink()
  const merged = { ...tokens, '{appLink}': appLink }
  return applyTokens(base, merged)
}

function upsertTemplate(key, text) {
  const normalized = normalizeKey(key)
  const body = String(text || '').trim()
  if (!normalized) return { ok: false, error: 'Chave inválida.' }
  if (!body) return { ok: false, error: 'Texto inválido.' }
  const saved = botTexts.upsert({ key: normalized, text: body })
  if (!saved) return { ok: false, error: 'Falha ao salvar.' }
  return { ok: true, template: saved }
}

function tokensForKey(key) {
  const normalized = normalizeKey(key)
  return TOKENS[normalized] || []
}

function keysByCategory(category) {
  const normalized = normalizeKey(category)
  return CATEGORY_KEYS[normalized] || []
}

module.exports = {
  KEYS,
  CATEGORIES,
  getTemplate,
  render,
  upsertTemplate,
  tokensForKey,
  keysByCategory
}

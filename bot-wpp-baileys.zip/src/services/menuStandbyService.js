const { menuStandby } = require('../database')

const ONE_HOUR_MS = 60 * 60 * 1000

const toTime = (value) => {
  const ts = new Date(value || '').getTime()
  if (!Number.isFinite(ts)) return null
  return ts
}

function isInStandby(phone, now = Date.now()) {
  const key = String(phone || '').trim()
  if (!key) return false
  const row = menuStandby.findByPhone(key)
  if (!row) return false
  const until = toTime(row.untilAt)
  if (!until) {
    menuStandby.remove(key)
    return false
  }
  if (until <= now) {
    menuStandby.remove(key)
    return false
  }
  return true
}

function setStandby(phone, now = Date.now()) {
  const key = String(phone || '').trim()
  if (!key) return null
  const untilAt = new Date(now + ONE_HOUR_MS).toISOString()
  return menuStandby.upsert({ phone: key, untilAt })
}

function clearIfExpired(phone, now = Date.now()) {
  const key = String(phone || '').trim()
  if (!key) return false
  const row = menuStandby.findByPhone(key)
  if (!row) return false
  const until = toTime(row.untilAt)
  if (!until) return menuStandby.remove(key)
  if (until <= now) return menuStandby.remove(key)
  return false
}

module.exports = { isInStandby, setStandby, clearIfExpired }

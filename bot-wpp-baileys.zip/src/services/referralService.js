const { referrals, accesses } = require('../database')
const { createPanelApi } = require('../utils/api')
const { extractPhoneDigits, isValidPhone, formatPhoneLink, formatSpDate } = require('../utils/helpers')
const { sendText } = require('../utils/messages')
const config = require('../config')

const panelApi = createPanelApi(config.panelDomain, config.panelToken)
const adminJid = `${config.adminNumber}@s.whatsapp.net`

const REF_CMD = /^(indicacao|indicação|indica|ref)\s+(.+)$/i

const normalizePhone = (value) => {
  const digits = extractPhoneDigits(value)
  if (!digits) return null
  if (digits.startsWith('55')) return digits
  const withCountry = `55${digits}`
  return withCountry
}

function parseReferralMessage(text) {
  const raw = String(text || '').trim()
  const match = raw.match(REF_CMD)
  if (!match) return null
  return normalizePhone(match[2])
}

function canAttachReferrer({ refereePhone, referrerPhone }) {
  const cfg = referrals.getConfig()
  if (!cfg?.active) return { ok: false, error: 'Programa de indicação está desativado.' }
  if (!referrerPhone) return { ok: false, error: 'Número inválido.' }
  if (!isValidPhone(referrerPhone)) return { ok: false, error: 'Número inválido.' }
  if (referrerPhone === refereePhone) return { ok: false, error: 'Você não pode indicar a si mesmo.' }
  return { ok: true, config: cfg }
}

const addDaysIso = (iso, days) => {
  const dt = new Date(iso)
  const ts = dt.getTime()
  if (!Number.isFinite(ts)) return null
  dt.setDate(dt.getDate() + Number(days || 0))
  return dt.toISOString()
}

async function handlePurchaseCompleted({ sock, purchase }) {
  const referrerPhone = purchase?.referrerPhone
  if (!referrerPhone) return false

  const cfg = referrals.getConfig()
  if (!cfg?.active) return false

  try {
    referrals.insertReferral({
      referrerPhone,
      refereePhone: purchase.phone,
      purchaseId: purchase.id,
      status: 'approved'
    })
  } catch {}

  const approved = referrals.countApprovedFor(referrerPhone)
  const rewarded = referrals.countRewardsFor(referrerPhone)
  const required = cfg.requiredCount || 1
  const due = Math.floor(approved / required) - rewarded
  if (due <= 0) return true

  const access = accesses.findLatestByPhone(referrerPhone)
  if (!access) {
    for (let i = 0; i < due; i++) {
      referrals.insertReward({ referrerPhone, login: null, rewardDays: cfg.rewardDays })
    }
    await sendText(sock, adminJid, [
      '🎁 *Indicação aprovada*',
      '',
      `> Referrer: _${formatPhoneLink(referrerPhone)}_`,
      `> Indicado: _${formatPhoneLink(purchase.phone)}_`,
      `> Recompensa pendente (sem login encontrado)`
    ].join('\n'), false)
    return true
  }

  const totalDays = cfg.rewardDays * due
  try {
    await panelApi.renewUser({ login: access.login, dias: totalDays, limite: access.limitCount })
  } catch {
    await sendText(sock, adminJid, [
      '⚠️ *Falha ao aplicar indicação*',
      '',
      `> Referrer: _${formatPhoneLink(referrerPhone)}_`,
      `> Login: *${access.login}*`,
      `> Dias pendentes: *${totalDays}*`
    ].join('\n'), false)
    return true
  }

  for (let i = 0; i < due; i++) {
    referrals.insertReward({ referrerPhone, login: access.login, rewardDays: cfg.rewardDays })
  }

  const nextExpires = addDaysIso(access.expiresAt, totalDays)
  if (nextExpires) accesses.updateExpiresAt(access.login, nextExpires)

  const updatedAccess = accesses.findByLogin(access.login)
  const expText = updatedAccess?.expiresAt ? formatSpDate(updatedAccess.expiresAt) : 'indisponível'

  await sendText(sock, `${referrerPhone}@s.whatsapp.net`, [
    '🎉 *Você ganhou dias grátis!*',
    '',
    `> ✅ Indicações confirmadas: *${approved}*`,
    `> 🎁 Recompensa: *+${totalDays} dias*`,
    `> 📅 Nova validade: _${expText}_`
  ].join('\n'))

  await sendText(sock, adminJid, [
    '🎁 *Recompensa de indicação aplicada*',
    '',
    `> Referrer: _${formatPhoneLink(referrerPhone)}_`,
    `> Indicado: _${formatPhoneLink(purchase.phone)}_`,
    `> Login: *${access.login}*`,
    `> +${totalDays} dias`,
    `> Expira: _${expText}_`
  ].join('\n'), false)

  return true
}

module.exports = { parseReferralMessage, canAttachReferrer, handlePurchaseCompleted }

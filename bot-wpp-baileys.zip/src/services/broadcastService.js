const { downloadContentFromMessage } = require('@whiskeysockets/baileys')
const { sendText } = require('../utils/messages')
const { sendButtons } = require('../utils/buttons')
const { templates, broadcastJobs, broadcastEvents } = require('../database')
const { executeBroadcast, phonesForSegment } = require('./broadcastExecutor')
const { formatSpDate } = require('../utils/helpers')
const config = require('../config')

const TYPES = { TEXT: 'text', MEDIA: 'media', COMPLETE: 'complete' }
const SEGMENTS = { ALL: 'all', ACTIVE: 'active', EXPIRED: 'expired' }
const adminJid = `${config.adminNumber}@s.whatsapp.net`

const BUTTONS = {
  SEG_ALL: 'broadcast_segment_all',
  SEG_ACTIVE: 'broadcast_segment_active',
  SEG_EXPIRED: 'broadcast_segment_expired',
  TYPE_TEXT: 'broadcast_type_text',
  TYPE_MEDIA: 'broadcast_type_media',
  TYPE_COMPLETE: 'broadcast_type_complete',
  TEMPLATES: 'broadcast_templates',
  SEND_NOW: 'broadcast_send_now',
  SEND_SCHEDULE: 'broadcast_send_schedule',
  CANCEL: 'broadcast_cancel',
  TEMPLATE_PREFIX: 'broadcast_tpl_'
}

const ADMIN_NAV = {
  BROADCAST: 'admin_broadcast',
  MARKETING_MENU: 'admin_marketing_menu',
  TEMPLATES_MENU: 'admin_templates_menu',
  BROADCAST_JOBS_LIST: 'admin_broadcast_jobs_list',
  ADMIN_BACK_MAIN: 'admin_back_main'
}

const SEGMENT_MAP = {
  [BUTTONS.SEG_ALL]: SEGMENTS.ALL,
  [BUTTONS.SEG_ACTIVE]: SEGMENTS.ACTIVE,
  [BUTTONS.SEG_EXPIRED]: SEGMENTS.EXPIRED
}

const TYPE_MAP = {
  [BUTTONS.TYPE_TEXT]: TYPES.TEXT,
  [BUTTONS.TYPE_MEDIA]: TYPES.MEDIA,
  [BUTTONS.TYPE_COMPLETE]: TYPES.COMPLETE
}

const createInitialState = () => ({
  segment: null,
  type: null,
  text: null,
  mediaBuffer: null,
  mediaType: null,
  mimetype: null,
  templateId: null,
  stage: null
})

let state = createInitialState()

const resetState = () => { state = createInitialState() }

const getState = () => ({ ...state })

const isAwaitingInput = () => state.stage !== null

const segmentLabel = (segment) => {
  const labels = {
    [SEGMENTS.ALL]: 'Todos',
    [SEGMENTS.ACTIVE]: 'Ativos',
    [SEGMENTS.EXPIRED]: 'Expirados'
  }
  return labels[segment] || 'Todos'
}

const estimatedMinutes = (total, delayMs = 2000) => Math.ceil((total * delayMs) / 60000)

const parseScheduleAt = (text) => {
  const raw = String(text || '').trim()
  const match = raw.match(/^(\d{4}-\d{2}-\d{2})\s+(\d{2}:\d{2})$/)
  if (!match) return null
  const dt = new Date(`${match[1]}T${match[2]}:00-03:00`)
  const ts = dt.getTime()
  if (!Number.isFinite(ts)) return null
  return dt.toISOString()
}

const sendError = async (sock, message) => {
  await sendText(sock, adminJid, `❌ ${message}`, false)
  resetState()
}

const promptSegment = async (sock) => {
  const allCount = phonesForSegment('all').length
  const activeCount = phonesForSegment('active').length
  const expiredCount = phonesForSegment('expired').length

  await sendButtons(sock, adminJid, {
    text: [
      '📢 *MARKETING — Broadcast*',
      '',
      `> 👥 Todos: *${allCount}*`,
      `> ✅ Ativos: *${activeCount}*`,
      `> ⏰ Expirados: *${expiredCount}*`,
      '',
      '_Selecione o público:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTONS.SEG_ALL, text: '👥 Todos' },
      { id: BUTTONS.SEG_ACTIVE, text: '✅ Ativos' },
      { id: BUTTONS.SEG_EXPIRED, text: '⏰ Expirados' },
      { id: BUTTONS.CANCEL, text: '❌ Cancelar' }
    ]
  })

  state.stage = 'awaiting_segment'
}

const promptType = async (sock) => {
  await sendButtons(sock, adminJid, {
    text: [
      '📢 *Tipo de mensagem*',
      '',
      `> Público: *${segmentLabel(state.segment)}*`,
      '',
      '_Escolha o tipo:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTONS.TYPE_TEXT, text: '📝 Texto' },
      { id: BUTTONS.TYPE_MEDIA, text: '📎 Mídia' },
      { id: BUTTONS.TYPE_COMPLETE, text: '🖼️ Mídia + Legenda' },
      { id: BUTTONS.CANCEL, text: '❌ Cancelar' }
    ]
  })

  state.stage = 'awaiting_type'
}

const promptText = async (sock) => {
  await sendButtons(sock, adminJid, {
    text: [
      '📝 *Texto do broadcast*',
      '',
      '> Digite a mensagem abaixo.',
      '',
      '_Ou selecione um template:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTONS.TEMPLATES, text: '📄 Templates' },
      { id: BUTTONS.CANCEL, text: '❌ Cancelar' }
    ]
  })
  state.stage = 'awaiting_text'
}

const promptMedia = async (sock, wantsCaption) => {
  const title = wantsCaption ? '🖼️ *Mídia com legenda*' : '📎 *Envie a mídia*'
  const tip = wantsCaption ? '> Envie *imagem* ou *vídeo* com a legenda' : '> Envie *imagem*, *vídeo* ou *áudio*'
  await sendText(sock, adminJid, [title, '', tip].join('\n'), false)
  state.stage = 'awaiting_media'
}

const promptSendMode = async (sock) => {
  const total = phonesForSegment(state.segment || 'all').length
  await sendButtons(sock, adminJid, {
    text: [
      '🚀 *Enviar ou agendar?*',
      '',
      `> Público: *${segmentLabel(state.segment)}*`,
      `> Total: *${total}*`,
      `> Tempo estimado: *${estimatedMinutes(total)} min*`,
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTONS.SEND_NOW, text: '🚀 Enviar agora' },
      { id: BUTTONS.SEND_SCHEDULE, text: '📅 Agendar' },
      { id: BUTTONS.CANCEL, text: '❌ Cancelar' }
    ]
  })
  state.stage = 'awaiting_send_mode'
}

const promptScheduleAt = async (sock) => {
  await sendText(sock, adminJid, [
    '📅 *Agendar broadcast*',
    '',
    'Envie no formato (horário de Brasília):',
    '> YYYY-MM-DD HH:MM',
    '',
    'Exemplo:',
    '> 2026-02-01 09:30'
  ].join('\n'), false)
  state.stage = 'awaiting_schedule_at'
}

const extractMediaInfo = (message) => {
  const mediaTypes = [
    { key: 'imageMessage', type: 'image' },
    { key: 'videoMessage', type: 'video' },
    { key: 'audioMessage', type: 'audio' }
  ]

  const found = mediaTypes.find(m => message?.[m.key])
  if (!found) return null

  const mediaMsg = message[found.key]
  return {
    mediaMsg,
    mediaType: found.type,
    caption: mediaMsg.caption || '',
    mimetype: mediaMsg.mimetype || `${found.type}/mp4`
  }
}

const downloadMedia = async (mediaMsg, mediaType) => {
  const stream = await downloadContentFromMessage(mediaMsg, mediaType)
  const chunks = []
  for await (const chunk of stream) {
    chunks.push(chunk)
  }
  return Buffer.concat(chunks)
}

async function startBroadcast({ sock }) {
  resetState()
  await promptSegment(sock)
  return true
}

const promptByType = {
  [TYPES.TEXT]: (sock) => promptText(sock),
  [TYPES.MEDIA]: (sock) => promptMedia(sock, false),
  [TYPES.COMPLETE]: (sock) => promptMedia(sock, true)
}

async function handleCancel(sock) {
  resetState()
  await sendButtons(sock, adminJid, {
    text: '✅ Broadcast cancelado.\n\n_Selecione uma opção:_',
    footer: '© MASTER BOT',
    buttons: [
      { id: ADMIN_NAV.BROADCAST, text: '📢 Broadcast' },
      { id: ADMIN_NAV.TEMPLATES_MENU, text: '📄 Templates' },
      { id: ADMIN_NAV.BROADCAST_JOBS_LIST, text: '📅 Agendamentos' },
      { id: ADMIN_NAV.ADMIN_BACK_MAIN, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function handleType(sock, type) {
  const prompt = promptByType[type]
  if (!prompt) return false
  state.type = type
  state.stage = null
  await prompt(sock)
  return true
}

async function handleTemplatesMenu(sock) {
  const list = templates.listAll().slice(0, 10)
  if (!list.length) {
    await sendText(sock, adminJid, '📭 Nenhum template cadastrado.', false)
    await promptText(sock)
    return true
  }

  await sendButtons(sock, adminJid, {
    text: '📄 *Templates* — selecione um:',
    footer: '© MASTER BOT',
    buttons: [
      ...list.map(t => ({ id: `${BUTTONS.TEMPLATE_PREFIX}${t.id}`, text: t.name.slice(0, 24) })),
      { id: BUTTONS.CANCEL, text: '❌ Cancelar' }
    ]
  })
  state.stage = 'awaiting_template'
  return true
}

async function handleTemplatePick(sock, buttonId) {
  const id = buttonId.slice(BUTTONS.TEMPLATE_PREFIX.length)
  const tpl = templates.findById(id)
  if (!tpl) {
    await sendText(sock, adminJid, '❌ Template não encontrado.', false)
    await promptText(sock)
    return true
  }
  state.templateId = tpl.id
  state.text = tpl.text
  state.stage = null
  await promptSendMode(sock)
  return true
}

async function handleSendNow(sock) {
  state.stage = null
  const now = new Date().toISOString()
  const job = broadcastJobs.create({
    segment: state.segment || 'all',
    type: state.type,
    text: state.text,
    media: state.mediaBuffer,
    mediaType: state.mediaType,
    mimetype: state.mimetype,
    templateId: state.templateId,
    scheduledAt: now
  })

  broadcastJobs.updateStatus(job.id, { status: broadcastJobs.STATUSES.RUNNING, startedAt: now })

  const total = phonesForSegment(job.segment).length
  await sendText(sock, adminJid, [
    '🚀 *Iniciando broadcast...*',
    '',
    `> ID: *${job.id}*`,
    `> Público: *${segmentLabel(job.segment)}*`,
    `> Total: *${total}*`,
    `> Tempo estimado: *${estimatedMinutes(total)} min*`
  ].join('\n'), false)

  try {
    const result = await executeBroadcast({
      sock,
      segment: job.segment,
      type: job.type,
      text: job.text,
      mediaBuffer: job.media,
      mediaType: job.mediaType,
      mimetype: job.mimetype,
      broadcastId: job.id
    })

    const finishedAt = new Date().toISOString()
    broadcastJobs.updateStatus(job.id, {
      status: broadcastJobs.STATUSES.COMPLETED,
      total: result.total,
      sent: result.sent,
      failed: result.failed,
      finishedAt
    })

    const replies = broadcastEvents.countByKind(job.id, 'reply')
    const delivered = broadcastEvents.countByKind(job.id, 'delivered')
    const read = broadcastEvents.countByKind(job.id, 'read')

    await sendText(sock, adminJid, [
      '✅ *Broadcast concluído!*',
      '',
      `> ID: *${job.id}*`,
      `> Público: *${segmentLabel(job.segment)}*`,
      `> 📤 Enviados: *${result.sent}*`,
      `> ❌ Falhas: *${result.failed}*`,
      `> 💬 Respostas: *${replies}*`,
      `> 📬 Entregues: *${delivered}*`,
      `> 👁️ Lidas: *${read}*`,
      `> 📊 Total: *${result.total}*`,
      `> ⏱️ Tempo: *${result.duration}s*`
    ].join('\n'), false)
  } catch (error) {
    const finishedAt = new Date().toISOString()
    broadcastJobs.updateStatus(job.id, {
      status: broadcastJobs.STATUSES.FAILED,
      errorMessage: error?.message || 'Erro desconhecido',
      finishedAt
    })
    await sendText(sock, adminJid, `❌ Falha ao enviar broadcast: ${error?.message || 'desconhecido'}`, false)
  }

  resetState()
  return true
}

async function handleSchedule(sock) {
  state.stage = null
  await promptScheduleAt(sock)
  return true
}

async function handleButton({ sock, buttonId }) {
  if (buttonId === BUTTONS.CANCEL) return handleCancel(sock)

  const segment = SEGMENT_MAP[buttonId]
  if (segment) {
    state.segment = segment
    state.stage = null
    await promptType(sock)
    return true
  }

  const type = TYPE_MAP[buttonId]
  if (type) return handleType(sock, type)

  if (buttonId === BUTTONS.TEMPLATES) return handleTemplatesMenu(sock)

  const isTemplatePick = buttonId?.startsWith(BUTTONS.TEMPLATE_PREFIX)
  if (isTemplatePick) return handleTemplatePick(sock, buttonId)

  if (buttonId === BUTTONS.SEND_NOW) return handleSendNow(sock)

  if (buttonId === BUTTONS.SEND_SCHEDULE) return handleSchedule(sock)

  return false
}

async function handleTextInput({ sock, text }) {
  if (state.stage === 'awaiting_text') {
    state.text = text
    state.stage = null
    await promptSendMode(sock)
    return true
  }

  if (state.stage !== 'awaiting_schedule_at') return false

  const scheduledAt = parseScheduleAt(text)
  if (!scheduledAt) {
    await sendError(sock, 'Data/hora inválida. Use YYYY-MM-DD HH:MM')
    return true
  }

  const job = broadcastJobs.create({
    segment: state.segment || 'all',
    type: state.type,
    text: state.text,
    media: state.mediaBuffer,
    mediaType: state.mediaType,
    mimetype: state.mimetype,
    templateId: state.templateId,
    scheduledAt
  })

  await sendText(sock, adminJid, [
    '✅ *Broadcast agendado!*',
    '',
    `> ID: *${job.id}*`,
    `> Público: *${segmentLabel(job.segment)}*`,
    `> Data: _${formatSpDate(job.scheduledAt)}_`
  ].join('\n'), false)

  resetState()
  return true
}

async function handleMediaInput({ sock, message }) {
  if (state.stage !== 'awaiting_media') return false

  const mediaInfo = extractMediaInfo(message)
  if (!mediaInfo) {
    await sendError(sock, 'Mídia não reconhecida. Envie imagem, vídeo ou áudio.')
    return true
  }

  try {
    state.mediaBuffer = await downloadMedia(mediaInfo.mediaMsg, mediaInfo.mediaType)
    state.mediaType = mediaInfo.mediaType
    state.mimetype = mediaInfo.mimetype
    state.text = state.type === TYPES.COMPLETE ? mediaInfo.caption : state.text
    state.stage = null
    await promptSendMode(sock)
  } catch (error) {
    await sendError(sock, `Falha ao processar mídia: ${error.message}`)
  }

  return true
}

const handleTypeSelection = ({ sock, buttonId }) => handleButton({ sock, buttonId })

module.exports = {
  TYPES,
  SEGMENTS,
  BUTTONS,
  startBroadcast,
  handleButton,
  handleTypeSelection,
  handleTextInput,
  handleMediaInput,
  isAwaitingInput,
  getState,
  resetState
}

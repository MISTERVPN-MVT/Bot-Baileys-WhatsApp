const { purchases, renewals, accesses } = require('../database')
const { createPanelApi } = require('../utils/api')
const { sendText } = require('../utils/messages')
const { sendButtons } = require('../utils/buttons')
const { formatPhoneLink } = require('../utils/helpers')
const config = require('../config')
const settingsService = require('./settingsService')

const panelApi = createPanelApi(config.panelDomain, config.panelToken)
const adminJid = `${config.adminNumber}@s.whatsapp.net`
const MAX_DAYS_EXPIRED = 5
const DAY_MS = 24 * 60 * 60 * 1000

const safeTs = (value) => {
  const ts = new Date(value).getTime()
  if (!Number.isFinite(ts)) return null
  return ts
}

const addDaysIso = (iso, days) => {
  const ts = safeTs(iso)
  if (ts == null) return null
  const dt = new Date(ts)
  dt.setDate(dt.getDate() + Number(days || 0))
  return dt.toISOString()
}

const computePurchaseExpiresAt = (purchase) => {
  const base = purchase?.completedAt || purchase?.createdAt
  const ts = safeTs(base)
  if (ts == null) return null
  const dt = new Date(ts)
  dt.setDate(dt.getDate() + Number(purchase.days || 0))
  return dt.toISOString()
}

function canRenew(purchase) {
  if (!purchase?.completedAt) return false
  const accessExpiresAt = purchase?.login ? accesses.findByLogin(purchase.login)?.expiresAt : null
  const expiresAt = accessExpiresAt || computePurchaseExpiresAt(purchase)
  const expiresTs = safeTs(expiresAt)
  if (expiresTs == null) return false

  const now = Date.now()
  if (now <= expiresTs) return true

  const expiredMs = now - expiresTs
  const daysExpired = Math.floor(expiredMs / DAY_MS)
  return daysExpired <= MAX_DAYS_EXPIRED
}

async function showRenewButton(sock, jid, phone, isAdmin) {
  const hasPurchased = purchases.hasPurchased(phone)
  if (!hasPurchased && !isAdmin) return false

  await sendButtons(sock, jid, {
    text: '🔄 *Renovar Acesso*\n\n_Renove seu acesso mantendo seu login e senha atuais._',
    footer: 'Author: @vpnmasternet',
    buttons: [{ id: 'renew_access', text: '🔄 Renovar' }]
  })
  return true
}

async function handleRenewButton({ sock, jid, phone, isAdmin }) {
  if (isAdmin) {
    await sendText(sock, jid, '🔐 *Admin*\n\nEnvie o login que deseja renovar:')
    return { waitingForLogin: true }
  }

  const purchase = purchases.findCompletedByPhone(phone)
  if (!purchase) {
    await sendText(sock, jid, '❌ Você ainda não possui uma compra para renovar.')
    return null
  }

  if (!canRenew(purchase)) {
    await sendText(sock, jid, '❌ Seu acesso expirou há mais de 5 dias.\n\n📲 Realize uma nova compra para continuar.')
    return null
  }

  await sendButtons(sock, jid, {
    text: `🔄 *Renovar Acesso*\n\n📌 Login: ${purchase.login}\n\n_Clique abaixo para escolher o plano de renovação:_`,
    footer: 'Author: @vpnmasternet',
    buttons: [{ id: `renew_confirm_${purchase.id}`, text: '✅ Renovar este login' }]
  })

  return purchase
}

async function handleAdminRenewLogin({ sock, jid, login }) {
  try {
    const result = await panelApi.getUser(login)
    const users = result?.data?.usuarios || []
    const user = users.find(u => u.login === login)
    
    if (!user) {
      await sendText(sock, jid, `❌ Login "${login}" não encontrado no painel.`, false)
      return false
    }

    await panelApi.renewUser({
      login,
      dias: 30,
      limite: user.limite || 1
    })

    const access = accesses.findByLogin(login)
    const nextExpires = access ? addDaysIso(access.expiresAt, 30) : null
    if (nextExpires) accesses.updateExpiresAt(login, nextExpires)
    if (access) renewals.create({ phone: access.phone, login, days: 30, amount: 0, planLabel: 'Renovação admin' })

    await sendText(sock, jid, `✅ Login "${login}" renovado com sucesso!\n\n📅 +30 dias adicionados.`, false)
    return true
  } catch (error) {
    await sendText(sock, jid, `❌ Erro ao renovar: ${error.message}`, false)
    return false
  }
}

async function processRenewal({ sock, jid, purchase, phone }) {
  try {
    await panelApi.renewUser({
      login: purchase.login,
      dias: purchase.days,
      limite: purchase.limit
    })

    renewals.create({
      phone,
      login: purchase.login,
      days: purchase.days,
      amount: purchase.amount,
      planLabel: purchase.planLabel
    })

    const currentAccess = accesses.findByLogin(purchase.login)
    const baseExpires = currentAccess?.expiresAt || computePurchaseExpiresAt(purchase) || new Date().toISOString()
    const nextExpires = addDaysIso(baseExpires, purchase.days)
    if (nextExpires) {
      accesses.upsertAccess({
        login: purchase.login,
        phone,
        jid: purchase.jid || jid,
        planId: purchase.planId,
        planLabel: purchase.planLabel,
        limitCount: purchase.limit,
        days: purchase.days,
        expiresAt: nextExpires
      })
    }

    await sendText(sock, jid, [
      '✅ *Acesso Renovado!*',
      '',
      `📌 Login: ${purchase.login}`,
      `🔑 Senha: ${purchase.password}`,
      `📅 Validade: +${purchase.days} dias`,
      '',
      `📲 App: ${settingsService.getAppLink()}`
    ].join('\n'))

    await notifyAdminRenewal(sock, purchase, phone)
    return true
  } catch (error) {
    await sendText(sock, jid, `❌ Erro ao renovar: ${error.message}`)
    return false
  }
}

async function notifyAdminRenewal(sock, purchase, phone) {
  const link = formatPhoneLink(phone)
  const text = [
    '🔄 *Renovação realizada*',
    `Login: ${purchase.login}`,
    `Usuário: ${link}`,
    `Plano: ${purchase.planLabel}`
  ].join('\n')
  await sendText(sock, adminJid, text, false)
}

module.exports = {
  canRenew,
  showRenewButton,
  handleRenewButton,
  handleAdminRenewLogin,
  processRenewal,
  MAX_DAYS_EXPIRED
}

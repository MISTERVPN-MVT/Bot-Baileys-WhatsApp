const { tests, supports, users, blocked, templates, broadcastJobs, broadcastEvents, logs, purchases, accesses, systemState, plans } = require('../database')
const { createPanelApi } = require('../utils/api')
const { sendText } = require('../utils/messages')
const { sendButtons } = require('../utils/buttons')
const { delay, randomDigits, generateUuid, formatPhoneLink, formatSpDate } = require('../utils/helpers')
const broadcastService = require('./broadcastService')
const financeService = require('./financeService')
const backupService = require('./backupService')
const dashboardService = require('./dashboardService')
const paymentMonitorService = require('./paymentMonitorService')
const settingsService = require('./settingsService')
const notificationTemplateService = require('./notificationTemplateService')
const textTemplateService = require('./textTemplateService')
const config = require('../config')

const panelApi = createPanelApi(config.panelDomain, config.panelToken)
const adminJid = `${config.adminNumber}@s.whatsapp.net`
const audit = (action, data = null) => logs.add('admin', action, data)

const ADMIN_COMMANDS = ['.admin', '.adm']
const normalizeButtonLabel = (text) => String(text || '').replace(/^[^\p{L}\p{N}]+/gu, '').trim().toLowerCase()
const sortButtonsAlpha = (buttons) => [...buttons].sort((a, b) => normalizeButtonLabel(a.text).localeCompare(normalizeButtonLabel(b.text), 'pt-BR'))

const textEditPrefix = 'admin_text_edit_'
const planEditPrefix = 'admin_plan_edit_'
const planDeletePrefix = 'admin_plan_delete_'
const planDeleteConfirmPrefix = 'admin_plan_delete_confirm_'

const textEditButtonId = (key) => `${textEditPrefix}${key}`
const planEditButtonId = (id) => `${planEditPrefix}${id}`
const planDeleteButtonId = (id) => `${planDeletePrefix}${id}`

const BUTTON_IDS = {
  ACCESS_MENU: 'admin_access_menu',
  ACCESS_LOOKUP: 'admin_access_lookup',
  ACCESS_RENEW_LOGIN: 'admin_access_renew_login',
  ACCESS_DELETE_LOGIN: 'admin_access_delete_login',
  ADMIN_MENU_3: 'admin_menu_3',
  NOTIFY_MENU: 'admin_notify_menu',
  NOTIFY_SET_BEFORE_3D: 'admin_notify_set_before_3d',
  NOTIFY_SET_AFTER_7D: 'admin_notify_set_after_7d',
  NOTIFY_SET_EXPIRES_DAY: 'admin_notify_set_expires_day',
  NOTIFY_TEMPLATES_MENU: 'admin_notify_templates_menu',
  NOTIFY_TEMPLATE_BEFORE_3D: 'admin_notify_tpl_before_3d',
  NOTIFY_TEMPLATE_EXPIRES_DAY: 'admin_notify_tpl_expires_day',
  NOTIFY_TEMPLATE_AFTER_7D: 'admin_notify_tpl_after_7d',
  VIEW_SUPPORTS: 'admin_view_supports',
  REMOVE_ALL_TESTS: 'admin_rm_all_tests',
  REMOVE_TEST: 'admin_rm_test',
  CREATE_VIP: 'admin_create_vip',
  BROADCAST: 'admin_broadcast',
  DASHBOARD: 'admin_dashboard',
  FINANCE_MENU: 'admin_finance_menu',
  PAYMENTS_MENU: 'admin_payments_menu',
  PAYMENTS_PENDING: 'admin_payments_pending',
  PAYMENTS_APPROVED: 'admin_payments_approved',
  PAYMENTS_REFUNDED: 'admin_payments_refunded',
  PAYMENTS_EXPIRED: 'admin_payments_expired',
  COUPON_CREATE: 'admin_coupon_create',
  COUPON_LIST: 'admin_coupon_list',
  COUPON_DELETE: 'admin_coupon_delete',
  MARKETING_MENU: 'admin_marketing_menu',
  TEMPLATES_MENU: 'admin_templates_menu',
  TEMPLATE_CREATE: 'admin_template_create',
  TEMPLATE_LIST: 'admin_template_list',
  TEMPLATE_DELETE: 'admin_template_delete',
  BROADCAST_JOBS_LIST: 'admin_broadcast_jobs_list',
  LOGS_MENU: 'admin_logs_menu',
  LOGS_VIEW: 'admin_logs_view',
  LOGS_CLEAR: 'admin_logs_clear',
  LOGS_CLEAR_CONFIRM: 'admin_logs_clear_confirm',
  BACKUP_NOW: 'admin_backup_now',
  CONFIG_MENU: 'admin_config_menu',
  TEXTS_MENU: 'admin_texts_menu',
  TEXTS_MENU_WELCOME: 'admin_texts_menu_welcome',
  TEXTS_MENU_TESTS: 'admin_texts_menu_tests',
  TEXTS_MENU_PURCHASES: 'admin_texts_menu_purchases',
  TEXTS_MENU_FAQ: 'admin_texts_menu_faq',
  PLANS_MENU: 'admin_plans_menu',
  PLAN_CREATE: 'admin_plan_create',
  PLAN_DELETE: 'admin_plan_delete',
  APP_LINK_SET: 'admin_app_link_set',
  PURCHASE_REMOVE: 'admin_purchase_remove',
  TESTS_MENU: 'admin_tests_menu',
  SECURITY_MENU: 'admin_security_menu',
  ADMIN_BACK_MAIN: 'admin_back_main',
  REMOVE_NUMBER: 'admin_rm_number',
  BLOCK_NUMBER: 'admin_block_number',
  UNBLOCK_NUMBER: 'admin_unblock_number',
  VIEW_BLOCKED: 'admin_view_blocked',
  VIEW_STATS: 'admin_view_stats',
  ADMIN_MENU_2: 'admin_menu_2'
}

let adminState = {
  awaitingTestInput: false,
  awaitingVipLogin: false,
  awaitingRenewLogin: false,
  awaitingRemoveNumber: false,
  awaitingBlockNumber: false,
  awaitingUnblockNumber: false,
  awaitingAccessLookup: false,
  awaitingAccessDelete: false,
  awaitingNotifyBefore3dTime: false,
  awaitingNotifyAfter7dTime: false,
  awaitingNotifyExpiresDayTime: false,
  awaitingNotifyTemplateBefore3d: false,
  awaitingNotifyTemplateExpiresDay: false,
  awaitingNotifyTemplateAfter7d: false,
  awaitingAppLinkSet: false,
  awaitingPurchaseRemove: false,
  awaitingCouponCreate: false,
  awaitingCouponDelete: false,
  awaitingTemplateCreate: false,
  awaitingTemplateDelete: false,
  awaitingTextEdit: false,
  awaitingPlanValue: false,
  awaitingPlanLimit: false,
  awaitingPlanDays: false,
  awaitingPlanLabel: false
}

let textEditContext = { key: null, returnMenu: null }
let planContext = { mode: null, id: null, amount: null, limit: null, days: null, label: null }

function resetState() {
  adminState = {
    awaitingTestInput: false,
    awaitingVipLogin: false,
    awaitingRenewLogin: false,
    awaitingRemoveNumber: false,
    awaitingBlockNumber: false,
    awaitingUnblockNumber: false,
    awaitingAccessLookup: false,
    awaitingAccessDelete: false,
    awaitingNotifyBefore3dTime: false,
    awaitingNotifyAfter7dTime: false,
    awaitingNotifyExpiresDayTime: false,
    awaitingNotifyTemplateBefore3d: false,
    awaitingNotifyTemplateExpiresDay: false,
    awaitingNotifyTemplateAfter7d: false,
    awaitingAppLinkSet: false,
    awaitingPurchaseRemove: false,
    awaitingCouponCreate: false,
    awaitingCouponDelete: false,
    awaitingTemplateCreate: false,
    awaitingTemplateDelete: false,
    awaitingTextEdit: false,
    awaitingPlanValue: false,
    awaitingPlanLimit: false,
    awaitingPlanDays: false,
    awaitingPlanLabel: false
  }
  textEditContext = { key: null, returnMenu: null }
  planContext = { mode: null, id: null, amount: null, limit: null, days: null, label: null }
}

function isAdminCommand(text) {
  return ADMIN_COMMANDS.includes(text?.toLowerCase?.())
}

async function showAdminPanel(sock) {
  const totalUsers = users.count()
  const totalBlocked = blocked.getAll().length
  
  const primaryButtons = [
    { id: BUTTON_IDS.ACCESS_MENU, text: '🔐 Acessos' },
    { id: BUTTON_IDS.DASHBOARD, text: '📊 Dashboard' },
    { id: BUTTON_IDS.PAYMENTS_MENU, text: '💳 Pagamentos' },
    { id: BUTTON_IDS.VIEW_SUPPORTS, text: '📋 Suportes' }
  ]

  const moreButton = { id: BUTTON_IDS.ADMIN_MENU_2, text: '➡️ Mais opções' }
  const buttons = [...primaryButtons, moreButton]

  await sendButtons(sock, adminJid, {
    text: [
      '🔐 *PAINEL ADMINISTRATIVO*',
      '',
      `> 👥 _Usuários:_ *${totalUsers}*`,
      `> 🚫 _Bloqueados:_ *${totalBlocked}*`,
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons
  })
  return true
}

async function showAdminMenu2(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '🔐 *PAINEL ADMIN — Menu 2/3*',
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.MARKETING_MENU, text: '🎯 Marketing' },
      { id: BUTTON_IDS.FINANCE_MENU, text: '💰 Cupons' },
      { id: BUTTON_IDS.NOTIFY_MENU, text: '⏰ Notificações' },
      { id: BUTTON_IDS.ADMIN_BACK_MAIN, text: '◀️ Voltar' },
      { id: BUTTON_IDS.ADMIN_MENU_3, text: '➡️ Mais opções' }
    ]
  })
  return true
}

async function showAdminMenu3(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '🔐 *PAINEL ADMIN — Menu 3/3*',
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.BACKUP_NOW, text: '💾 Backup' },
      { id: BUTTON_IDS.CONFIG_MENU, text: '⚙️ Configurações' },
      { id: BUTTON_IDS.LOGS_MENU, text: '📜 Logs admin' },
      { id: BUTTON_IDS.VIEW_STATS, text: '📈 Estatísticas' },
      { id: BUTTON_IDS.ADMIN_MENU_2, text: '◀️ Voltar' }
    ]
  })
  return true
}

const isValidTimeKey = (value) => /^\d{2}:\d{2}$/.test(String(value || '').trim())
const defaultTime = '09:00'
const formatTimeKey = (raw) => String(raw || '').trim()

const notifyConfig = () => ({
  before3d: systemState.get('notify_before_3d_time') || defaultTime,
  expiresDay: systemState.get('notify_expires_day_time') || defaultTime,
  after7d: systemState.get('notify_after_7d_time') || defaultTime
})

async function showNotifyMenu(sock) {
  const cfg = notifyConfig()
  await sendButtons(sock, adminJid, {
    text: [
      '⏰ *NOTIFICAÇÕES*',
      '',
      `> 3 dias antes: *${cfg.before3d}*`,
      `> No dia: *${cfg.expiresDay}*`,
      `> 7 dias depois: *${cfg.after7d}*`,
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.NOTIFY_TEMPLATES_MENU, text: '✏️ Editar textos' },
      { id: BUTTON_IDS.NOTIFY_SET_BEFORE_3D, text: '🗓️ Definir 3 dias antes' },
      { id: BUTTON_IDS.NOTIFY_SET_EXPIRES_DAY, text: '📅 Definir no dia' },
      { id: BUTTON_IDS.NOTIFY_SET_AFTER_7D, text: '⏳ Definir 7 dias depois' },
      { id: BUTTON_IDS.ADMIN_MENU_2, text: '◀️ Voltar' }
    ]
  })
  return true
}

const promptTimeSet = async (sock, title, stateKey) => {
  resetState()
  adminState[stateKey] = true
  await sendText(sock, adminJid, [
    title,
    '',
    'Envie no formato:',
    '> HH:MM',
    '',
    'Exemplos:',
    '> 09:00',
    '> 21:30'
  ].join('\n'), false)
}

async function promptNotifyBefore3d(sock) {
  return promptTimeSet(sock, '🗓️ *Definir horário — 3 dias antes*', 'awaitingNotifyBefore3dTime')
}

async function promptNotifyExpiresDay(sock) {
  return promptTimeSet(sock, '📅 *Definir horário — no dia do vencimento*', 'awaitingNotifyExpiresDayTime')
}

async function promptNotifyAfter7d(sock) {
  return promptTimeSet(sock, '⏳ *Definir horário — 7 dias depois*', 'awaitingNotifyAfter7dTime')
}

const saveNotifyTime = (key, timeKey) => {
  const value = formatTimeKey(timeKey)
  if (!isValidTimeKey(value)) return { ok: false, error: 'Horário inválido. Use HH:MM' }
  systemState.set(key, value)
  return { ok: true, value }
}

async function handleNotifyBefore3dInput({ sock, text }) {
  if (!adminState.awaitingNotifyBefore3dTime) return false
  adminState.awaitingNotifyBefore3dTime = false
  const res = saveNotifyTime('notify_before_3d_time', text)
  if (!res.ok) {
    await sendText(sock, adminJid, `❌ ${res.error}`, false)
    return true
  }
  audit('notify_time_set', { key: 'before_3d', value: res.value })
  await sendText(sock, adminJid, `✅ Horário atualizado: *${res.value}*`, false)
  await showNotifyMenu(sock)
  return true
}

async function handleNotifyExpiresDayInput({ sock, text }) {
  if (!adminState.awaitingNotifyExpiresDayTime) return false
  adminState.awaitingNotifyExpiresDayTime = false
  const res = saveNotifyTime('notify_expires_day_time', text)
  if (!res.ok) {
    await sendText(sock, adminJid, `❌ ${res.error}`, false)
    return true
  }
  audit('notify_time_set', { key: 'expires_day', value: res.value })
  await sendText(sock, adminJid, `✅ Horário atualizado: *${res.value}*`, false)
  await showNotifyMenu(sock)
  return true
}

async function handleNotifyAfter7dInput({ sock, text }) {
  if (!adminState.awaitingNotifyAfter7dTime) return false
  adminState.awaitingNotifyAfter7dTime = false
  const res = saveNotifyTime('notify_after_7d_time', text)
  if (!res.ok) {
    await sendText(sock, adminJid, `❌ ${res.error}`, false)
    return true
  }
  audit('notify_time_set', { key: 'after_7d', value: res.value })
  await sendText(sock, adminJid, `✅ Horário atualizado: *${res.value}*`, false)
  await showNotifyMenu(sock)
  return true
}

const templateLabel = (key) => {
  const labels = {
    [notificationTemplateService.KEYS.BEFORE_3D]: '3 dias antes',
    [notificationTemplateService.KEYS.EXPIRES_DAY]: 'No dia',
    [notificationTemplateService.KEYS.AFTER_7D]: '7 dias depois'
  }
  return labels[key] || key
}

async function showNotifyTemplatesMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '✏️ *TEXTOS DE NOTIFICAÇÃO*',
      '',
      'Tokens:',
      '{login} {expiresAt} {appLink} {phone} {jid}',
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.NOTIFY_TEMPLATE_BEFORE_3D, text: `🗓️ ${templateLabel(notificationTemplateService.KEYS.BEFORE_3D)}` },
      { id: BUTTON_IDS.NOTIFY_TEMPLATE_EXPIRES_DAY, text: `📅 ${templateLabel(notificationTemplateService.KEYS.EXPIRES_DAY)}` },
      { id: BUTTON_IDS.NOTIFY_TEMPLATE_AFTER_7D, text: `⏳ ${templateLabel(notificationTemplateService.KEYS.AFTER_7D)}` },
      { id: BUTTON_IDS.NOTIFY_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

const promptTemplateEdit = async (sock, key, stateKey) => {
  resetState()
  adminState[stateKey] = true
  const current = notificationTemplateService.getTemplate(key)
  await sendText(sock, adminJid, [
    `✏️ *Editar texto — ${templateLabel(key)}*`,
    '',
    'Envie o novo texto completo.',
    '',
    'Tokens:',
    '{login} {expiresAt} {appLink} {phone} {jid}',
    '',
    '*Atual:*',
    current
  ].join('\n'), false)
}

async function promptTemplateBefore3d(sock) {
  return promptTemplateEdit(sock, notificationTemplateService.KEYS.BEFORE_3D, 'awaitingNotifyTemplateBefore3d')
}

async function promptTemplateExpiresDay(sock) {
  return promptTemplateEdit(sock, notificationTemplateService.KEYS.EXPIRES_DAY, 'awaitingNotifyTemplateExpiresDay')
}

async function promptTemplateAfter7d(sock) {
  return promptTemplateEdit(sock, notificationTemplateService.KEYS.AFTER_7D, 'awaitingNotifyTemplateAfter7d')
}

async function handleTemplateBefore3dInput({ sock, text }) {
  if (!adminState.awaitingNotifyTemplateBefore3d) return false
  adminState.awaitingNotifyTemplateBefore3d = false
  const res = notificationTemplateService.upsertTemplate({ key: notificationTemplateService.KEYS.BEFORE_3D, text })
  if (!res.ok) {
    await sendText(sock, adminJid, `❌ ${res.error}`, false)
    return true
  }
  audit('notify_template_set', { key: res.template.key })
  await sendText(sock, adminJid, '✅ Texto atualizado.', false)
  await showNotifyTemplatesMenu(sock)
  return true
}

async function handleTemplateExpiresDayInput({ sock, text }) {
  if (!adminState.awaitingNotifyTemplateExpiresDay) return false
  adminState.awaitingNotifyTemplateExpiresDay = false
  const res = notificationTemplateService.upsertTemplate({ key: notificationTemplateService.KEYS.EXPIRES_DAY, text })
  if (!res.ok) {
    await sendText(sock, adminJid, `❌ ${res.error}`, false)
    return true
  }
  audit('notify_template_set', { key: res.template.key })
  await sendText(sock, adminJid, '✅ Texto atualizado.', false)
  await showNotifyTemplatesMenu(sock)
  return true
}

async function handleTemplateAfter7dInput({ sock, text }) {
  if (!adminState.awaitingNotifyTemplateAfter7d) return false
  adminState.awaitingNotifyTemplateAfter7d = false
  const res = notificationTemplateService.upsertTemplate({ key: notificationTemplateService.KEYS.AFTER_7D, text })
  if (!res.ok) {
    await sendText(sock, adminJid, `❌ ${res.error}`, false)
    return true
  }
  audit('notify_template_set', { key: res.template.key })
  await sendText(sock, adminJid, '✅ Texto atualizado.', false)
  await showNotifyTemplatesMenu(sock)
  return true
}

async function showConfigMenu(sock) {
  const link = settingsService.getAppLink()
  await sendButtons(sock, adminJid, {
    text: [
      '⚙️ *CONFIGURAÇÕES*',
      '',
      `> App: _${link}_`,
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.TEXTS_MENU, text: '✏️ Textos' },
      { id: BUTTON_IDS.PLANS_MENU, text: '🧾 Planos' },
      { id: BUTTON_IDS.APP_LINK_SET, text: '📲 Alterar link do app' },
      { id: BUTTON_IDS.PURCHASE_REMOVE, text: '🗑️ Remover venda' },
      { id: BUTTON_IDS.SECURITY_MENU, text: '🛡️ Segurança' },
      { id: BUTTON_IDS.TESTS_MENU, text: '🧪 Testes' },
      { id: BUTTON_IDS.ADMIN_MENU_3, text: '◀️ Voltar' }
    ]
  })
  return true
}

const tokensLine = (tokens) => tokens.length ? `Tokens: ${tokens.join(' ')}` : 'Tokens: nenhum'

const resolveTextReturnMenu = (key) => {
  const normalized = String(key || '').trim()
  const menuKeys = textTemplateService.keysByCategory(textTemplateService.CATEGORIES.MENU)
  const testKeys = textTemplateService.keysByCategory(textTemplateService.CATEGORIES.TEST)
  const purchaseKeys = textTemplateService.keysByCategory(textTemplateService.CATEGORIES.PURCHASE)
  const faqKeys = textTemplateService.keysByCategory(textTemplateService.CATEGORIES.FAQ)
  if (menuKeys.includes(normalized)) return BUTTON_IDS.TEXTS_MENU_WELCOME
  if (testKeys.includes(normalized)) return BUTTON_IDS.TEXTS_MENU_TESTS
  if (purchaseKeys.includes(normalized)) return BUTTON_IDS.TEXTS_MENU_PURCHASES
  if (faqKeys.includes(normalized)) return BUTTON_IDS.TEXTS_MENU_FAQ
  return BUTTON_IDS.TEXTS_MENU
}

const returnToTextsMenu = (sock, menuId) => {
  const handlers = {
    [BUTTON_IDS.TEXTS_MENU]: () => showTextsMenu(sock),
    [BUTTON_IDS.TEXTS_MENU_WELCOME]: () => showTextsWelcomeMenu(sock),
    [BUTTON_IDS.TEXTS_MENU_TESTS]: () => showTextsTestsMenu(sock),
    [BUTTON_IDS.TEXTS_MENU_PURCHASES]: () => showTextsPurchasesMenu(sock),
    [BUTTON_IDS.TEXTS_MENU_FAQ]: () => showTextsFaqMenu(sock)
  }
  const handler = handlers[menuId]
  if (!handler) return showTextsMenu(sock)
  return handler()
}

async function showTextsMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '✏️ *TEXTOS*',
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.TEXTS_MENU_WELCOME, text: '👋 Boas-vindas' },
      { id: BUTTON_IDS.TEXTS_MENU_TESTS, text: '🧪 Testes' },
      { id: BUTTON_IDS.TEXTS_MENU_PURCHASES, text: '💳 Compras' },
      { id: BUTTON_IDS.TEXTS_MENU_FAQ, text: '❓ FAQ' },
      { id: BUTTON_IDS.CONFIG_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function showTextsWelcomeMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '👋 *TEXTOS — BOAS-VINDAS*',
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: textEditButtonId(textTemplateService.KEYS.MENU_WELCOME), text: '✅ Mensagem do menu' },
      { id: BUTTON_IDS.TEXTS_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function showTextsTestsMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '🧪 *TEXTOS — TESTES*',
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: textEditButtonId(textTemplateService.KEYS.TEST_ACTIVE), text: '⚠️ Teste ativo' },
      { id: textEditButtonId(textTemplateService.KEYS.TEST_EXPIRED), text: '⏰ Teste expirado' },
      { id: textEditButtonId(textTemplateService.KEYS.TEST_ERROR), text: '❌ Erro ao criar' },
      { id: textEditButtonId(textTemplateService.KEYS.TEST_CREATED), text: '✅ Teste criado' },
      { id: textEditButtonId(textTemplateService.KEYS.TEST_ADMIN_NOTIFY), text: '📩 Aviso admin' },
      { id: BUTTON_IDS.TEXTS_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function showTextsPurchasesMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '💳 *TEXTOS — COMPRAS*',
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_PLANS_MENU), text: '📋 Menu planos' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_PLAN_SELECTED), text: '💎 Plano selecionado' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_PIX_GENERATED), text: '✅ PIX gerado' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_PAYMENT_APPROVED), text: '✅ Pagamento aprovado' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_ACCESS_CREATED), text: '🎉 Acesso criado' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_PIX_EXPIRED), text: '⏰ PIX expirado' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_PAYMENT_REJECTED), text: '❌ Pagamento rejeitado' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_PAYMENT_REFUNDED), text: '⚠️ Pagamento estornado' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_PIX_ERROR), text: '❌ Erro PIX' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_ACCESS_ERROR), text: '❌ Erro acesso' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_ADMIN_START), text: '🧾 Admin compra' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_ADMIN_COMPLETED), text: '✅ Admin venda' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_ADMIN_REFUNDED), text: '⚠️ Admin estorno' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_COUPON_APPLIED), text: '🎟️ Cupom aplicado' },
      { id: textEditButtonId(textTemplateService.KEYS.PURCHASE_COUPON_ERROR), text: '❌ Cupom inválido' },
      { id: BUTTON_IDS.TEXTS_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function showTextsFaqMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '❓ *TEXTOS — FAQ*',
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: textEditButtonId(textTemplateService.KEYS.FAQ_Q1), text: '📲 APP' },
      { id: textEditButtonId(textTemplateService.KEYS.FAQ_Q2), text: '🔄 Renovação' },
      { id: textEditButtonId(textTemplateService.KEYS.FAQ_Q3), text: '💳 Pagamento' },
      { id: textEditButtonId(textTemplateService.KEYS.FAQ_Q4), text: '📶 Conexão' },
      { id: textEditButtonId(textTemplateService.KEYS.FAQ_Q5), text: '✅ Acesso' },
      { id: BUTTON_IDS.TEXTS_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function promptTextEdit(sock, key, returnMenu) {
  resetState()
  adminState.awaitingTextEdit = true
  textEditContext = { key, returnMenu }
  const tokens = textTemplateService.tokensForKey(key)
  const current = textTemplateService.getTemplate(key)
  await sendText(sock, adminJid, [
    '✏️ *Editar texto*',
    '',
    tokensLine(tokens),
    '',
    'Envie o novo texto completo:',
    '',
    '*Atual:*',
    current
  ].join('\n'), false)
}

async function handleTextEditInput({ sock, text }) {
  if (!adminState.awaitingTextEdit) return false
  adminState.awaitingTextEdit = false
  const { key, returnMenu } = textEditContext
  textEditContext = { key: null, returnMenu: null }
  const res = textTemplateService.upsertTemplate(key, text)
  if (!res.ok) {
    await sendText(sock, adminJid, `❌ ${res.error}`, false)
    await returnToTextsMenu(sock, returnMenu)
    return true
  }
  audit('text_template_set', { key })
  await sendText(sock, adminJid, '✅ Texto atualizado.', false)
  await returnToTextsMenu(sock, returnMenu)
  return true
}

const parseAmount = (value) => {
  const normalized = String(value || '').trim().replace(',', '.')
  const num = Number(normalized)
  if (!Number.isFinite(num)) return null
  if (num <= 0) return null
  return Math.round(num * 100) / 100
}

const parsePositiveInt = (value) => {
  const normalized = String(value || '').trim()
  const num = Number(normalized)
  if (!Number.isFinite(num)) return null
  const intVal = Math.floor(num)
  if (intVal <= 0) return null
  return intVal
}

const nextPlanId = () => {
  const list = plans.getAll()
  const nums = list
    .map(plan => String(plan.id || '').match(/^plan_(\d+)$/))
    .filter(Boolean)
    .map(match => Number(match[1]))
    .filter(Number.isFinite)
  const max = nums.reduce((acc, val) => Math.max(acc, val), 0)
  return `plan_${max + 1}`
}

const formatPlanSummary = (plan) => {
  if (!plan) return ''
  return `> Atual: *${plan.label}* (R$ ${plan.amount} / ${plan.days} dias / limite ${plan.limit})`
}

async function showPlansMenu(sock) {
  const list = plans.getAll()
  const planButtons = list.map(plan => ({
    id: planEditButtonId(plan.id),
    text: String(plan.label || '').slice(0, 40)
  }))
  const buttons = [
    ...planButtons,
    { id: BUTTON_IDS.PLAN_CREATE, text: '➕ Criar plano' },
    { id: BUTTON_IDS.PLAN_DELETE, text: '🗑️ Remover plano' },
    { id: BUTTON_IDS.CONFIG_MENU, text: '◀️ Voltar' }
  ]

  await sendButtons(sock, adminJid, {
    text: [
      '🧾 *PLANOS*',
      '',
      '_Selecione um plano para editar ou escolha uma ação:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons
  })
  return true
}

async function showPlanDeleteMenu(sock) {
  const list = plans.getAll()
  if (!list.length) {
    await sendText(sock, adminJid, '📭 Nenhum plano cadastrado.', false)
    await showPlansMenu(sock)
    return true
  }
  const buttons = [
    ...list.map(plan => ({ id: planDeleteButtonId(plan.id), text: String(plan.label || '').slice(0, 40) })),
    { id: BUTTON_IDS.PLANS_MENU, text: '◀️ Voltar' }
  ]
  await sendButtons(sock, adminJid, {
    text: [
      '🗑️ *Remover plano*',
      '',
      '_Selecione o plano:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons
  })
  return true
}

async function confirmPlanDelete(sock, planId) {
  const plan = plans.findById(planId)
  if (!plan) {
    await sendText(sock, adminJid, '❌ Plano não encontrado.', false)
    await showPlansMenu(sock)
    return true
  }
  await sendButtons(sock, adminJid, {
    text: [
      '⚠️ *Confirmar remoção do plano*',
      '',
      `> ID: *${plan.id}*`,
      `> Label: *${plan.label}*`,
      `> Valor: *R$ ${plan.amount}*`,
      `> Limite: *${plan.limit}*`,
      `> Dias: *${plan.days}*`,
      '',
      'Deseja remover este plano?'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: `${planDeleteConfirmPrefix}${plan.id}`, text: '✅ Confirmar' },
      { id: BUTTON_IDS.PLANS_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function deletePlan(sock, planId) {
  const removed = plans.remove(planId)
  if (!removed) {
    await sendText(sock, adminJid, '❌ Falha ao remover.', false)
    await showPlansMenu(sock)
    return true
  }
  audit('plan_remove', { id: planId })
  await sendText(sock, adminJid, '✅ Plano removido.', false)
  await showPlansMenu(sock)
  return true
}

async function promptPlanValue(sock) {
  adminState.awaitingPlanValue = true
  const current = planContext.mode === 'edit' ? plans.findById(planContext.id) : null
  const info = formatPlanSummary(current)
  await sendText(sock, adminJid, [
    '💰 *Definir valor do plano*',
    '',
    info,
    '',
    'Envie o valor (ex: 18.00):'
  ].filter(Boolean).join('\n'), false)
}

async function promptPlanLimit(sock) {
  adminState.awaitingPlanLimit = true
  await sendText(sock, adminJid, [
    '👥 *Definir limite*',
    '',
    'Envie o limite de conexões (ex: 1):'
  ].join('\n'), false)
}

async function promptPlanDays(sock) {
  adminState.awaitingPlanDays = true
  await sendText(sock, adminJid, [
    '📅 *Definir dias*',
    '',
    'Envie a quantidade de dias (ex: 30):'
  ].join('\n'), false)
}

async function promptPlanLabel(sock) {
  adminState.awaitingPlanLabel = true
  await sendText(sock, adminJid, [
    '🏷️ *Texto do botão*',
    '',
    'Envie o texto que será exibido no botão:'
  ].join('\n'), false)
}

async function startPlanCreate(sock) {
  resetState()
  planContext = { mode: 'create', id: null, amount: null, limit: null, days: null, label: null }
  await promptPlanValue(sock)
}

async function startPlanEdit(sock, planId) {
  const plan = plans.findById(planId)
  if (!plan) {
    await sendText(sock, adminJid, '❌ Plano não encontrado.', false)
    await showPlansMenu(sock)
    return true
  }
  resetState()
  planContext = { mode: 'edit', id: planId, amount: null, limit: null, days: null, label: null }
  await promptPlanValue(sock)
  return true
}

async function handlePlanValueInput({ sock, text }) {
  if (!adminState.awaitingPlanValue) return false
  adminState.awaitingPlanValue = false
  const amount = parseAmount(text)
  if (!amount) {
    adminState.awaitingPlanValue = true
    await sendText(sock, adminJid, '❌ Valor inválido. Envie um valor positivo.', false)
    return true
  }
  planContext.amount = amount
  await promptPlanLimit(sock)
  return true
}

async function handlePlanLimitInput({ sock, text }) {
  if (!adminState.awaitingPlanLimit) return false
  adminState.awaitingPlanLimit = false
  const limit = parsePositiveInt(text)
  if (!limit) {
    adminState.awaitingPlanLimit = true
    await sendText(sock, adminJid, '❌ Limite inválido. Envie um inteiro positivo.', false)
    return true
  }
  planContext.limit = limit
  await promptPlanDays(sock)
  return true
}

async function handlePlanDaysInput({ sock, text }) {
  if (!adminState.awaitingPlanDays) return false
  adminState.awaitingPlanDays = false
  const days = parsePositiveInt(text)
  if (!days) {
    adminState.awaitingPlanDays = true
    await sendText(sock, adminJid, '❌ Dias inválidos. Envie um inteiro positivo.', false)
    return true
  }
  planContext.days = days
  await promptPlanLabel(sock)
  return true
}

async function handlePlanLabelInput({ sock, text }) {
  if (!adminState.awaitingPlanLabel) return false
  adminState.awaitingPlanLabel = false
  const label = String(text || '').trim()
  if (!label) {
    adminState.awaitingPlanLabel = true
    await sendText(sock, adminJid, '❌ Texto inválido. Envie novamente.', false)
    return true
  }
  planContext.label = label
  const missing = [planContext.amount, planContext.limit, planContext.days].some(val => val == null)
  if (missing) {
    resetState()
    await sendText(sock, adminJid, '❌ Dados do plano incompletos. Inicie novamente.', false)
    await showPlansMenu(sock)
    return true
  }
  const mode = planContext.mode
  const id = mode === 'edit' ? planContext.id : nextPlanId()
  const data = {
    id,
    label: planContext.label,
    amount: planContext.amount,
    limit: planContext.limit,
    days: planContext.days
  }
  const saved = plans.create(data)
  resetState()
  if (!saved) {
    await sendText(sock, adminJid, '❌ Falha ao salvar o plano.', false)
    await showPlansMenu(sock)
    return true
  }
  const action = mode === 'edit' ? 'plan_update' : 'plan_create'
  audit(action, { id: saved.id })
  await sendText(sock, adminJid, `✅ Plano salvo: *${saved.label}*`, false)
  await showPlansMenu(sock)
  return true
}

async function showSecurityMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '🛡️ *SEGURANÇA*',
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.BLOCK_NUMBER, text: '🚫 Bloquear número' },
      { id: BUTTON_IDS.UNBLOCK_NUMBER, text: '✅ Desbloquear número' },
      { id: BUTTON_IDS.VIEW_BLOCKED, text: '📋 Ver bloqueados' },
      { id: BUTTON_IDS.REMOVE_NUMBER, text: '🗑️ Remover número' },
      { id: BUTTON_IDS.CONFIG_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function showTestsMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '🧪 *TESTES*',
      '',
      '_Selecione:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.REMOVE_TEST, text: '❌ Remover teste' },
      { id: BUTTON_IDS.REMOVE_ALL_TESTS, text: '🗑️ Remover todos testes' },
      { id: BUTTON_IDS.CONFIG_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function promptAppLinkSet(sock) {
  resetState()
  adminState.awaitingAppLinkSet = true
  await sendText(sock, adminJid, [
    '📲 *Alterar link do app*',
    '',
    'Envie o novo link:'
  ].join('\n'), false)
}

async function handleAppLinkSetInput({ sock, text }) {
  if (!adminState.awaitingAppLinkSet) return false
  adminState.awaitingAppLinkSet = false
  const res = settingsService.setAppLink(text)
  if (!res.ok) {
    await sendText(sock, adminJid, `❌ ${res.error}`, false)
    return true
  }
  audit('app_link_set', { value: res.value })
  await sendText(sock, adminJid, `✅ Link atualizado: _${res.value}_`, false)
  await showConfigMenu(sock)
  return true
}

async function promptPurchaseRemove(sock) {
  resetState()
  adminState.awaitingPurchaseRemove = true
  await sendText(sock, adminJid, [
    '🗑️ *Remover venda*',
    '',
    'Envie o ID da venda (purchase id):'
  ].join('\n'), false)
}

async function handlePurchaseRemoveInput({ sock, text }) {
  if (!adminState.awaitingPurchaseRemove) return false
  adminState.awaitingPurchaseRemove = false

  const id = String(text || '').trim()
  const found = purchases.findById(id)
  if (!found) {
    await sendText(sock, adminJid, '❌ Venda não encontrada.', false)
    return true
  }

  await sendButtons(sock, adminJid, {
    text: [
      '⚠️ *Confirmar remoção da venda*',
      '',
      `> ID: *${found.id}*`,
      `> Telefone: _${formatPhoneLink(found.phone)}_`,
      `> Plano: *${found.planLabel}*`,
      '',
      'Deseja remover esta venda do banco?'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: `admin_purchase_remove_confirm_${found.id}`, text: '✅ Confirmar' },
      { id: BUTTON_IDS.CONFIG_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function confirmPurchaseRemove(sock, purchaseId) {
  const removed = purchases.removeById(purchaseId)
  if (!removed) {
    await sendText(sock, adminJid, '❌ Falha ao remover.', false)
    return true
  }
  audit('purchase_remove', { id: removed.id, phone: removed.phone })
  await sendText(sock, adminJid, '✅ Venda removida.', false)
  await showConfigMenu(sock)
  return true
}

async function showAccessMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '🔐 *ACESSOS*',
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: sortButtonsAlpha([
      { id: BUTTON_IDS.ACCESS_LOOKUP, text: '🔎 Buscar' },
      { id: BUTTON_IDS.CREATE_VIP, text: '⭐ Criar VIP' },
      { id: BUTTON_IDS.ACCESS_DELETE_LOGIN, text: '🗑️ Excluir login' },
      { id: BUTTON_IDS.ACCESS_RENEW_LOGIN, text: '🔄 Renovar login' },
      { id: BUTTON_IDS.ADMIN_BACK_MAIN, text: '◀️ Voltar' }
    ])
  })
  return true
}

const extractDigits = (value) => String(value || '').replace(/\D/g, '')
const isPhoneDigits = (digits) => digits.length >= 10

const findUserFromPanel = (result, login) => {
  const users = result?.data?.usuarios || []
  return users.find(u => u.login === login) || null
}

async function promptAccessLookup(sock) {
  resetState()
  adminState.awaitingAccessLookup = true
  await sendText(sock, adminJid, [
    '🔎 *Buscar acesso*',
    '',
    'Envie um *login* ou *telefone*:',
    '> mv1234',
    '> 5562999999999'
  ].join('\n'), false)
}

async function handleAccessLookupInput({ sock, text }) {
  if (!adminState.awaitingAccessLookup) return false
  adminState.awaitingAccessLookup = false

  const raw = String(text || '').trim()
  const digits = extractDigits(raw)

  const byPhone = isPhoneDigits(digits)
  const phone = byPhone ? digits : null
  const loginInput = byPhone ? null : raw

  const fromAccess = phone ? accesses.findLatestByPhone(phone) : accesses.findByLogin(loginInput)
  const fromPurchase = phone ? purchases.findCompletedByPhone(phone) : purchases.getAll().find(p => p.login === loginInput && p.stage === 'completed')

  const login = fromAccess?.login || fromPurchase?.login || loginInput
  if (!login) {
    await sendText(sock, adminJid, '❌ Não encontrei o login para esta busca.', false)
    return true
  }

  try {
    const userResult = await panelApi.getUser(login)
    const user = findUserFromPanel(userResult, login)
    const onlineList = await panelApi.listOnline()
    const online = Array.isArray(onlineList) ? onlineList.some(o => o?.login === login) : false

    const resolvedPhone = fromAccess?.phone || fromPurchase?.phone || phone
    const link = resolvedPhone ? formatPhoneLink(resolvedPhone) : 'N/A'
    const status = user?.status || 'indisponível'
    const expira = user?.expira_formatada || user?.expira || 'indisponível'
    const dias = user?.dias_restantes != null ? `${user.dias_restantes} dia(s)` : 'N/A'
    const limite = user?.limite != null ? `${user.limite}` : 'N/A'

    await sendText(sock, adminJid, [
      '🔎 *Acesso encontrado*',
      '',
      `> Login: *${login}*`,
      `> Telefone: _${link}_`,
      `> Status: *${status}*`,
      `> Expira: _${expira}_`,
      `> Dias restantes: *${dias}*`,
      `> Limite: *${limite}*`,
      `> Online agora: *${online ? 'sim' : 'não'}*`
    ].join('\n'), false)
    audit('access_lookup', { login, phone: resolvedPhone || null })
    return true
  } catch (error) {
    await sendText(sock, adminJid, `❌ Erro ao buscar no painel: ${error.message}`, false)
    return true
  }
}

async function promptRenewLogin(sock) {
  resetState()
  adminState.awaitingRenewLogin = true
  await sendText(sock, adminJid, '🔄 *Renovar login*\n\nEnvie o login:', false)
}

async function promptAccessDelete(sock) {
  resetState()
  adminState.awaitingAccessDelete = true
  await sendText(sock, adminJid, [
    '🗑️ *Excluir login*',
    '',
    'Envie o login que deseja excluir:'
  ].join('\n'), false)
}

async function handleAccessDeleteInput({ sock, text }) {
  if (!adminState.awaitingAccessDelete) return false
  adminState.awaitingAccessDelete = false

  const login = String(text || '').trim()
  if (!login) {
    await sendText(sock, adminJid, '❌ Login inválido.', false)
    return true
  }

  await sendButtons(sock, adminJid, {
    text: [
      '⚠️ *Confirmar exclusão*',
      '',
      `Login: *${login}*`,
      '',
      'Deseja excluir este login do painel?'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: `admin_access_delete_confirm_${login}`, text: '✅ Confirmar' },
      { id: BUTTON_IDS.ACCESS_MENU, text: '◀️ Voltar' }
    ]
  })
  return true
}

async function confirmDeleteAccess(sock, login) {
  const value = String(login || '').trim()
  if (!value) {
    await sendText(sock, adminJid, '❌ Login inválido.', false)
    return false
  }

  try {
    await panelApi.deleteUser(value)
    const removed = accesses.removeByLogin ? accesses.removeByLogin(value) : false
    audit('access_delete', { login: value, localRemoved: Boolean(removed) })
    await sendText(sock, adminJid, `✅ Login *${value}* excluído.`, false)
    return true
  } catch (error) {
    await sendText(sock, adminJid, `❌ Falha ao excluir: ${error.message}`, false)
    return true
  }
}

async function showPaymentsMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      paymentMonitorService.buildSummaryMessage(7),
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: sortButtonsAlpha([
      { id: BUTTON_IDS.PAYMENTS_APPROVED, text: '✅ Aprovados' },
      { id: BUTTON_IDS.PAYMENTS_EXPIRED, text: '⏰ Expirados/Cancelados' },
      { id: BUTTON_IDS.PAYMENTS_PENDING, text: '🕒 Pendentes' },
      { id: BUTTON_IDS.PAYMENTS_REFUNDED, text: '⚠️ Estornados' },
      { id: BUTTON_IDS.FINANCE_MENU, text: '◀️ Voltar' }
    ])
  })
  return true
}

const paymentGroups = {
  pending: BUTTON_IDS.PAYMENTS_PENDING,
  approved: BUTTON_IDS.PAYMENTS_APPROVED,
  refunded: BUTTON_IDS.PAYMENTS_REFUNDED,
  expired: BUTTON_IDS.PAYMENTS_EXPIRED
}

async function showPaymentsList(sock, groupKey) {
  const valid = Object.keys(paymentGroups).includes(groupKey)
  if (!valid) {
    await sendText(sock, adminJid, '❌ Opção inválida.', false)
    return true
  }

  await sendText(sock, adminJid, paymentMonitorService.buildListMessage(groupKey, 20), false)
  await showPaymentsMenu(sock)
  audit('payments_list', { group: groupKey })
  return true
}

async function handleAdminButton({ sock, buttonId }) {
  const dynamicHandlers = [
    {
      match: (id) => String(id || '').startsWith('admin_access_delete_confirm_'),
      run: (id) => confirmDeleteAccess(sock, id.slice('admin_access_delete_confirm_'.length))
    },
    {
      match: (id) => String(id || '').startsWith('admin_purchase_remove_confirm_'),
      run: (id) => confirmPurchaseRemove(sock, id.slice('admin_purchase_remove_confirm_'.length))
    },
    {
      match: (id) => String(id || '').startsWith(planDeleteConfirmPrefix),
      run: (id) => deletePlan(sock, id.slice(planDeleteConfirmPrefix.length))
    },
    {
      match: (id) => String(id || '').startsWith(textEditPrefix),
      run: (id) => promptTextEdit(sock, id.slice(textEditPrefix.length), resolveTextReturnMenu(id.slice(textEditPrefix.length)))
    },
    {
      match: (id) => String(id || '').startsWith(planEditPrefix),
      run: (id) => startPlanEdit(sock, id.slice(planEditPrefix.length))
    },
    {
      match: (id) => String(id || '').startsWith(planDeletePrefix),
      run: (id) => confirmPlanDelete(sock, id.slice(planDeletePrefix.length))
    }
  ]

  const dynamic = dynamicHandlers.find(h => h.match(buttonId))
  if (dynamic) {
    await dynamic.run(buttonId)
    return true
  }

  const handlers = {
    [BUTTON_IDS.ACCESS_MENU]: () => showAccessMenu(sock),
    [BUTTON_IDS.ACCESS_LOOKUP]: () => promptAccessLookup(sock),
    [BUTTON_IDS.ACCESS_RENEW_LOGIN]: () => promptRenewLogin(sock),
    [BUTTON_IDS.ACCESS_DELETE_LOGIN]: () => promptAccessDelete(sock),
    [BUTTON_IDS.NOTIFY_MENU]: () => showNotifyMenu(sock),
    [BUTTON_IDS.NOTIFY_SET_BEFORE_3D]: () => promptNotifyBefore3d(sock),
    [BUTTON_IDS.NOTIFY_SET_EXPIRES_DAY]: () => promptNotifyExpiresDay(sock),
    [BUTTON_IDS.NOTIFY_SET_AFTER_7D]: () => promptNotifyAfter7d(sock),
    [BUTTON_IDS.NOTIFY_TEMPLATES_MENU]: () => showNotifyTemplatesMenu(sock),
    [BUTTON_IDS.NOTIFY_TEMPLATE_BEFORE_3D]: () => promptTemplateBefore3d(sock),
    [BUTTON_IDS.NOTIFY_TEMPLATE_EXPIRES_DAY]: () => promptTemplateExpiresDay(sock),
    [BUTTON_IDS.NOTIFY_TEMPLATE_AFTER_7D]: () => promptTemplateAfter7d(sock),
    [BUTTON_IDS.DASHBOARD]: () => showDashboard(sock),
    [BUTTON_IDS.VIEW_SUPPORTS]: () => viewSupports(sock),
    [BUTTON_IDS.REMOVE_ALL_TESTS]: () => removeAllTests(sock),
    [BUTTON_IDS.REMOVE_TEST]: () => promptRemoveTest(sock),
    [BUTTON_IDS.CREATE_VIP]: () => promptCreateVip(sock),
    [BUTTON_IDS.BROADCAST]: () => broadcastService.startBroadcast({ sock }),
    [BUTTON_IDS.FINANCE_MENU]: () => showFinanceMenu(sock),
    [BUTTON_IDS.PAYMENTS_MENU]: () => showPaymentsMenu(sock),
    [BUTTON_IDS.PAYMENTS_PENDING]: () => showPaymentsList(sock, 'pending'),
    [BUTTON_IDS.PAYMENTS_APPROVED]: () => showPaymentsList(sock, 'approved'),
    [BUTTON_IDS.PAYMENTS_REFUNDED]: () => showPaymentsList(sock, 'refunded'),
    [BUTTON_IDS.PAYMENTS_EXPIRED]: () => showPaymentsList(sock, 'expired'),
    [BUTTON_IDS.MARKETING_MENU]: () => showMarketingMenu(sock),
    [BUTTON_IDS.TEMPLATES_MENU]: () => showTemplatesMenu(sock),
    [BUTTON_IDS.TEMPLATE_CREATE]: () => promptTemplateCreate(sock),
    [BUTTON_IDS.TEMPLATE_LIST]: () => listTemplates(sock),
    [BUTTON_IDS.TEMPLATE_DELETE]: () => promptTemplateDelete(sock),
    [BUTTON_IDS.BROADCAST_JOBS_LIST]: () => listBroadcastJobs(sock),
    [BUTTON_IDS.LOGS_MENU]: () => showLogsMenu(sock),
    [BUTTON_IDS.LOGS_VIEW]: () => viewAdminLogs(sock),
    [BUTTON_IDS.LOGS_CLEAR]: () => confirmClearAdminLogs(sock),
    [BUTTON_IDS.LOGS_CLEAR_CONFIRM]: () => clearAdminLogs(sock),
    [BUTTON_IDS.BACKUP_NOW]: () => backupNow(sock),
    [BUTTON_IDS.COUPON_CREATE]: () => promptCreateCoupon(sock),
    [BUTTON_IDS.COUPON_LIST]: () => listCoupons(sock),
    [BUTTON_IDS.COUPON_DELETE]: () => promptDeleteCoupon(sock),
    [BUTTON_IDS.CONFIG_MENU]: () => showConfigMenu(sock),
    [BUTTON_IDS.TEXTS_MENU]: () => showTextsMenu(sock),
    [BUTTON_IDS.TEXTS_MENU_WELCOME]: () => showTextsWelcomeMenu(sock),
    [BUTTON_IDS.TEXTS_MENU_TESTS]: () => showTextsTestsMenu(sock),
    [BUTTON_IDS.TEXTS_MENU_PURCHASES]: () => showTextsPurchasesMenu(sock),
    [BUTTON_IDS.TEXTS_MENU_FAQ]: () => showTextsFaqMenu(sock),
    [BUTTON_IDS.PLANS_MENU]: () => showPlansMenu(sock),
    [BUTTON_IDS.PLAN_CREATE]: () => startPlanCreate(sock),
    [BUTTON_IDS.PLAN_DELETE]: () => showPlanDeleteMenu(sock),
    [BUTTON_IDS.SECURITY_MENU]: () => showSecurityMenu(sock),
    [BUTTON_IDS.TESTS_MENU]: () => showTestsMenu(sock),
    [BUTTON_IDS.APP_LINK_SET]: () => promptAppLinkSet(sock),
    [BUTTON_IDS.PURCHASE_REMOVE]: () => promptPurchaseRemove(sock),
    [BUTTON_IDS.ADMIN_BACK_MAIN]: () => showAdminPanel(sock),
    [BUTTON_IDS.REMOVE_NUMBER]: () => promptRemoveNumber(sock),
    [BUTTON_IDS.BLOCK_NUMBER]: () => promptBlockNumber(sock),
    [BUTTON_IDS.UNBLOCK_NUMBER]: () => promptUnblockNumber(sock),
    [BUTTON_IDS.VIEW_BLOCKED]: () => viewBlocked(sock),
    [BUTTON_IDS.VIEW_STATS]: () => viewStats(sock),
    [BUTTON_IDS.ADMIN_MENU_2]: () => showAdminMenu2(sock),
    [BUTTON_IDS.ADMIN_MENU_3]: () => showAdminMenu3(sock)
  }

  const handler = handlers[buttonId]
  if (!handler) return false
  await handler()
  return true
}

async function showDashboard(sock) {
  await sendButtons(sock, adminJid, {
    text: dashboardService.buildDashboardMessage(),
    footer: '© MASTER BOT',
    buttons: [{ id: BUTTON_IDS.ADMIN_BACK_MAIN, text: '◀️ Voltar' }]
  })
  audit('dashboard_view', null)
}

async function showFinanceMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '💰 *CUPONS*',
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: sortButtonsAlpha([
      { id: BUTTON_IDS.COUPON_CREATE, text: '🎟️ Criar cupom' },
      { id: BUTTON_IDS.COUPON_LIST, text: '📄 Listar cupons' },
      { id: BUTTON_IDS.COUPON_DELETE, text: '🗑️ Deletar cupom' },
      { id: BUTTON_IDS.ADMIN_MENU_2, text: '◀️ Voltar' }
    ])
  })
}

async function showMarketingMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '🎯 *MARKETING*',
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: sortButtonsAlpha([
      { id: BUTTON_IDS.BROADCAST, text: '📢 Broadcast' },
      { id: BUTTON_IDS.TEMPLATES_MENU, text: '📄 Templates' },
      { id: BUTTON_IDS.BROADCAST_JOBS_LIST, text: '📅 Agendamentos' },
      { id: BUTTON_IDS.ADMIN_BACK_MAIN, text: '◀️ Voltar' }
    ])
  })
}

async function showTemplatesMenu(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '📄 *TEMPLATES*',
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: sortButtonsAlpha([
      { id: BUTTON_IDS.TEMPLATE_CREATE, text: '➕ Criar template' },
      { id: BUTTON_IDS.TEMPLATE_LIST, text: '📋 Listar templates' },
      { id: BUTTON_IDS.TEMPLATE_DELETE, text: '🗑️ Excluir template' },
      { id: BUTTON_IDS.MARKETING_MENU, text: '◀️ Voltar' }
    ])
  })
}

async function promptTemplateCreate(sock) {
  resetState()
  adminState.awaitingTemplateCreate = true
  await sendText(sock, adminJid, [
    '➕ *Criar template*',
    '',
    'Envie no formato:',
    '> Nome|Mensagem',
    '',
    'Exemplo:',
    '> Promo|🔥 Promoção do dia...'
  ].join('\n'), false)
}

async function handleTemplateCreateInput({ sock, text }) {
  if (!adminState.awaitingTemplateCreate) return false
  adminState.awaitingTemplateCreate = false

  const raw = String(text || '')
  const idx = raw.indexOf('|')
  if (idx < 0) {
    await sendText(sock, adminJid, '❌ Formato inválido. Use Nome|Mensagem', false)
    return true
  }

  const name = raw.slice(0, idx).trim()
  const body = raw.slice(idx + 1).trim()
  if (!name || !body) {
    await sendText(sock, adminJid, '❌ Nome e mensagem são obrigatórios.', false)
    return true
  }

  const tpl = templates.create({ name: name.slice(0, 40), text: body })
  audit('template_create', { id: tpl.id, name: tpl.name })
  await sendText(sock, adminJid, `✅ Template criado: *${tpl.name}* (ID: *${tpl.id}*)`, false)
  await showTemplatesMenu(sock)
  return true
}

async function listTemplates(sock) {
  const list = templates.listAll().slice(0, 20)
  if (!list.length) {
    await sendText(sock, adminJid, '📭 Nenhum template cadastrado.', false)
    return
  }

  const lines = list.map(t => `• *${t.id}* — ${t.name}`)
  await sendText(sock, adminJid, ['📄 *Templates*', '', ...lines].join('\n'), false)
  await showTemplatesMenu(sock)
}

async function promptTemplateDelete(sock) {
  resetState()
  adminState.awaitingTemplateDelete = true
  await sendText(sock, adminJid, [
    '🗑️ *Excluir template*',
    '',
    'Envie o ID do template:',
    '> 2f0c...'
  ].join('\n'), false)
}

async function handleTemplateDeleteInput({ sock, text }) {
  if (!adminState.awaitingTemplateDelete) return false
  adminState.awaitingTemplateDelete = false

  const id = String(text || '').trim()
  const ok = templates.remove(id)
  if (!ok) {
    await sendText(sock, adminJid, '❌ Template não encontrado.', false)
    return true
  }

  await sendText(sock, adminJid, '✅ Template removido.', false)
  audit('template_delete', { id })
  await showTemplatesMenu(sock)
  return true
}

async function listBroadcastJobs(sock) {
  const list = broadcastJobs.listRecent(15)
  if (!list.length) {
    await sendText(sock, adminJid, '📭 Nenhum broadcast agendado encontrado.', false)
    return
  }

  const lines = list.map(j => {
    const sched = formatSpDate(j.scheduledAt)
    const replies = broadcastEvents.countByKind(j.id, 'reply')
    const delivered = broadcastEvents.countByKind(j.id, 'delivered')
    const read = broadcastEvents.countByKind(j.id, 'read')
    const stats = j.status === 'completed' ? `${j.sent}/${j.total} — 💬 ${replies} — 📬 ${delivered} — 👁️ ${read}` : `${j.status}`
    return `• *${j.id}* — ${sched} — ${j.segment} — ${stats}`
  })
  await sendText(sock, adminJid, ['📅 *Agendamentos*', '', ...lines].join('\n'), false)
  await showMarketingMenu(sock)
}

async function showLogsMenu(sock) {
  const total = logs.countByType ? logs.countByType('admin') : logs.getByType('admin', 1).length
  const label = Number.isFinite(total) ? `${total}` : 'N/A'
  await sendButtons(sock, adminJid, {
    text: [
      '📜 *LOGS ADMIN*',
      '',
      `> Registros: *${label}*`,
      '',
      '_Selecione uma opção:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: sortButtonsAlpha([
      { id: BUTTON_IDS.LOGS_VIEW, text: '📄 Ver logs' },
      { id: BUTTON_IDS.LOGS_CLEAR, text: '🧹 Limpar logs' },
      { id: BUTTON_IDS.ADMIN_MENU_2, text: '◀️ Voltar' }
    ])
  })
  return true
}

async function viewAdminLogs(sock) {
  const list = logs.getByType('admin', 25)
  if (!list.length) {
    await sendText(sock, adminJid, '📭 Nenhum log encontrado.', false)
    return
  }

  const lines = list.map(item => {
    const meta = item.data ? ` — ${JSON.stringify(item.data)}` : ''
    return `• _${formatSpDate(item.createdAt)}_ — ${item.message}${meta}`
  })
  await sendText(sock, adminJid, ['📜 *Logs admin*', '', ...lines].join('\n'), false)
  await showAdminMenu3(sock)
}

async function confirmClearAdminLogs(sock) {
  await sendButtons(sock, adminJid, {
    text: [
      '🧹 *Limpar logs admin*',
      '',
      '⚠️ Esta ação remove todos os logs do admin.',
      '',
      'Deseja continuar?'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons: [
      { id: BUTTON_IDS.LOGS_CLEAR_CONFIRM, text: '✅ Confirmar' },
      { id: BUTTON_IDS.LOGS_MENU, text: '◀️ Voltar' }
    ]
  })
}

async function clearAdminLogs(sock) {
  const changes = logs.clearByType ? logs.clearByType('admin') : 0
  logs.add('security', 'admin_logs_clear', { type: 'admin', changes })
  await sendText(sock, adminJid, `✅ Logs admin removidos: *${changes}*`, false)
  await showLogsMenu(sock)
  return true
}

async function backupNow(sock) {
  try {
    const created = await backupService.sendBackupZip({ sock, jid: adminJid, reason: 'manual' })
    audit('backup_manual', { fileName: created.fileName, dateKey: created.dateKey, timeKey: created.timeKey })
  } catch (error) {
    await sendText(sock, adminJid, `❌ Falha ao criar backup: ${error.message}`, false)
  }
}

async function promptCreateCoupon(sock) {
  resetState()
  adminState.awaitingCouponCreate = true
  await sendText(sock, adminJid, [
    '🎟️ *Criar cupom*',
    '',
    'Formato:',
    '> CODIGO TIPO VALOR MAX VALIDADE',
    '',
    'Exemplos:',
    '> PROMO10 percent 10 100 2026-02-10',
    '> FIX5 fixed 5 - -',
    '',
    '_Envie agora:_'
  ].join('\n'), false)
}

async function handleCouponCreateInput({ sock, text }) {
  if (!adminState.awaitingCouponCreate) return false
  adminState.awaitingCouponCreate = false

  const created = financeService.createCouponFromAdminText(text)
  if (!created.ok) {
    await sendText(sock, adminJid, `❌ ${created.error}`, false)
    return true
  }

  await sendText(sock, adminJid, [
    '✅ *Cupom criado/atualizado!*',
    '',
    `> Código: *${created.coupon.code}*`,
    `> Tipo: *${created.coupon.kind}*`,
    `> Valor: *${created.coupon.value}*`,
    `> Limite: *${created.coupon.maxUses || '∞'}*`,
    `> Validade: *${created.coupon.expiresAt || 'sem'}*`
  ].join('\n'), false)
  audit('coupon_upsert', { code: created.coupon.code })
  await showFinanceMenu(sock)
  return true
}

async function listCoupons(sock) {
  await sendText(sock, adminJid, financeService.listCoupons(15), false)
  await showFinanceMenu(sock)
}

async function promptDeleteCoupon(sock) {
  resetState()
  adminState.awaitingCouponDelete = true
  await sendText(sock, adminJid, [
    '🗑️ *Deletar cupom*',
    '',
    'Envie o código:',
    '> PROMO10'
  ].join('\n'), false)
}

async function handleCouponDeleteInput({ sock, text }) {
  if (!adminState.awaitingCouponDelete) return false
  adminState.awaitingCouponDelete = false

  const removed = financeService.deleteCoupon(text)
  if (!removed.ok) {
    await sendText(sock, adminJid, `❌ ${removed.error}`, false)
    return true
  }

  await sendText(sock, adminJid, `✅ Cupom *${removed.code}* removido.`, false)
  audit('coupon_delete', { code: removed.code })
  await showFinanceMenu(sock)
  return true
}

async function viewSupports(sock) {
  const open = supports.getOpen()
  audit('supports_view', { total: open.length })
  
  if (!open.length) {
    await sendText(sock, adminJid, [
      '✅ *Nenhum suporte pendente*',
      '',
      '> _Todos os pedidos foram atendidos._'
    ].join('\n'), false)
    return
  }

  const buttons = [
    ...open.slice(0, 5).map(item => ({
      id: `support_close_${item.id}`,
      text: `📱 ${item.phone || item.id.slice(0, 8)}`
    })),
    { id: BUTTON_IDS.ADMIN_BACK_MAIN, text: '◀️ Voltar' }
  ]

  await sendButtons(sock, adminJid, {
    text: [
      '📋 *SUPORTES EM ABERTO*',
      '',
      `> _Total:_ *${open.length}* pedido(s)`,
      '',
      '_Clique para encerrar:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons
  })
}

async function removeAllTests(sock) {
  const allTests = tests.getAllWithPhone()
  
  if (!allTests.length) {
    await sendText(sock, adminJid, [
      '✅ *Nenhum teste encontrado*',
      '',
      '> _Não há testes para remover._'
    ].join('\n'), false)
    return
  }

  await sendText(sock, adminJid, [
    '🗑️ *Removendo testes...*',
    '',
    `> _Total:_ *${allTests.length}* teste(s)`,
    '',
    '_Aguarde..._'
  ].join('\n'), false)

  let removed = 0
  for (const test of allTests) {
    if (!test.phone) continue

    const jid = `${test.phone}@s.whatsapp.net`
    try {
      await sendText(sock, jid, [
        '❌ *Seu teste foi removido!*',
        '',
        '> _O período de teste chegou ao fim._',
        '',
        '✨ Gostou? Adquira seu *acesso VIP*!',
        '📲 _Estamos à disposição._'
      ].join('\n'), false)
      removed++
    } catch {}
    await delay(2000)
  }

  tests.deleteAll()
  audit('tests_remove_all', { total: allTests.length, notified: removed })
  await sendText(sock, adminJid, [
    '✅ *Testes removidos com sucesso!*',
    '',
    `> _Removidos:_ *${removed}*`,
    `> _Total processado:_ *${allTests.length}*`
  ].join('\n'), false)
}

async function promptRemoveTest(sock) {
  adminState.awaitingTestInput = true
  await sendText(sock, adminJid, [
    '🔍 *Remover Teste*',
    '',
    '> Digite o *login* ou *telefone* do teste:',
    '',
    '_Exemplo: mv1234 ou 5562999999999_'
  ].join('\n'), false)
}

async function handleTestInput({ sock, text }) {
  if (!adminState.awaitingTestInput) return false
  adminState.awaitingTestInput = false

  const input = text.trim()
  let test = tests.findByLogin(input)
  if (!test) test = tests.findByPhone(input)

  if (!test) {
    await sendText(sock, adminJid, [
      '❌ *Teste não encontrado*',
      '',
      `> Busca: _${input}_`
    ].join('\n'), false)
    return true
  }

  const jid = test.phone ? `${test.phone}@s.whatsapp.net` : test.jid
  tests.deleteByLogin(test.login)
  audit('test_remove', { login: test.login, phone: test.phone || null })

  await sendText(sock, jid, [
    '❌ *Seu teste foi removido!*',
    '',
    '> _O período de teste chegou ao fim._',
    '',
    '✨ Gostou? Adquira seu *acesso VIP*!',
    '📲 _Estamos à disposição._'
  ].join('\n'), false)

  await sendText(sock, adminJid, [
    '✅ *Teste removido!*',
    '',
    `> Login: *${test.login}*`,
    `> Telefone: _${test.phone || 'N/A'}_`
  ].join('\n'), false)
  return true
}

async function promptCreateVip(sock) {
  adminState.awaitingVipLogin = true
  await sendText(sock, adminJid, [
    '⭐ *Criar Acesso VIP*',
    '',
    '> Digite o *login* desejado (3-8 letras):',
    '',
    '_Ou envie qualquer texto para gerar automaticamente_'
  ].join('\n'), false)
}

async function handleVipInput({ sock, text }) {
  if (!adminState.awaitingVipLogin) return false
  adminState.awaitingVipLogin = false

  const input = text.trim().toLowerCase()
  const isValid = /^[a-zA-Z]{3,8}$/.test(input)
  const login = isValid ? `${input}${randomDigits(2)}` : `vip${randomDigits(4)}`
  const password = randomDigits(5)
  const uuid = generateUuid()

  try {
    await panelApi.createUser({
      login,
      senha: password,
      dias: 30,
      limite: 1,
      nome: login,
      tipo: 'xray',
      uuid
    })

    audit('vip_create', { login })
    await sendText(sock, adminJid, [
      '✅ *VIP criado com sucesso!*',
      '',
      `> 👤 Login: *${login}*`,
      `> 🔑 Senha: *${password}*`,
      `> 🆔 UUID: \`${uuid}\``,
      `> 📅 Validade: *30 dias*`,
      '',
      `📲 App: ${settingsService.getAppLink()}`
    ].join('\n'), false)
  } catch (error) {
    await sendText(sock, adminJid, [
      '❌ *Erro ao criar VIP*',
      '',
      `> _${error.message}_`
    ].join('\n'), false)
  }

  return true
}

async function promptRemoveNumber(sock) {
  adminState.awaitingRemoveNumber = true
  await sendText(sock, adminJid, [
    '🗑️ *Remover Número*',
    '',
    '> Digite o *número* para remover do banco:',
    '',
    '_Exemplo: 5562999999999_'
  ].join('\n'), false)
}

async function handleRemoveNumberInput({ sock, text }) {
  if (!adminState.awaitingRemoveNumber) return false
  adminState.awaitingRemoveNumber = false

  const phone = text.trim().replace(/\D/g, '')
  
  if (!phone || phone.length < 10) {
    await sendText(sock, adminJid, [
      '❌ *Número inválido*',
      '',
      '> Digite um número válido com DDD.'
    ].join('\n'), false)
    return true
  }

  const removed = users.deleteByPhone(phone)

  if (!removed) {
    await sendText(sock, adminJid, [
      '⚠️ *Número não encontrado*',
      '',
      `> _${phone}_ não está no banco de dados.`
    ].join('\n'), false)
    return true
  }

  audit('user_remove', { phone })
  await sendText(sock, adminJid, [
    '✅ *Número removido!*',
    '',
    `> Telefone: *${phone}*`,
    '',
    '_O número foi removido do banco de dados._'
  ].join('\n'), false)

  return true
}

async function promptBlockNumber(sock) {
  adminState.awaitingBlockNumber = true
  await sendText(sock, adminJid, [
    '🚫 *Bloquear Número*',
    '',
    '> Digite o *número* para bloquear:',
    '',
    '_Exemplo: 5562999999999_'
  ].join('\n'), false)
}

async function handleBlockNumberInput({ sock, text }) {
  if (!adminState.awaitingBlockNumber) return false
  adminState.awaitingBlockNumber = false

  const phone = text.trim().replace(/\D/g, '')
  
  if (!phone || phone.length < 10) {
    await sendText(sock, adminJid, [
      '❌ *Número inválido*',
      '',
      '> Digite um número válido com DDD.'
    ].join('\n'), false)
    return true
  }

  if (blocked.isBlocked(phone)) {
    await sendText(sock, adminJid, [
      '⚠️ *Já está bloqueado*',
      '',
      `> _${phone}_ já está na lista de bloqueados.`
    ].join('\n'), false)
    return true
  }

  blocked.block(phone, 'Bloqueado pelo admin')
  audit('number_block', { phone })

  await sendText(sock, adminJid, [
    '🚫 *Número bloqueado!*',
    '',
    `> Telefone: *${phone}*`,
    '',
    '_Este número não poderá mais usar o bot._'
  ].join('\n'), false)

  return true
}

async function promptUnblockNumber(sock) {
  adminState.awaitingUnblockNumber = true
  await sendText(sock, adminJid, [
    '✅ *Desbloquear Número*',
    '',
    '> Digite o *número* para desbloquear:',
    '',
    '_Exemplo: 5562999999999_'
  ].join('\n'), false)
}

async function handleUnblockNumberInput({ sock, text }) {
  if (!adminState.awaitingUnblockNumber) return false
  adminState.awaitingUnblockNumber = false

  const phone = text.trim().replace(/\D/g, '')
  
  if (!phone || phone.length < 10) {
    await sendText(sock, adminJid, [
      '❌ *Número inválido*',
      '',
      '> Digite um número válido com DDD.'
    ].join('\n'), false)
    return true
  }

  const removed = blocked.unblock(phone)

  if (!removed) {
    await sendText(sock, adminJid, [
      '⚠️ *Número não estava bloqueado*',
      '',
      `> _${phone}_ não está na lista de bloqueados.`
    ].join('\n'), false)
    return true
  }

  audit('number_unblock', { phone })
  await sendText(sock, adminJid, [
    '✅ *Número desbloqueado!*',
    '',
    `> Telefone: *${phone}*`,
    '',
    '_Este número pode usar o bot novamente._'
  ].join('\n'), false)

  return true
}

async function viewBlocked(sock) {
  const list = blocked.getAll()
  audit('blocked_view', { total: list.length })

  if (!list.length) {
    await sendText(sock, adminJid, [
      '✅ *Nenhum número bloqueado*',
      '',
      '> _A lista de bloqueados está vazia._'
    ].join('\n'), false)
    return
  }

  const lines = list.map((item, i) => `${i + 1}. *${item.phone}*`).slice(0, 20)

  await sendText(sock, adminJid, [
    '🚫 *NÚMEROS BLOQUEADOS*',
    '',
    ...lines,
    '',
    list.length > 20 ? `_...e mais ${list.length - 20} números_` : '',
    '',
    `> _Total:_ *${list.length}*`
  ].filter(Boolean).join('\n'), false)
}

async function viewStats(sock) {
  const totalUsers = users.count()
  const totalBlocked = blocked.getAll().length
  const totalTests = tests.getAllWithPhone().length
  const openSupports = supports.getOpen().length

  await sendText(sock, adminJid, [
    '📊 *ESTATÍSTICAS DO BOT*',
    '',
    `> 👥 Usuários: *${totalUsers}*`,
    `> 🧪 Testes ativos: *${totalTests}*`,
    `> 📋 Suportes abertos: *${openSupports}*`,
    `> 🚫 Bloqueados: *${totalBlocked}*`,
    '',
    '_Atualizado em tempo real_'
  ].join('\n'), false)
}

function setAwaitingRenewLogin(value) {
  adminState.awaitingRenewLogin = value
}

function isAwaitingRenewLogin() {
  return adminState.awaitingRenewLogin
}

function isAwaitingInput() {
  return Object.values(adminState).some(v => v === true)
}

function getState() {
  return { ...adminState }
}

async function handleTextInput({ sock, text }) {
  const routes = [
    ['awaitingTextEdit', handleTextEditInput],
    ['awaitingPlanValue', handlePlanValueInput],
    ['awaitingPlanLimit', handlePlanLimitInput],
    ['awaitingPlanDays', handlePlanDaysInput],
    ['awaitingPlanLabel', handlePlanLabelInput],
    ['awaitingRemoveNumber', handleRemoveNumberInput],
    ['awaitingBlockNumber', handleBlockNumberInput],
    ['awaitingUnblockNumber', handleUnblockNumberInput],
    ['awaitingAccessLookup', handleAccessLookupInput],
    ['awaitingAccessDelete', handleAccessDeleteInput],
    ['awaitingNotifyBefore3dTime', handleNotifyBefore3dInput],
    ['awaitingNotifyExpiresDayTime', handleNotifyExpiresDayInput],
    ['awaitingNotifyAfter7dTime', handleNotifyAfter7dInput],
    ['awaitingNotifyTemplateBefore3d', handleTemplateBefore3dInput],
    ['awaitingNotifyTemplateExpiresDay', handleTemplateExpiresDayInput],
    ['awaitingNotifyTemplateAfter7d', handleTemplateAfter7dInput],
    ['awaitingAppLinkSet', handleAppLinkSetInput],
    ['awaitingPurchaseRemove', handlePurchaseRemoveInput],
    ['awaitingCouponCreate', handleCouponCreateInput],
    ['awaitingCouponDelete', handleCouponDeleteInput],
    ['awaitingTemplateCreate', handleTemplateCreateInput],
    ['awaitingTemplateDelete', handleTemplateDeleteInput]
  ]

  const match = routes.find(([key]) => adminState[key])
  if (!match) return false
  const handler = match[1]
  return handler({ sock, text })
}

module.exports = {
  BUTTON_IDS,
  isAdminCommand,
  showAdminPanel,
  handleAdminButton,
  handleTestInput,
  handleVipInput,
  handleTextInput,
  isAwaitingInput,
  isAwaitingRenewLogin,
  setAwaitingRenewLogin,
  getState,
  resetState
}

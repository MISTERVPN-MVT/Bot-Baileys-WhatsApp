const { purchases, accesses, systemState } = require('../database')
const { sendText } = require('../utils/messages')
const notificationTemplateService = require('./notificationTemplateService')

const SP_TZ = 'America/Sao_Paulo'
const DAY_MS = 24 * 60 * 60 * 1000
const RUN_EVERY_MS = 60 * 1000
const DEFAULT_NOTIFY_TIME = '09:00'

const spDateKey = (date) => {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: SP_TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  })
  return formatter.format(date)
}

const spTimeKey = (date) => {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: SP_TZ,
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23'
  })
  return formatter.format(date)
}

const keyToMs = (key) => new Date(`${key}T00:00:00-03:00`).getTime()

const daysBetweenKeys = (fromKey, toKey) => {
  const a = keyToMs(fromKey)
  const b = keyToMs(toKey)
  if (!Number.isFinite(a) || !Number.isFinite(b)) return null
  return Math.round((b - a) / DAY_MS)
}

const daysLeftSp = (expiresAt) => {
  const ts = new Date(expiresAt).getTime()
  if (!Number.isFinite(ts)) return null
  const nowKey = spDateKey(new Date())
  const expKey = spDateKey(new Date(ts))
  return daysBetweenKeys(nowKey, expKey)
}

const computeExpiresAt = (purchase) => {
  const ts = new Date(purchase.completedAt || purchase.createdAt).getTime()
  if (!Number.isFinite(ts)) return null
  const dt = new Date(ts)
  dt.setDate(dt.getDate() + Number(purchase.days || 0))
  return dt.toISOString()
}

function backfillAccesses() {
  const all = purchases.getAll()
  const completed = all.filter(p => p.stage === 'completed' && p.login)
  for (const purchase of completed) {
    const exists = accesses.findByLogin(purchase.login)
    if (exists) continue
    const expiresAt = computeExpiresAt(purchase)
    if (!expiresAt) continue
    accesses.upsertAccess({
      login: purchase.login,
      phone: purchase.phone,
      jid: purchase.jid,
      planId: purchase.planId,
      planLabel: purchase.planLabel,
      limitCount: purchase.limit,
      days: purchase.days,
      expiresAt
    })
  }
}

const templateKeyByKind = {
  before3d: notificationTemplateService.KEYS.BEFORE_3D,
  expiresDay: notificationTemplateService.KEYS.EXPIRES_DAY,
  after7d: notificationTemplateService.KEYS.AFTER_7D
}

const shouldSend = (kind, notifications) => {
  const flags = {
    before3d: Boolean(notifications?.before3dAt),
    expiresDay: Boolean(notifications?.expiresDayAt),
    after7d: Boolean(notifications?.after7dAt)
  }
  return !flags[kind]
}

const markSent = (kind, login) => {
  const markers = {
    before3d: () => accesses.markBefore3d(login),
    expiresDay: () => accesses.markExpiresDay(login),
    after7d: () => accesses.markAfter7d(login)
  }
  const fn = markers[kind]
  if (!fn) return null
  return fn()
}

const kindForDaysLeft = (daysLeft) => {
  const map = { 3: 'before3d', 0: 'expiresDay', '-7': 'after7d' }
  return map[String(daysLeft)] || null
}

const isValidTimeKey = (value) => /^\d{2}:\d{2}$/.test(String(value || '').trim())

const getNotifyTime = (key, fallback = DEFAULT_NOTIFY_TIME) => {
  const raw = systemState.get(key)
  if (isValidTimeKey(raw)) return raw
  return fallback
}

const shouldRunKindNow = (kind, nowKey) => {
  const byKind = {
    before3d: getNotifyTime('notify_before_3d_time'),
    expiresDay: getNotifyTime('notify_expires_day_time'),
    after7d: getNotifyTime('notify_after_7d_time')
  }
  const target = byKind[kind]
  if (!target) return false
  return target === nowKey
}

async function runAccessReminders(sock) {
  const nowKey = spTimeKey(new Date())
  const enabledKinds = ['before3d', 'expiresDay', 'after7d']
  const kindsToRun = new Set(enabledKinds.filter(kind => shouldRunKindNow(kind, nowKey)))
  if (!kindsToRun.size) return

  const all = accesses.listAll()
  for (const access of all) {
    const daysLeft = daysLeftSp(access.expiresAt)
    const kind = kindForDaysLeft(daysLeft)
    if (!kind) continue
    if (!kindsToRun.has(kind)) continue

    const notifications = accesses.getNotifications(access.login)
    if (!shouldSend(kind, notifications)) continue

    const templateKey = templateKeyByKind[kind]
    const message = notificationTemplateService.render(templateKey, access)
    if (!message) continue

    const jid = access.jid || `${access.phone}@s.whatsapp.net`
    try {
      await sendText(sock, jid, message)
    } catch {
      continue
    }

    markSent(kind, access.login)
  }
}

function start(sock) {
  backfillAccesses()
  runAccessReminders(sock).catch(() => {})
  setInterval(() => runAccessReminders(sock).catch(() => {}), RUN_EVERY_MS)
}

module.exports = { start, backfillAccesses, runAccessReminders }

const { systemState } = require('../database')
const { sendText } = require('../utils/messages')
const backupService = require('./backupService')
const config = require('../config')

const adminJid = `${config.adminNumber}@s.whatsapp.net`
const POLL_EVERY_MS = 60 * 1000

const shouldRunBackupNow = () => {
  const parts = backupService.spParts(new Date())
  const time = parts.timeKey.slice(0, 4)
  return { dateKey: parts.dateKey, isNineAm: time === '0900' }
}

async function runDailyBackup(sock) {
  const { dateKey, isNineAm } = shouldRunBackupNow()
  if (!isNineAm) return false

  const last = systemState.get('last_backup_date')
  if (last === dateKey) return false

  try {
    await backupService.sendBackupZip({ sock, jid: adminJid, reason: 'daily_09h' })
    systemState.set('last_backup_date', dateKey)
    return true
  } catch (error) {
    await sendText(sock, adminJid, `❌ Falha no backup diário (${dateKey}): ${error.message}`, false)
    return false
  }
}

function start(sock) {
  setInterval(() => runDailyBackup(sock).catch(() => {}), POLL_EVERY_MS)
}

module.exports = { start, runDailyBackup }

const { notificationTemplates } = require('../database')
const settingsService = require('./settingsService')
const { formatSpDate } = require('../utils/helpers')

const KEYS = {
  BEFORE_3D: 'before_3d',
  EXPIRES_DAY: 'expires_day',
  AFTER_7D: 'after_7d'
}

const DEFAULTS = {
  [KEYS.BEFORE_3D]: [
    '⏳ *Seu acesso está expirando*',
    '',
    '🏷️ Login: *{login}*',
    '📅 Expira: _{expiresAt}_',
    '',
    '🔄 Para renovar: *MENU* → *OUTRAS OPÇÕES* → *RENOVAR*',
    '📩 Se precisar, use *SUPORTE*.'
  ].join('\n'),
  [KEYS.EXPIRES_DAY]: [
    '⚠️ *Seu acesso expira hoje*',
    '',
    '🏷️ Login: *{login}*',
    '📅 Expira: _{expiresAt}_',
    '',
    '🔄 Para renovar: *MENU* → *OUTRAS OPÇÕES* → *RENOVAR*'
  ].join('\n'),
  [KEYS.AFTER_7D]: [
    '💙 *Sentimos sua falta!*',
    '',
    'Seu acesso expirou há alguns dias.',
    '',
    '💎 Para voltar: *MENU* → *COMPRAR VIP*',
    '📲 App: {appLink}'
  ].join('\n')
}

const normalizeKey = (key) => String(key || '').trim()

const tokenMap = ({ access, appLink }) => ({
  '{login}': access?.login || '',
  '{expiresAt}': access?.expiresAt ? formatSpDate(access.expiresAt) : '',
  '{appLink}': appLink || '',
  '{phone}': access?.phone || '',
  '{jid}': access?.jid || ''
})

const applyTokens = (text, tokens) => {
  const entries = Object.entries(tokens)
  return entries.reduce((acc, [from, to]) => acc.split(from).join(String(to)), String(text || ''))
}

function getTemplate(key) {
  const normalized = normalizeKey(key)
  const row = notificationTemplates.findByKey(normalized)
  const fallback = DEFAULTS[normalized] || ''
  return row?.text || fallback
}

function render(key, access) {
  const appLink = settingsService.getAppLink()
  const base = getTemplate(key)
  return applyTokens(base, tokenMap({ access, appLink }))
}

function upsertTemplate({ key, text }) {
  const normalized = normalizeKey(key)
  const body = String(text || '').trim()
  if (!normalized) return { ok: false, error: 'Chave inválida.' }
  if (!body) return { ok: false, error: 'Texto inválido.' }
  const saved = notificationTemplates.upsert({ key: normalized, text: body })
  if (!saved) return { ok: false, error: 'Falha ao salvar.' }
  return { ok: true, template: saved }
}

function listKeys() {
  return Object.values(KEYS)
}

function defaultFor(key) {
  const normalized = normalizeKey(key)
  return DEFAULTS[normalized] || ''
}

module.exports = { KEYS, listKeys, getTemplate, render, upsertTemplate, defaultFor }


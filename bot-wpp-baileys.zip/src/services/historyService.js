const { purchases, renewals, accesses } = require('../database')
const { formatSpDate, formatMoney } = require('../utils/helpers')

const safeTs = (value) => {
  const ts = new Date(value).getTime()
  if (!Number.isFinite(ts)) return null
  return ts
}

const daysUntil = (expiresAt) => {
  const ts = safeTs(expiresAt)
  if (ts == null) return null
  const diffMs = ts - Date.now()
  return Math.ceil(diffMs / (1000 * 60 * 60 * 24))
}

const computeExpiresAt = (purchase) => {
  const base = purchase?.completedAt || purchase?.createdAt
  const ts = safeTs(base)
  if (ts == null) return null
  const dt = new Date(ts)
  dt.setDate(dt.getDate() + Number(purchase.days || 0))
  return dt.toISOString()
}

const mapPurchaseEvent = (p) => ({
  kind: 'purchase',
  at: p.completedAt || p.createdAt,
  label: p.planLabel,
  amount: p.amount,
  login: p.login || null
})

const mapRenewalEvent = (r) => ({
  kind: 'renewal',
  at: r.createdAt,
  label: r.planLabel || 'Renovação',
  amount: r.amount,
  login: r.login
})

const sortDesc = (a, b) => {
  const ta = safeTs(a.at) || 0
  const tb = safeTs(b.at) || 0
  return tb - ta
}

const statusTag = (status) => {
  const tags = { ativo: '🟢 *ATIVO*', expirado: '🔴 *EXPIRADO*' }
  return tags[status] || `⚪ *${String(status || 'indisponível').toUpperCase()}*`
}

const eventTag = (kind) => {
  const tags = { purchase: '🏷️ *COMPRA*', renewal: '🏷️ *RENOVAÇÃO*' }
  return tags[kind] || '🏷️ *EVENTO*'
}

function buildHistoryMessage(phone) {
  const recentPurchases = purchases.listCompletedByPhone(phone, 10)
  const recentRenewals = renewals.listByPhone(phone, 10)
  const events = [
    ...recentPurchases.map(mapPurchaseEvent),
    ...recentRenewals.map(mapRenewalEvent)
  ].sort(sortDesc).slice(0, 10)

  const latestAccess = accesses.findLatestByPhone(phone)
  const fallbackPurchase = recentPurchases[0]
  const expiresAt = latestAccess?.expiresAt || computeExpiresAt(fallbackPurchase)
  const daysLeft = expiresAt ? daysUntil(expiresAt) : null

  const statusLine = (() => {
    if (!expiresAt) return '📌 Status: _indisponível_'
    const status = daysLeft != null && daysLeft > 0 ? 'ativo' : 'expirado'
    const left = daysLeft == null ? 'N/A' : `${daysLeft} dia(s)`
    return `🏷️ Status: ${statusTag(status)} — expira: _${formatSpDate(expiresAt)}_ — *${left}*`
  })()

  if (!events.length) {
    return [
      '🧾 *Histórico de compras*',
      '',
      statusLine,
      '',
      '📭 Nenhuma compra encontrada para este número.'
    ].join('\n')
  }

  const lines = events.map(e => {
    const when = formatSpDate(e.at)
    const tag = eventTag(e.kind)
    const login = e.login ? ` — login *${e.login}*` : ''
    return `• ${tag} — _${when}_ — ${e.label} — ${formatMoney(e.amount)}${login}`
  })

  return [
    '🧾 *Histórico de compras*',
    '',
    statusLine,
    '',
    ...lines
  ].join('\n')
}

module.exports = { buildHistoryMessage }

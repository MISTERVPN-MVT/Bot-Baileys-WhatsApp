const { supports } = require('../database')
const { sendText } = require('../utils/messages')
const { sendButtons } = require('../utils/buttons')
const { formatPhoneLink } = require('../utils/helpers')
const config = require('../config')

const adminJid = `${config.adminNumber}@s.whatsapp.net`

async function requestSupport({ sock, jid, phone, name }) {
  const support = supports.create({ phone, jid, name })
  if (!support) return null
  
  await sendText(sock, jid, [
    '✅ *Pedido de suporte enviado!*',
    '',
    `> Protocolo: \`${support.id}\``,
    '',
    '📝 Envie sua mensagem abaixo.',
    '',
    'Se for sobre *pagamento*, envie também o comprovante.',
    '_Em breve você será atendido._'
  ].join('\n'))
  
  const link = formatPhoneLink(phone)
  
  await sendText(sock, adminJid, [
    '📩 *Novo pedido de suporte*',
    '',
    `> 🆔 ID: \`${support.id}\``,
    `> 👤 Nome: _${support.name || 'Não informado'}_`,
    `> 📱 Telefone: _${link}_`
  ].join('\n'), false)
  
  return support
}

async function handleAdminCommand({ sock, text }) {
  if (text !== '.sup') return false
  
  const open = supports.getOpen()
  if (!open.length) {
    await sendText(sock, adminJid, [
      '✅ *Nenhum suporte pendente*',
      '',
      '> _Todos os pedidos foram atendidos._'
    ].join('\n'), false)
    return true
  }

  const buttons = open.map(item => ({
    id: `support_close_${item.id}`,
    text: `📱 ${item.phone || item.id.slice(0, 8)}`
  }))

  await sendButtons(sock, adminJid, {
    text: [
      '📋 *SUPORTES EM ABERTO*',
      '',
      `> _Total:_ *${open.length}* pedido(s)`,
      '',
      '_Clique para encerrar:_'
    ].join('\n'),
    footer: '© MASTER BOT',
    buttons
  })
  
  return true
}

async function handleAdminButton({ sock, button }) {
  const id = button?.id || ''
  const prefix = 'support_close_'
  if (!id.startsWith(prefix)) return false
  
  const supportId = id.slice(prefix.length)
  const closed = supports.close(supportId)
  
  if (!closed) {
    await sendText(sock, adminJid, [
      '❌ *Suporte não encontrado*',
      '',
      `> ID: _${supportId}_`
    ].join('\n'), false)
    return true
  }

  await sendText(sock, adminJid, [
    '✅ *Suporte encerrado!*',
    '',
    `> ID: \`${supportId}\``
  ].join('\n'), false)
  
  await sendText(sock, closed.jid, [
    '✅ *Suporte encerrado!*',
    '',
    '> _Seu pedido de suporte foi finalizado._',
    '',
    '📲 Conte conosco sempre que precisar!',
    '_Obrigado por usar nossos serviços._'
  ].join('\n'))
  
  return true
}

function hasOpenSupport(phone) {
  return supports.hasOpen(phone)
}

module.exports = { requestSupport, handleAdminCommand, handleAdminButton, hasOpenSupport }

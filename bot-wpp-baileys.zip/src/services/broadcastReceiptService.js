const { broadcastMessageMap, broadcastEvents } = require('../database')

const kindFromReceipt = (receipt) => {
  if (receipt?.readTimestamp) return 'read'
  if (receipt?.receiptTimestamp) return 'delivered'
  return null
}

function handleReceiptUpdate(update) {
  const messageId = update?.key?.id
  if (!messageId) return false
  if (!update?.key?.fromMe) return false

  const kind = kindFromReceipt(update?.receipt)
  if (!kind) return false

  const mapping = broadcastMessageMap.findByMessageId(messageId)
  if (!mapping) return false

  const exists = broadcastEvents.hasKind(mapping.broadcastId, mapping.phone, kind)
  if (exists) return false

  broadcastEvents.add({ broadcastId: mapping.broadcastId, phone: mapping.phone, kind })
  return true
}

function handleReceiptUpdates(updates) {
  if (!Array.isArray(updates) || !updates.length) return 0
  let recorded = 0
  for (const update of updates) {
    const ok = handleReceiptUpdate(update)
    if (ok) recorded++
  }
  return recorded
}

module.exports = { handleReceiptUpdates }


const db = require('../database')
const { delay } = require('../utils')
const { sendUserText, sendImage, sendVideo, sendAudio, sendDocument } = require('./messaging')

const BROADCAST_DELAY_MS = 2000

const BROADCAST_TYPES = {
  text: 'text',
  document: 'document',
  complete: 'complete'
}

const runBroadcast = async (sock, adminJid, { type, text, media, mediaType, fileName }) => {
  const numbers = db.broadcast.getAll()
  const total = numbers.length
  
  if (total === 0) return { sent: 0, failed: 0, total: 0, duration: 0 }

  const startTime = Date.now()
  let sent = 0
  let failed = 0

  await sendUserText(sock, adminJid, `📢 Iniciando divulgação...\n📊 Total de números: ${total}`)

  for (const num of numbers) {
    const jid = num.jid || `${num.phone}@s.whatsapp.net`
    
    try {
      if (type === BROADCAST_TYPES.text) {
        await sendUserText(sock, jid, text)
      }

      if (type === BROADCAST_TYPES.document) {
        if (mediaType === 'image') await sendImage(sock, jid, media, '')
        if (mediaType === 'video') await sendVideo(sock, jid, media, '')
        if (mediaType === 'audio') await sendAudio(sock, jid, media)
        if (mediaType === 'document') await sendDocument(sock, jid, media, 'application/octet-stream', fileName)
      }

      if (type === BROADCAST_TYPES.complete) {
        if (mediaType === 'image') await sendImage(sock, jid, media, text)
        if (mediaType === 'video') await sendVideo(sock, jid, media, text)
        if (mediaType === 'audio') {
          await sendAudio(sock, jid, media)
          await sendUserText(sock, jid, text)
        }
      }

      sent++
    } catch {
      failed++
    }

    await delay(BROADCAST_DELAY_MS)
  }

  const duration = Math.round((Date.now() - startTime) / 1000)
  
  return { sent, failed, total, duration }
}

const formatBroadcastResult = ({ sent, failed, total, duration }) => {
  const lines = [
    '✅ *Divulgação finalizada!*',
    '',
    `📤 Enviados: ${sent}`,
    `❌ Falhas: ${failed}`,
    `📊 Total: ${total}`,
    `⏱️ Tempo: ${duration}s`
  ]
  return lines.join('\n')
}

module.exports = { runBroadcast, formatBroadcastResult, BROADCAST_TYPES }

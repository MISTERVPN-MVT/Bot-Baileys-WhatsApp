const { accesses, purchases } = require('../database')
const { createPanelApi } = require('../utils/api')
const { sendText } = require('../utils/messages')
const config = require('../config')

const panelApi = createPanelApi(config.panelDomain, config.panelToken)

const findLoginForPhone = (phone) => {
  const access = accesses.findLatestByPhone(phone)
  if (access?.login) return access.login
  const purchase = purchases.findCompletedByPhone(phone)
  if (purchase?.login) return purchase.login
  return null
}

const findUserFromPanel = (result, login) => {
  const users = result?.data?.usuarios || []
  return users.find(u => u.login === login) || null
}

async function checkAccess({ sock, jid, phone }) {
  const login = findLoginForPhone(phone)
  if (!login) {
    await sendText(sock, jid, '❌ Não encontrei seu login. Envie *Suporte* para ajuda.')
    return true
  }

  try {
    const userResult = await panelApi.getUser(login)
    const user = findUserFromPanel(userResult, login)

    const onlineList = await panelApi.listOnline()
    const online = Array.isArray(onlineList) ? onlineList.some(o => o?.login === login) : false

    const status = user?.status || 'indisponível'
    const expira = user?.expira_formatada || user?.expira || 'indisponível'
    const dias = user?.dias_restantes != null ? `${user.dias_restantes} dia(s)` : 'N/A'

    await sendText(sock, jid, [
      '✅ *Status do acesso*',
      '',
      `> Login: *${login}*`,
      `> Status: *${status}*`,
      `> Expira: _${expira}_`,
      `> Dias restantes: *${dias}*`,
      `> Online agora: *${online ? 'sim' : 'não'}*`
    ].join('\n'))
    return true
  } catch (error) {
    await sendText(sock, jid, `❌ Erro ao verificar: ${error.message}`)
    return true
  }
}

module.exports = { checkAccess }


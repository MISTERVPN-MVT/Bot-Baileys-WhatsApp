const { purchases } = require('../database')
const { formatMoney, formatSpDate, formatPhoneLink } = require('../utils/helpers')

const DAY_MS = 24 * 60 * 60 * 1000

const GROUPS = {
  pending: { label: 'Pendentes', stages: ['pending_payment'] },
  approved: { label: 'Aprovados', stages: ['awaiting_username', 'completed'] },
  refunded: { label: 'Estornados', stages: ['refunded'] },
  expired: { label: 'Expirados/Cancelados', stages: ['expired', 'cancelled', 'failed'] }
}

const isRecent = (iso, days) => {
  const ts = new Date(iso).getTime()
  if (!Number.isFinite(ts)) return false
  const cutoff = Date.now() - Number(days || 0) * DAY_MS
  return ts >= cutoff
}

const sumAmount = (list) => list.reduce((acc, p) => acc + Number(p.amount || 0), 0)

const stageLabel = (stage) => {
  const labels = {
    awaiting_email: 'Aguardando e-mail',
    pending_payment: 'Pagamento pendente',
    awaiting_username: 'Aprovado (criando acesso)',
    completed: 'Concluído',
    expired: 'Expirado',
    cancelled: 'Cancelado',
    refunded: 'Estornado',
    failed: 'Falhou'
  }
  return labels[stage] || stage || 'indisponível'
}

const paymentRef = (purchase) => {
  const id = purchase?.paymentId
  if (!id) return 'N/A'
  const raw = String(id)
  return raw.length > 10 ? `${raw.slice(0, 6)}...${raw.slice(-2)}` : raw
}

const pickAt = (purchase) => purchase?.completedAt || purchase?.createdAt

function summarize(days = 7) {
  const all = purchases.getAll().filter(p => isRecent(p.createdAt, days))
  const byGroup = Object.entries(GROUPS).map(([key, group]) => {
    const list = all.filter(p => group.stages.includes(p.stage))
    return { key, label: group.label, count: list.length, amount: sumAmount(list) }
  })
  const total = { count: all.length, amount: sumAmount(all) }
  return { byGroup, total, days }
}

function listRecent(groupKey, limit = 15) {
  const group = GROUPS[groupKey]
  if (!group) return []
  return purchases.getAll().filter(p => group.stages.includes(p.stage)).slice(0, limit)
}

function buildListMessage(groupKey, limit = 15) {
  const group = GROUPS[groupKey]
  if (!group) return '❌ Grupo inválido.'

  const list = listRecent(groupKey, limit)
  if (!list.length) return `📭 Nenhum pagamento em *${group.label}*.`

  const lines = list.map(p => {
    const when = formatSpDate(pickAt(p))
    const link = formatPhoneLink(p.phone)
    const stage = stageLabel(p.stage)
    return `• _${when}_ — *${formatMoney(p.amount)}* — ${p.planLabel} — _${link}_ — ${stage} — \`${paymentRef(p)}\``
  })

  return [
    `💳 *Pagamentos — ${group.label}*`,
    '',
    ...lines
  ].join('\n')
}

function buildSummaryMessage(days = 7) {
  const sum = summarize(days)
  const rows = sum.byGroup.map(g => `> ${g.label}: *${g.count}* — ${formatMoney(g.amount)}`)
  return [
    '💳 *Resumo de pagamentos*',
    '',
    `📆 Últimos ${sum.days} dia(s)`,
    '',
    ...rows,
    '',
    `📊 Total: *${sum.total.count}* — ${formatMoney(sum.total.amount)}`
  ].join('\n')
}

module.exports = { GROUPS, summarize, buildSummaryMessage, buildListMessage }


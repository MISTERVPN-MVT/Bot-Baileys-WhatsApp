const { broadcast, users, accesses, blocked, broadcastEvents, broadcastMessageMap } = require('../database')
const { delay } = require('../utils/helpers')

const DELAY_MS = 2000

const isActiveByExpiresAt = (expiresAt) => {
  const ts = new Date(expiresAt).getTime()
  if (!Number.isFinite(ts)) return false
  return ts > Date.now()
}

const uniquePhones = (phones) => Array.from(new Set(phones.filter(Boolean)))

const accessPhonesBySegment = (segment) => {
  const allAccesses = accesses.listAll()
  const statusByPhone = new Map()

  for (const access of allAccesses) {
    const phone = access.phone
    if (!phone) continue
    const prev = statusByPhone.get(phone) || { any: false, active: false }
    const next = { any: true, active: prev.active || isActiveByExpiresAt(access.expiresAt) }
    statusByPhone.set(phone, next)
  }

  const entries = Array.from(statusByPhone.entries())
  const filters = {
    active: ([, st]) => st.active,
    expired: ([, st]) => st.any && !st.active,
    all: () => true
  }

  const pick = filters[segment] || filters.all
  return entries.filter(pick).map(([phone]) => phone)
}

const basePhones = () => {
  const a = broadcast.getAllPhones()
  const b = users.getAllPhones()
  const c = accessPhonesBySegment('all')
  return uniquePhones([...a, ...b, ...c])
}

const phonesForSegment = (segment) => {
  const segments = {
    all: () => basePhones(),
    active: () => uniquePhones(accessPhonesBySegment('active')),
    expired: () => uniquePhones(accessPhonesBySegment('expired'))
  }
  const fn = segments[segment] || segments.all
  const phones = fn()
  return phones.filter(phone => !blocked.isBlocked(phone))
}

const payloadByMediaType = (mediaType, buffer, mimetype, text) => {
  const payloads = {
    image: () => ({ image: buffer, caption: text || '', mimetype }),
    video: () => ({ video: buffer, caption: text || '', mimetype }),
    audio: () => ({ audio: buffer, mimetype: mimetype || 'audio/mp4', ptt: false }),
    document: () => ({ document: buffer, mimetype: mimetype || 'application/octet-stream' })
  }
  const fn = payloads[mediaType]
  if (!fn) return null
  return fn()
}

const payloadForType = ({ type, text, mediaBuffer, mediaType, mimetype }) => {
  const builders = {
    text: () => ({ text }),
    media: () => payloadByMediaType(mediaType, mediaBuffer, mimetype, ''),
    complete: () => payloadByMediaType(mediaType, mediaBuffer, mimetype, text)
  }
  const fn = builders[type]
  if (!fn) return null
  return fn()
}

async function sendToJid(sock, jid, data) {
  return sock.sendMessage(jid, data)
}

async function executeBroadcast({ sock, segment, type, text, mediaBuffer, mediaType, mimetype, broadcastId }) {
  const numbers = phonesForSegment(segment || 'all')
  const total = numbers.length

  if (!total) return { sent: 0, failed: 0, total: 0, duration: 0 }

  const startTime = Date.now()
  let sent = 0
  let failed = 0

  for (const phone of numbers) {
    const jid = `${phone}@s.whatsapp.net`
    const payload = payloadForType({ type, text, mediaBuffer, mediaType, mimetype })
    if (!payload) {
      failed++
      if (broadcastId) broadcastEvents.add({ broadcastId, phone, kind: 'failed' })
      await delay(DELAY_MS)
      continue
    }
    try {
      const res = await sendToJid(sock, jid, payload)

      sent++
      if (broadcastId) {
        broadcastEvents.add({ broadcastId, phone, kind: 'sent' })
        broadcastMessageMap.add({ messageId: res?.key?.id, broadcastId, phone })
      }
    } catch {
      failed++
      if (broadcastId) broadcastEvents.add({ broadcastId, phone, kind: 'failed' })
    }
    await delay(DELAY_MS)
  }

  const duration = Math.ceil((Date.now() - startTime) / 1000)
  return { sent, failed, total, duration }
}

module.exports = { executeBroadcast, phonesForSegment }

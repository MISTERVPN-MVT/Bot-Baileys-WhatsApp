const { coupons } = require('../database')
const { formatMoney, formatSpDate } = require('../utils/helpers')
const textTemplateService = require('./textTemplateService')

const COUPON_CMD = /^cupom\s+([a-z0-9_-]{3,30})$/i

const isExpired = (expiresAt) => {
  if (!expiresAt) return false
  const ts = new Date(expiresAt).getTime()
  if (!Number.isFinite(ts)) return false
  return ts <= Date.now()
}

const computeDiscount = (amount, coupon) => {
  const base = Number(amount || 0)
  const value = Number(coupon.value || 0)
  if (base <= 0) return 0

  const byKind = {
    percent: () => base * (value / 100),
    fixed: () => value
  }

  const fn = byKind[coupon.kind]
  if (!fn) return 0

  const raw = fn()
  const bounded = Math.max(0, Math.min(base, raw))
  return Math.round(bounded * 100) / 100
}

function parseCouponMessage(text) {
  const raw = String(text || '').trim()
  const match = raw.match(COUPON_CMD)
  if (!match) return null
  return coupons.normalizeCode(match[1])
}

function validate({ code, phone }) {
  const coupon = coupons.findByCode(code)
  if (!coupon) return { ok: false, error: 'Cupom inválido.' }
  if (!coupon.active) return { ok: false, error: 'Cupom desativado.' }
  if (isExpired(coupon.expiresAt)) return { ok: false, error: 'Cupom expirado.' }
  if (coupons.hasPhoneUsed(code, phone)) return { ok: false, error: 'Este cupom já foi usado por este número.' }

  const maxUses = coupon.maxUses
  if (!maxUses) return { ok: true, coupon }

  const used = coupons.countUsages(code)
  if (used >= maxUses) return { ok: false, error: 'Cupom esgotado.' }

  return { ok: true, coupon }
}

function applyToPurchase({ purchase, phone, code }) {
  const normalized = coupons.normalizeCode(code)
  const validated = validate({ code: normalized, phone })
  if (!validated.ok) return validated

  const originalAmount = Number.isFinite(purchase.originalAmount) ? purchase.originalAmount : purchase.amount
  const discountAmount = computeDiscount(originalAmount, validated.coupon)
  const finalAmount = Math.max(1, Math.round((originalAmount - discountAmount) * 100) / 100)

  return {
    ok: true,
    coupon: validated.coupon,
    changes: {
      originalAmount,
      discountAmount,
      amount: finalAmount,
      couponCode: normalized
    }
  }
}

function buildAppliedMessage({ purchase, coupon }) {
  const expiresAt = coupon.expiresAt ? formatSpDate(coupon.expiresAt) : 'sem validade'
  return textTemplateService.render(textTemplateService.KEYS.PURCHASE_COUPON_APPLIED, {
    '{couponCode}': coupon.code,
    '{originalAmount}': formatMoney(purchase.originalAmount),
    '{discountAmount}': formatMoney(purchase.discountAmount),
    '{amount}': formatMoney(purchase.amount),
    '{expiresAt}': expiresAt
  })
}

function finalizeUsage(purchase) {
  const code = purchase?.couponCode
  if (!code) return false
  try {
    coupons.insertUsage({ code, phone: purchase.phone, purchaseId: purchase.id })
    return true
  } catch {
    return false
  }
}

module.exports = {
  parseCouponMessage,
  applyToPurchase,
  buildAppliedMessage,
  finalizeUsage
}

const { sendButtons } = require('./buttons')
const { delay } = require('../utils')

const sendUserText = async (sock, jid, text) => {
  const update = sock.sendPresenceUpdate
  if (!update) return sock.sendMessage(jid, { text })
  await update('composing', jid)
  await delay(700)
  await update('paused', jid)
  return sock.sendMessage(jid, { text })
}

const sendUserButtons = async (sock, jid, data) => {
  const update = sock.sendPresenceUpdate
  if (!update) return sendButtons(sock, jid, data)
  await update('composing', jid)
  await delay(700)
  await update('paused', jid)
  return sendButtons(sock, jid, data)
}

const sendAdminText = (sock, jid, text) => sock.sendMessage(jid, { text })

const sendAdminButtons = (sock, jid, data) => sendButtons(sock, jid, data)

const sendImage = (sock, jid, image, caption) => sock.sendMessage(jid, { image, caption })

const sendVideo = (sock, jid, video, caption) => sock.sendMessage(jid, { video, caption })

const sendAudio = (sock, jid, audio) => sock.sendMessage(jid, { audio, mimetype: 'audio/mp4' })

const sendDocument = (sock, jid, document, mimetype, fileName) => sock.sendMessage(jid, { document, mimetype, fileName })

const markRead = async (sock, key) => {
  const read = sock.readMessages
  if (!read) return
  await read([key])
}

module.exports = {
  sendUserText,
  sendUserButtons,
  sendAdminText,
  sendAdminButtons,
  sendImage,
  sendVideo,
  sendAudio,
  sendDocument,
  markRead
}

const { purchases, plans, accesses } = require('../database')
const { createMercadoPagoApi, createPanelApi } = require('../utils/api')
const { sendText } = require('../utils/messages')
const { sendButtons } = require('../utils/buttons')
const { randomDigits, generateUuid, formatTimeOnly, formatMoney, formatPhoneLink } = require('../utils/helpers')
const config = require('../config')
const couponService = require('./couponService')
const textTemplateService = require('./textTemplateService')

const STAGES = {
  AWAITING_EMAIL: 'awaiting_email',
  PENDING_PAYMENT: 'pending_payment',
  AWAITING_USERNAME: 'awaiting_username',
  COMPLETED: 'completed',
  FAILED: 'failed',
  EXPIRED: 'expired',
  CANCELLED: 'cancelled',
  REFUNDED: 'refunded'
}

const mpApi = createMercadoPagoApi(config.mpAccessToken, config.mpWebhookUrl)
const panelApi = createPanelApi(config.panelDomain, config.panelToken)
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const usernamePattern = /^[a-zA-Z]{3,8}$/
const adminJid = `${config.adminNumber}@s.whatsapp.net`

const validEmail = (value) => emailPattern.test(String(value || '').trim())
const normalizeEmail = (value) => String(value || '').trim().toLowerCase()
const validUsername = (value) => usernamePattern.test(value || '')
const buildFallbackUsername = () => `vip${randomDigits(2 + Math.floor(Math.random() * 3))}`
const notifyFlag = (purchase, key) => Boolean(purchase.notified?.[key])

const markNotified = (purchase, key) => {
  const notified = { ...purchase.notified, [key]: true }
  return purchases.patch(purchase, { notified })
}

const messages = {
  planSelected: (planLabel) => textTemplateService.render(textTemplateService.KEYS.PURCHASE_PLAN_SELECTED, {
    '{planLabel}': planLabel
  }),
  pixGenerated: (purchase) => textTemplateService.render(textTemplateService.KEYS.PURCHASE_PIX_GENERATED, {
    '{planLabel}': purchase.planLabel,
    '{amount}': formatMoney(purchase.amount),
    '{expiresAt}': formatTimeOnly(purchase.expiresAt),
    '{ticketUrl}': purchase.ticketUrl || '_indisponível_'
  }),
  paymentApproved: () => textTemplateService.render(textTemplateService.KEYS.PURCHASE_PAYMENT_APPROVED),
  accessCreated: (login, password, uuid) => textTemplateService.render(textTemplateService.KEYS.PURCHASE_ACCESS_CREATED, {
    '{login}': login,
    '{password}': password,
    '{uuid}': uuid
  }),
  pixExpired: () => textTemplateService.render(textTemplateService.KEYS.PURCHASE_PIX_EXPIRED),
  paymentRejected: () => textTemplateService.render(textTemplateService.KEYS.PURCHASE_PAYMENT_REJECTED),
  paymentRefunded: () => textTemplateService.render(textTemplateService.KEYS.PURCHASE_PAYMENT_REFUNDED),
  pixError: (error) => textTemplateService.render(textTemplateService.KEYS.PURCHASE_PIX_ERROR, {
    '{error}': error
  }),
  accessError: (error) => textTemplateService.render(textTemplateService.KEYS.PURCHASE_ACCESS_ERROR, {
    '{error}': error
  }),
  adminStart: (purchase, link) => textTemplateService.render(textTemplateService.KEYS.PURCHASE_ADMIN_START, {
    '{planLabel}': purchase.planLabel,
    '{amount}': formatMoney(purchase.amount),
    '{phoneLink}': link,
    '{paymentId}': purchase.paymentId
  }),
  adminCompleted: (purchase, link) => textTemplateService.render(textTemplateService.KEYS.PURCHASE_ADMIN_COMPLETED, {
    '{planLabel}': purchase.planLabel,
    '{amount}': formatMoney(purchase.amount),
    '{phoneLink}': link,
    '{login}': purchase.login,
    '{paymentId}': purchase.paymentId
  }),
  adminRefunded: (purchase, link) => textTemplateService.render(textTemplateService.KEYS.PURCHASE_ADMIN_REFUNDED, {
    '{planLabel}': purchase.planLabel,
    '{amount}': formatMoney(purchase.amount),
    '{phoneLink}': link,
    '{paymentId}': purchase.paymentId
  }),
  plansMenu: () => textTemplateService.render(textTemplateService.KEYS.PURCHASE_PLANS_MENU)
}

const sendPlansMenu = async (sock, jid, backButtonId) => {
  const basePlans = plans.getAll()
  const buttons = basePlans.map(plan => ({ id: plan.id, text: plan.label }))
  buttons.push({ id: backButtonId, text: '◀️ Voltar' })
  
  await sendButtons(sock, jid, {
    text: messages.plansMenu(),
    footer: '© MASTER BOT',
    buttons
  })
}

const handlePlanSelection = async ({ sock, jid, planId, name, phone, backButtonId }) => {
  const plan = plans.findById(planId)
  if (!plan) return false
  
  const current = purchases.findActiveByPhone(phone)
  if (current) {
    await handleResume(sock, jid, current)
    return true
  }

  const purchase = purchases.create({
    phone,
    jid,
    name,
    planId: plan.id,
    planLabel: plan.label,
    amount: plan.amount,
    limit: plan.limit,
    days: plan.days,
    stage: STAGES.AWAITING_EMAIL
  })

  await sendText(sock, jid, messages.planSelected(purchase.planLabel))
  return true
}

const handleResume = async (sock, jid, purchase) => {
  const actions = {
    [STAGES.AWAITING_EMAIL]: () => sendText(sock, jid, messages.planSelected(purchase.planLabel)),
    [STAGES.PENDING_PAYMENT]: async () => {
      await sendText(sock, jid, messages.pixGenerated(purchase))
      await sendText(sock, jid, purchase.qrCode || '_indisponível_')
    },
    [STAGES.AWAITING_USERNAME]: () => sendText(sock, jid, messages.paymentApproved())
  }
  
  const action = actions[purchase.stage]
  if (!action) return
  await action()
}

const handleEmailInput = async ({ sock, jid, text, purchase }) => {
  const couponCode = couponService.parseCouponMessage(text)
  if (couponCode) {
    const applied = couponService.applyToPurchase({ purchase, phone: purchase.phone, code: couponCode })
    if (!applied.ok) {
      await sendText(sock, jid, textTemplateService.render(textTemplateService.KEYS.PURCHASE_COUPON_ERROR, {
        '{error}': applied.error
      }))
      return purchase
    }
    const updated = purchases.patch(purchase, applied.changes)
    await sendText(sock, jid, couponService.buildAppliedMessage({ purchase: updated, coupon: applied.coupon }))
    return updated
  }

  const normalized = normalizeEmail(text)
  const email = validEmail(normalized) ? normalized : 'cliente@email.com'
  
  try {
    const payment = await mpApi.createPixPayment({
      amount: purchase.amount,
      description: `Plano ${purchase.planLabel}`,
      email,
      externalReference: purchase.id,
      idempotencyKey: purchase.id
    })

    const updated = purchases.patch(purchase, {
      email,
      paymentId: payment.id,
      paymentStatus: payment.status,
      stage: STAGES.PENDING_PAYMENT,
      status: payment.status,
      expiresAt: payment.expiresAt,
      qrCode: payment.qrCode,
      ticketUrl: payment.ticketUrl
    })

    await sendText(sock, jid, messages.pixGenerated(updated))
    await sendText(sock, jid, updated.qrCode || '_indisponível_')
    await notifyAdminStart(sock, updated)
    return updated
  } catch (error) {
    purchases.patch(purchase, { stage: STAGES.FAILED, status: 'failed' })
    await sendText(sock, jid, messages.pixError(error.message))
    return null
  }
}

const notifyAdminStart = async (sock, purchase) => {
  if (notifyFlag(purchase, 'adminStart')) return purchase
  const link = formatPhoneLink(purchase.phone)
  await sendText(sock, adminJid, messages.adminStart(purchase, link), false)
  return markNotified(purchase, 'adminStart')
}

const handleUsernameInput = async ({ sock, jid, text, purchase }) => {
  const base = String(text || '').trim()
  const isValid = validUsername(base)
  const username = isValid ? base : buildFallbackUsername()

  try {
    const suffix = randomDigits(2)
    const login = (isValid ? `${username}${suffix}` : username).toLowerCase()
    const password = randomDigits(5)
    const uuid = generateUuid()

    await panelApi.createUser({
      login,
      senha: password,
      dias: purchase.days,
      limite: purchase.limit,
      nome: login,
      tipo: 'xray',
      uuid
    })

    const updated = purchases.patch(purchase, {
      stage: STAGES.COMPLETED,
      status: 'approved',
      login,
      password,
      uuid,
      completedAt: new Date().toISOString()
    })

    await sendText(sock, jid, messages.accessCreated(login, password, uuid))
    await notifyAdminCompleted(sock, updated)
    const expiresAt = (() => {
      const base = new Date(updated.completedAt)
      const ts = base.getTime()
      if (!Number.isFinite(ts)) return null
      base.setDate(base.getDate() + Number(updated.days || 0))
      return base.toISOString()
    })()
    if (expiresAt) {
      accesses.upsertAccess({
        login,
        phone: updated.phone,
        jid: updated.jid,
        planId: updated.planId,
        planLabel: updated.planLabel,
        limitCount: updated.limit,
        days: updated.days,
        expiresAt
      })
    }
    couponService.finalizeUsage(updated)
    return updated
  } catch (error) {
    purchases.patch(purchase, { stage: STAGES.FAILED, status: 'failed' })
    await sendText(sock, jid, messages.accessError(error.message))
    return null
  }
}

const notifyAdminCompleted = async (sock, purchase) => {
  if (notifyFlag(purchase, 'adminCompleted')) return purchase
  const link = formatPhoneLink(purchase.phone)
  await sendText(sock, adminJid, messages.adminCompleted(purchase, link), false)
  return markNotified(purchase, 'adminCompleted')
}

const handleText = async ({ sock, jid, text, phone }) => {
  const purchase = purchases.findActiveByPhone(phone)
  if (!purchase) return false

  const actions = {
    [STAGES.AWAITING_EMAIL]: () => handleEmailInput({ sock, jid, text, purchase }),
    [STAGES.AWAITING_USERNAME]: () => handleUsernameInput({ sock, jid, text, purchase })
  }
  
  const action = actions[purchase.stage]
  if (!action) return false
  await action()
  return true
}

const processApproved = async (sock, purchase) => {
  if (notifyFlag(purchase, 'userApproved')) return purchase
  
  const updated = purchases.patch(purchase, { 
    status: 'approved', 
    stage: STAGES.AWAITING_USERNAME, 
    paymentStatus: 'approved' 
  })
  
  try {
    await sendText(sock, updated.jid, messages.paymentApproved())
  } catch (err) {
    console.error('[PURCHASE] Erro ao notificar aprovação:', err.message)
  }
  
  return markNotified(updated, 'userApproved')
}

const processExpired = async (sock, purchase) => {
  if (notifyFlag(purchase, 'userExpired')) return purchase
  
  const updated = purchases.patch(purchase, { 
    status: 'expired', 
    stage: STAGES.EXPIRED, 
    paymentStatus: 'expired' 
  })
  
  try {
    await sendText(sock, updated.jid, messages.pixExpired())
  } catch (err) {
    console.error('[PURCHASE] Erro ao notificar expiração:', err.message)
  }
  
  return markNotified(updated, 'userExpired')
}

const processRejected = async (sock, purchase) => {
  if (notifyFlag(purchase, 'userRejected')) return purchase
  
  const updated = purchases.patch(purchase, { 
    status: 'cancelled', 
    stage: STAGES.CANCELLED, 
    paymentStatus: 'rejected' 
  })
  
  try {
    await sendText(sock, updated.jid, messages.paymentRejected())
  } catch (err) {
    console.error('[PURCHASE] Erro ao notificar rejeição:', err.message)
  }
  
  return markNotified(updated, 'userRejected')
}

const notifyAdminRefunded = async (sock, purchase) => {
  if (notifyFlag(purchase, 'adminRefunded')) return purchase
  const link = formatPhoneLink(purchase.phone)
  await sendText(sock, adminJid, messages.adminRefunded(purchase, link), false)
  return markNotified(purchase, 'adminRefunded')
}

const processRefunded = async (sock, purchase, paymentStatus) => {
  if (notifyFlag(purchase, 'userRefunded')) return purchase

  const updated = purchases.patch(purchase, {
    status: 'refunded',
    stage: STAGES.REFUNDED,
    paymentStatus: paymentStatus || 'refunded'
  })

  try {
    await sendText(sock, updated.jid, messages.paymentRefunded())
  } catch (err) {
    console.error('[PURCHASE] Erro ao notificar estorno:', err.message)
  }

  try {
    await notifyAdminRefunded(sock, updated)
  } catch {}

  return markNotified(updated, 'userRefunded')
}

const handlePendingPayment = async (sock, purchase) => {
  const isExpiredByTime = new Date(purchase.expiresAt).getTime() <= Date.now()
  if (isExpiredByTime) return processExpired(sock, purchase)

  try {
    const payment = await mpApi.fetchPayment(purchase.paymentId)
    const status = payment.status
    
    console.log(`[WATCHER] Payment ${purchase.paymentId} status: ${status}`)
    const current = purchases.patch(purchase, { paymentStatus: status, status })

    const statusHandlers = {
      approved: () => processApproved(sock, current),
      rejected: () => processRejected(sock, current),
      cancelled: () => processRejected(sock, current),
      expired: () => processExpired(sock, current),
      refunded: () => processRefunded(sock, current, status),
      charged_back: () => processRefunded(sock, current, status)
    }

    const handler = statusHandlers[status]
    if (!handler) return current
    return handler()
  } catch (err) {
    console.error(`[WATCHER] Erro ao verificar pagamento ${purchase.paymentId}:`, err.message)
    return purchase
  }
}

const checkPendingPayments = async (sock) => {
  const pending = purchases.findPendingPayments()
  if (pending.length > 0) {
    console.log(`[WATCHER] Verificando ${pending.length} pagamento(s) pendente(s)`)
  }
  for (const purchase of pending) {
    await handlePendingPayment(sock, purchase)
  }
}

const startPaymentWatcher = (sock) => {
  setInterval(() => checkPendingPayments(sock).catch(() => {}), 20000)
}

module.exports = {
  STAGES,
  sendPlansMenu,
  handlePlanSelection,
  handleText,
  startPaymentWatcher,
  checkPendingPayments
}

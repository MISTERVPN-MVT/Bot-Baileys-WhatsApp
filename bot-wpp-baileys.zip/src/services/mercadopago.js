const https = require('https')
const config = require('../config')
const { generateUuid } = require('../utils')

const parseJsonSafe = (text) => {
  try {
    return { value: JSON.parse(text), error: null }
  } catch (error) {
    return { value: null, error }
  }
}

const requestJson = ({ method, url, headers, body }) => {
  return new Promise((resolve, reject) => {
    const req = https.request(url, { method, headers }, (res) => {
      let data = ''
      res.on('data', chunk => { data += chunk })
      res.on('end', () => {
        const parsed = parseJsonSafe(data)
        if (parsed.error) {
          const error = new Error(`Resposta invalida: ${data.slice(0, 200)}`)
          error.statusCode = res.statusCode
          return reject(error)
        }
        if (res.statusCode >= 400) {
          const msg = parsed.value?.message || parsed.value?.cause?.[0]?.description || `Status ${res.statusCode}`
          const error = new Error(msg)
          error.statusCode = res.statusCode
          return reject(error)
        }
        resolve(parsed.value || {})
      })
    })
    req.on('error', reject)
    if (body) req.write(body)
    req.end()
  })
}

const createPixPayment = ({ amount, description, email, externalReference, idempotencyKey }) => {
  const expiresAt = new Date(Date.now() + 30 * 60000).toISOString()
  const payload = {
    transaction_amount: amount,
    description,
    payment_method_id: 'pix',
    payer: { email },
    date_of_expiration: expiresAt
  }
  
  if (config.mpWebhookUrl) payload.notification_url = config.mpWebhookUrl
  if (externalReference) payload.external_reference = externalReference

  const key = idempotencyKey || generateUuid()
  const body = JSON.stringify(payload)
  const headers = {
    Authorization: `Bearer ${config.mpAccessToken}`,
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'X-Idempotency-Key': key
  }
  const url = new URL('https://api.mercadopago.com/v1/payments')

  return requestJson({ method: 'POST', url, headers, body }).then(result => ({
    id: result.id,
    status: result.status,
    qrCode: result?.point_of_interaction?.transaction_data?.qr_code || '',
    ticketUrl: result?.point_of_interaction?.transaction_data?.ticket_url || '',
    expiresAt
  }))
}

const getPayment = (paymentId) => {
  const url = new URL(`https://api.mercadopago.com/v1/payments/${paymentId}`)
  const headers = { Authorization: `Bearer ${config.mpAccessToken}` }
  return requestJson({ method: 'GET', url, headers })
}

module.exports = { createPixPayment, getPayment }

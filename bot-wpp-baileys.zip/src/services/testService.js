const crypto = require('crypto')
const { tests } = require('../database')
const { createPanelApi } = require('../utils/api')
const { randomDigits, generateUuid, formatSpDate, formatDuration, formatNumberLink } = require('../utils/helpers')
const { sendText } = require('../utils/messages')
const config = require('../config')
const textTemplateService = require('./textTemplateService')

const panelApi = createPanelApi(config.panelDomain, config.panelToken)

function randomLogin() {
  return `mv${randomDigits(crypto.randomInt(3, 6))}`
}

function buildTestPayload(name) {
  return {
    login: randomLogin(),
    senha: randomDigits(5),
    minutos: config.testMinutes,
    nome: name || 'Teste',
    tipo: config.testType,
    uuid: generateUuid()
  }
}

async function createTest({ sock, jid, name, phone, isAdmin }) {
  const current = isAdmin ? null : tests.latestFor(jid, phone)
  const isActive = current && !tests.isExpired(current)
  
  if (isActive) {
    await sendText(sock, jid, textTemplateService.render(textTemplateService.KEYS.TEST_ACTIVE, {
      '{login}': current.login,
      '{password}': current.senha,
      '{uuid}': current.uuid,
      '{expiresAt}': formatSpDate(current.expiresAt)
    }))
    return null
  }

  if (current && tests.isExpired(current)) {
    await sendText(sock, jid, textTemplateService.render(textTemplateService.KEYS.TEST_EXPIRED))
    return null
  }

  const payload = buildTestPayload(name)
  
  try {
    await panelApi.createTest(payload)
  } catch (error) {
    await sendText(sock, jid, textTemplateService.render(textTemplateService.KEYS.TEST_ERROR, {
      '{error}': error.message
    }))
    return null
  }

  const test = isAdmin ? null : tests.create({ ...payload, jid, phone })
  const expiresAt = test ? test.expiresAt : new Date(Date.now() + payload.minutos * 60000).toISOString()

  await sendText(sock, jid, textTemplateService.render(textTemplateService.KEYS.TEST_CREATED, {
    '{login}': payload.login,
    '{password}': payload.senha,
    '{uuid}': payload.uuid,
    '{duration}': formatDuration(payload.minutos),
    '{expiresAt}': formatSpDate(expiresAt)
  }))
  
  await notifyAdminTestCreated(sock, payload, expiresAt, { jid, name, phone })
  
  return test
}

async function notifyAdminTestCreated(sock, payload, expiresAt, requester) {
  const adminJid = `${config.adminNumber}@s.whatsapp.net`
  const { link } = formatNumberLink(requester.phone || requester.jid)
  
  await sendText(sock, adminJid, textTemplateService.render(textTemplateService.KEYS.TEST_ADMIN_NOTIFY, {
    '{name}': requester.name || 'Não informado',
    '{phone}': requester.phone || '',
    '{phoneLink}': link || 'indisponível',
    '{login}': payload.login,
    '{expiresAt}': formatSpDate(expiresAt)
  }), false)
}

module.exports = { createTest, buildTestPayload }

const { sendButtons } = require('../utils/buttons')
const textTemplateService = require('./textTemplateService')

const FAQ_IDS = {
  MENU: 'faq',
  Q1: 'faq_q1',
  Q2: 'faq_q2',
  Q3: 'faq_q3',
  Q4: 'faq_q4',
  Q5: 'faq_q5'
}

const answerMap = {
  [FAQ_IDS.Q1]: textTemplateService.KEYS.FAQ_Q1,
  [FAQ_IDS.Q2]: textTemplateService.KEYS.FAQ_Q2,
  [FAQ_IDS.Q3]: textTemplateService.KEYS.FAQ_Q3,
  [FAQ_IDS.Q4]: textTemplateService.KEYS.FAQ_Q4,
  [FAQ_IDS.Q5]: textTemplateService.KEYS.FAQ_Q5
}

const buildFaqMenu = () => ({
  text: [
    '❓ *FAQ*',
    '',
    '_Selecione uma pergunta:_'
  ].join('\n'),
  footer: '© MASTER BOT',
  buttons: [
    { id: FAQ_IDS.Q1, text: '📲 APP' },
    { id: FAQ_IDS.Q2, text: '🔄 RENOVAÇÃO' },
    { id: FAQ_IDS.Q3, text: '💳 PAGAMENTO' },
    { id: FAQ_IDS.Q4, text: '📶 CONEXÃO' },
    { id: FAQ_IDS.Q5, text: '✅ ACESSO' },
    { id: 'other_options', text: '◀️ VOLTAR' }
  ]
})

const isFaqButton = (id) => String(id || '').startsWith('faq_')

async function showFaqMenu(sock, jid) {
  await sendButtons(sock, jid, buildFaqMenu())
}

async function handleFaqButton({ sock, jid, buttonId }) {
  if (buttonId === FAQ_IDS.MENU) {
    await showFaqMenu(sock, jid)
    return true
  }

  if (!isFaqButton(buttonId)) return false

  const key = answerMap[buttonId]
  if (!key) return false

  const text = textTemplateService.render(key)
  await sock.sendMessage(jid, { text })
  return true
}

module.exports = { FAQ_IDS, showFaqMenu, handleFaqButton }

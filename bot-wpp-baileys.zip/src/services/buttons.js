const buildInteractiveButtons = (buttons = []) => {
  return buttons.map((b, i) => {
    if (b && b.name && b.buttonParamsJson) return b
    
    if (b && (b.id || b.text)) {
      return {
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
          display_text: b.text || b.displayText || `Button ${i + 1}`,
          id: b.id || `quick_${i + 1}`
        })
      }
    }
    
    if (b && b.buttonId && b.buttonText?.displayText) {
      return {
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
          display_text: b.buttonText.displayText,
          id: b.buttonId
        })
      }
    }
    
    return b
  })
}

const convertToInteractiveMessage = (content) => {
  const buttons = content.interactiveButtons || []
  const nativeButtons = buildInteractiveButtons(buttons)
  
  const body = { text: content.text || '' }
  const footer = content.footer ? { text: content.footer } : undefined
  const header = content.title ? { title: content.title, hasMediaAttachment: false } : undefined
  
  return {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body,
          footer,
          header,
          nativeFlowMessage: {
            buttons: nativeButtons,
            messageParamsJson: ''
          }
        }
      }
    }
  }
}

const getButtonType = (content) => {
  const interactive = content?.interactiveMessage
  if (!interactive) return null
  if (interactive.nativeFlowMessage?.buttons?.length) return 'native_flow'
  return null
}

const getButtonArgs = (content) => {
  const buttonType = getButtonType(content)
  if (buttonType !== 'native_flow') return { tag: 'biz', attrs: {} }
  
  return {
    tag: 'biz',
    attrs: {},
    content: [{
      tag: 'interactive',
      attrs: { type: 'native_flow', v: '1' },
      content: []
    }]
  }
}

const sendInteractiveMessage = async (sock, jid, content, options = {}) => {
  if (!sock) throw new Error('Socket is required')

  let generateWAMessageFromContent, relayMessage, normalizeMessageContent, isJidGroup, generateMessageIDV2
  
  const candidatePkgs = ['baileys', '@whiskeysockets/baileys', '@adiwajshing/baileys']
  let loaded = false
  
  for (const pkg of candidatePkgs) {
    if (loaded) break
    try {
      const mod = require(pkg)
      generateWAMessageFromContent = mod.generateWAMessageFromContent || mod.Utils?.generateWAMessageFromContent
      normalizeMessageContent = mod.normalizeMessageContent || mod.Utils?.normalizeMessageContent
      isJidGroup = mod.isJidGroup || mod.WABinary?.isJidGroup
      generateMessageIDV2 = mod.generateMessageIDV2 || mod.Utils?.generateMessageIDV2 || mod.generateMessageID
      relayMessage = sock.relayMessage
      if (generateWAMessageFromContent && normalizeMessageContent && isJidGroup && relayMessage) loaded = true
    } catch { }
  }
  
  if (!loaded) throw new Error('Missing baileys internals')

  const convertedContent = convertToInteractiveMessage(content)
  const userJid = sock.authState?.creds?.me?.id || sock.user?.id
  
  const fullMsg = generateWAMessageFromContent(jid, convertedContent, {
    logger: sock.logger,
    userJid,
    messageId: generateMessageIDV2(userJid),
    timestamp: new Date(),
    ...options
  })

  const normalizedContent = normalizeMessageContent(fullMsg.message)
  const buttonType = getButtonType(normalizedContent)
  let additionalNodes = [...(options.additionalNodes || [])]
  
  if (buttonType) {
    const buttonsNode = getButtonArgs(normalizedContent)
    const isPrivate = !isJidGroup(jid)
    additionalNodes.push(buttonsNode)
    if (isPrivate) additionalNodes.push({ tag: 'bot', attrs: { biz_bot: '1' } })
  }

  await relayMessage(jid, fullMsg.message, {
    messageId: fullMsg.key.id,
    useCachedGroupMetadata: options.useCachedGroupMetadata,
    additionalAttributes: options.additionalAttributes || {},
    statusJidList: options.statusJidList,
    additionalNodes
  })

  return fullMsg
}

const sendButtons = async (sock, jid, data = {}, options = {}) => {
  const { text = '', footer = '', title, buttons = [] } = data
  const interactiveButtons = buildInteractiveButtons(buttons)
  const payload = { text, footer, interactiveButtons }
  if (title) payload.title = title
  return sendInteractiveMessage(sock, jid, payload, options)
}

module.exports = { sendButtons, sendInteractiveMessage }

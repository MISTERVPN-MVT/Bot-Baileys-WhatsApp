const path = require('path')
const fs = require('fs')
const { execFile } = require('child_process')
const { promisify } = require('util')
const { logs } = require('../database')

const SP_TZ = 'America/Sao_Paulo'
const ROOT_DIR = path.join(__dirname, '..', '..')
const execFileAsync = promisify(execFile)

const safeUnlink = (filePath) => {
  try { fs.unlinkSync(filePath) } catch {}
}

const spParts = (date) => {
  const fmt = new Intl.DateTimeFormat('en-CA', {
    timeZone: SP_TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23'
  })
  const parts = fmt.formatToParts(date).reduce((acc, p) => ({ ...acc, [p.type]: p.value }), {})
  return {
    dateKey: `${parts.year}-${parts.month}-${parts.day}`,
    timeKey: `${parts.hour}${parts.minute}${parts.second}`
  }
}

const zipExcludeArgs = (fileName) => [
  '-q',
  '-r',
  fileName,
  '.',
  '-x',
  'node_modules',
  'node_modules/*',
  'auth',
  'auth/*',
  fileName
]

async function createBackupZip(reason = 'scheduled') {
  const { dateKey, timeKey } = spParts(new Date())
  const fileName = `bot-${dateKey}-${timeKey}.zip`
  const destPath = path.join(ROOT_DIR, fileName)

  safeUnlink(destPath)
  await execFileAsync('zip', zipExcludeArgs(fileName), { cwd: ROOT_DIR })
  logs.add('backup', 'zip_created', { fileName, reason })
  return { destPath, fileName, dateKey, timeKey }
}

async function sendBackupZip({ sock, jid, reason = 'scheduled' }) {
  const created = await createBackupZip(reason)
  try {
    await sock.sendMessage(jid, {
      document: { url: created.destPath },
      mimetype: 'application/zip',
      fileName: created.fileName,
      caption: `💾 Backup do bot — ${created.dateKey} ${created.timeKey}`
    })
    logs.add('backup', 'zip_sent', { fileName: created.fileName, reason })
    return created
  } finally {
    safeUnlink(created.destPath)
  }
}

module.exports = { spParts, createBackupZip, sendBackupZip }

const config = require('../config')
const db = require('../database')
const { panelApi } = require('../services')
const { broadcast: broadcastService } = require('../services')
const { sendAdminText, sendAdminButtons, sendUserText } = require('../services/messaging')
const { delay, randomDigits, generateUuid } = require('../utils')

const ADMIN_JID = `${config.adminNumber}@s.whatsapp.net`
const REMOVE_TEST_DELAY_MS = 2000

const adminState = {
  awaitingInput: null,
  broadcastType: null,
  broadcastMedia: null
}

const BUTTON_IDS = {
  viewSupports: 'admin_view_supports',
  removeAllTests: 'admin_rm_all_tests',
  removeTest: 'admin_rm_test',
  createVip: 'admin_create_vip',
  broadcast: 'admin_broadcast',
  broadcastText: 'admin_broadcast_text',
  broadcastDocument: 'admin_broadcast_document',
  broadcastComplete: 'admin_broadcast_complete'
}

const sendAdminPanel = async (sock) => {
  const lines = [
    '🔐 *Painel Administrativo*',
    '',
    '> Selecione uma opção:'
  ]

  await sendAdminButtons(sock, ADMIN_JID, {
    text: lines.join('\n'),
    footer: 'Author: @vpnmasternet',
    buttons: [
      { id: BUTTON_IDS.viewSupports, text: '📋 Ver suportes' },
      { id: BUTTON_IDS.removeAllTests, text: '🗑️ Rm todos testes' },
      { id: BUTTON_IDS.removeTest, text: '❌ Rm teste' },
      { id: BUTTON_IDS.createVip, text: '👑 Criar VIP' },
      { id: BUTTON_IDS.broadcast, text: '📢 Divulgar' }
    ]
  })
}

const handleViewSupports = async (sock) => {
  const supports = db.supports.findAllOpen()
  
  if (supports.length === 0) {
    await sendAdminText(sock, ADMIN_JID, '📭 Nenhum pedido de suporte em aberto.')
    return
  }

  const buttons = supports.map(s => ({
    id: `support_close_${s.id}`,
    text: `${s.id} - ${s.name || s.phone}`
  }))

  await sendAdminButtons(sock, ADMIN_JID, {
    text: '📋 *Pedidos de suporte em aberto:*',
    footer: 'Author: @vpnmasternet',
    buttons
  })
}

const handleRemoveAllTests = async (sock) => {
  const tests = db.tests.getAll()
  
  if (tests.length === 0) {
    await sendAdminText(sock, ADMIN_JID, '📭 Nenhum teste encontrado.')
    return
  }

  await sendAdminText(sock, ADMIN_JID, `🗑️ Removendo ${tests.length} testes...`)

  let removed = 0
  let failed = 0

  for (const test of tests) {
    try {
      await panelApi.deleteUser(test.login)
      db.tests.remove(test.id)
      
      const jid = test.jid || `${test.phone}@s.whatsapp.net`
      const msg = [
        '❌ *Teste removido!*',
        '',
        '✨ Você pode gerar um novo teste sempre que desejar.',
        '📲 Conte conosco!'
      ].join('\n')
      
      await sendUserText(sock, jid, msg)
      removed++
    } catch {
      failed++
    }

    await delay(REMOVE_TEST_DELAY_MS)
  }

  await sendAdminText(sock, ADMIN_JID, `✅ Removidos: ${removed} | ❌ Falhas: ${failed}`)
}

const handleRemoveTestPrompt = async (sock) => {
  adminState.awaitingInput = 'remove_test'
  await sendAdminText(sock, ADMIN_JID, '📝 Digite o login ou telefone do teste a remover:')
}

const handleRemoveTestInput = async (sock, input) => {
  adminState.awaitingInput = null
  
  const test = db.tests.findByLogin(input) || db.tests.findByPhone(input)?.[0]
  
  if (!test) {
    await sendAdminText(sock, ADMIN_JID, '❌ Teste não encontrado.')
    return
  }

  try {
    await panelApi.deleteUser(test.login)
    db.tests.remove(test.id)

    const jid = test.jid || `${test.phone}@s.whatsapp.net`
    const msg = [
      '❌ *Teste removido!*',
      '',
      '✨ Você pode gerar um novo teste sempre que desejar.',
      '📲 Conte conosco!'
    ].join('\n')

    await sendUserText(sock, jid, msg)
    await sendAdminText(sock, ADMIN_JID, `✅ Teste ${test.login} removido.`)
  } catch (error) {
    await sendAdminText(sock, ADMIN_JID, `❌ Erro: ${error.message}`)
  }
}

const handleCreateVipPrompt = async (sock) => {
  adminState.awaitingInput = 'create_vip'
  await sendAdminText(sock, ADMIN_JID, '👤 Digite o login para o novo VIP:')
}

const handleCreateVipInput = async (sock, login) => {
  adminState.awaitingInput = null
  
  const password = randomDigits(5)
  const uuid = generateUuid()
  const finalLogin = login.toLowerCase().replace(/[^a-z0-9]/g, '')

  try {
    await panelApi.createUser({
      login: finalLogin,
      senha: password,
      dias: 30,
      limite: 1,
      nome: finalLogin,
      tipo: 'xray',
      uuid
    })

    const lines = [
      '✅ *VIP criado com sucesso!*',
      '',
      `👤 Login: ${finalLogin}`,
      `🔑 Senha: ${password}`,
      `🆔 UUID: ${uuid}`
    ]
    await sendAdminText(sock, ADMIN_JID, lines.join('\n'))
  } catch (error) {
    await sendAdminText(sock, ADMIN_JID, `❌ Erro: ${error.message}`)
  }
}

const handleBroadcastMenu = async (sock) => {
  await sendAdminButtons(sock, ADMIN_JID, {
    text: '📢 *Tipo de divulgação:*',
    footer: 'Author: @vpnmasternet',
    buttons: [
      { id: BUTTON_IDS.broadcastText, text: '📝 Somente texto' },
      { id: BUTTON_IDS.broadcastDocument, text: '📎 Somente documento' },
      { id: BUTTON_IDS.broadcastComplete, text: '📦 Completo (mídia + legenda)' }
    ]
  })
}

const handleBroadcastTextPrompt = async (sock) => {
  adminState.awaitingInput = 'broadcast_text'
  adminState.broadcastType = 'text'
  await sendAdminText(sock, ADMIN_JID, '📝 Digite o texto da divulgação:')
}

const handleBroadcastDocumentPrompt = async (sock) => {
  adminState.awaitingInput = 'broadcast_document'
  adminState.broadcastType = 'document'
  await sendAdminText(sock, ADMIN_JID, '📎 Envie a imagem, vídeo ou áudio:')
}

const handleBroadcastCompletePrompt = async (sock) => {
  adminState.awaitingInput = 'broadcast_complete_media'
  adminState.broadcastType = 'complete'
  await sendAdminText(sock, ADMIN_JID, '📎 Primeiro, envie a mídia (imagem/vídeo/áudio):')
}

const handleBroadcastTextInput = async (sock, text) => {
  adminState.awaitingInput = null
  
  const result = await broadcastService.runBroadcast(sock, ADMIN_JID, {
    type: 'text',
    text
  })
  
  await sendAdminText(sock, ADMIN_JID, broadcastService.formatBroadcastResult(result))
}

const handleAdminCommand = async ({ sock, text }) => {
  const cmd = text.toLowerCase().trim()
  if (cmd !== '.admin' && cmd !== '.adm') return false
  await sendAdminPanel(sock)
  return true
}

const handleAdminButton = async ({ sock, button }) => {
  const id = button?.id || ''

  if (id === BUTTON_IDS.viewSupports) {
    await handleViewSupports(sock)
    return true
  }

  if (id === BUTTON_IDS.removeAllTests) {
    await handleRemoveAllTests(sock)
    return true
  }

  if (id === BUTTON_IDS.removeTest) {
    await handleRemoveTestPrompt(sock)
    return true
  }

  if (id === BUTTON_IDS.createVip) {
    await handleCreateVipPrompt(sock)
    return true
  }

  if (id === BUTTON_IDS.broadcast) {
    await handleBroadcastMenu(sock)
    return true
  }

  if (id === BUTTON_IDS.broadcastText) {
    await handleBroadcastTextPrompt(sock)
    return true
  }

  if (id === BUTTON_IDS.broadcastDocument) {
    await handleBroadcastDocumentPrompt(sock)
    return true
  }

  if (id === BUTTON_IDS.broadcastComplete) {
    await handleBroadcastCompletePrompt(sock)
    return true
  }

  return false
}

const handleAdminTextInput = async ({ sock, text }) => {
  if (adminState.awaitingInput === 'remove_test') {
    await handleRemoveTestInput(sock, text)
    return true
  }

  if (adminState.awaitingInput === 'create_vip') {
    await handleCreateVipInput(sock, text)
    return true
  }

  if (adminState.awaitingInput === 'broadcast_text') {
    await handleBroadcastTextInput(sock, text)
    return true
  }

  return false
}

const isAwaitingInput = () => adminState.awaitingInput !== null

module.exports = {
  sendAdminPanel,
  handleAdminCommand,
  handleAdminButton,
  handleAdminTextInput,
  isAwaitingInput,
  BUTTON_IDS
}

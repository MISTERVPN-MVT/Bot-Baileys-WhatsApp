const config = require('../config')
const { sendUserButtons } = require('../services/messaging')
const { hasPurchaseHistory } = require('./renew')

const BUTTON_IDS = {
  createTest: 'create_test',
  buyVip: 'buy_vip',
  support: 'support',
  renewAccess: 'renew_access',
  backMenu: 'back_menu'
}

const GREETING_TRIGGERS = new Set(['oi', 'menu', 'ola'])

const isGreeting = (text) => {
  const normalized = text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim()
  const firstWord = normalized.split(' ')[0]
  return GREETING_TRIGGERS.has(firstWord)
}

const buildMenuButtons = (phone, isAdmin) => {
  const buttons = [
    { id: BUTTON_IDS.createTest, text: '🧪 Criar teste' },
    { id: BUTTON_IDS.buyVip, text: '💎 Comprar' },
    { id: BUTTON_IDS.support, text: '📞 Suporte' }
  ]

  const showRenew = isAdmin || hasPurchaseHistory(phone)
  if (showRenew) {
    buttons.splice(2, 0, { id: BUTTON_IDS.renewAccess, text: '🔄 Renovar Acesso' })
  }

  return buttons
}

const sendMenu = async (sock, jid, name, phone, isAdmin) => {
  const displayName = name || 'usuário'
  const buttons = buildMenuButtons(phone, isAdmin)

  const text = [
    `🚀 *Bem-vindo(a), ${displayName}!*`,
    '',
    '_Este é um bot de atendimento automático._',
    '',
    '> *Clique na opção desejada:*'
  ].join('\n')

  await sendUserButtons(sock, jid, {
    text,
    footer: 'Author: @vpnmasternet',
    buttons
  })
}

module.exports = { sendMenu, isGreeting, BUTTON_IDS }

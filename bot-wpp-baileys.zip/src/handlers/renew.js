const config = require('../config')
const db = require('../database')
const { panelApi } = require('../services')
const { sendUserText, sendUserButtons, sendAdminText } = require('../services/messaging')
const { daysBetween, formatPhoneLink } = require('../utils')

const ADMIN_JID = `${config.adminNumber}@s.whatsapp.net`
const MAX_EXPIRED_DAYS = config.renewMaxDays

const hasPurchaseHistory = (phone) => {
  const purchases = db.purchases.findCompletedByPhone(phone)
  return purchases.length > 0
}

const getLatestCompletedPurchase = (phone) => {
  const purchases = db.purchases.findCompletedByPhone(phone)
  return purchases[0] || null
}

const canRenew = (purchase) => {
  if (!purchase) return false
  if (!purchase.completed_at) return false
  
  const daysSinceCompletion = daysBetween(purchase.completed_at, new Date())
  return daysSinceCompletion <= (purchase.days + MAX_EXPIRED_DAYS)
}

const sendRenewMenu = async (sock, jid, purchase) => {
  const lines = [
    '🔄 *Renovar Acesso*',
    '',
    `👤 Login: ${purchase.login}`,
    `💎 Plano: ${purchase.plan_label}`,
    '',
    '> Clique para renovar:'
  ]
  
  await sendUserButtons(sock, jid, {
    text: lines.join('\n'),
    footer: 'Author: @vpnmasternet',
    buttons: [
      { id: `renew_confirm_${purchase.id}`, text: '✅ Confirmar Renovação' },
      { id: 'back_menu', text: '↩️ Voltar' }
    ]
  })
}

const sendCannotRenewMessage = async (sock, jid) => {
  const lines = [
    '❌ *Não é possível renovar*',
    '',
    `⚠️ Seu login expirou há mais de ${MAX_EXPIRED_DAYS} dias.`,
    '',
    '💎 Adquira um novo plano VIP!'
  ]
  await sendUserText(sock, jid, lines.join('\n'))
}

const sendAdminRenewPrompt = async (sock) => {
  const lines = [
    '🔄 *Renovar Acesso*',
    '',
    '📝 Digite o login que deseja renovar:'
  ]
  await sendAdminText(sock, ADMIN_JID, lines.join('\n'))
}

const processRenewal = async (sock, jid, purchase, isAdmin) => {
  try {
    const plan = db.plans.findById(purchase.plan_id)
    const dias = plan?.days || purchase.days
    const limite = plan?.limit_count || purchase.limit_count

    await panelApi.renewUser({
      login: purchase.login,
      dias,
      limite
    })

    const lines = [
      '✅ *Acesso renovado com sucesso!*',
      '',
      `👤 Login: ${purchase.login}`,
      `📅 Dias: +${dias}`,
      `🔢 Limite: ${limite}`,
      '',
      '✨ Obrigado por renovar!'
    ]
    await sendUserText(sock, jid, lines.join('\n'))

    if (!isAdmin) {
      await notifyAdminRenewal(sock, purchase)
    }

    return true
  } catch (error) {
    await sendUserText(sock, jid, `❌ Erro ao renovar: ${error.message}`)
    return false
  }
}

const notifyAdminRenewal = async (sock, purchase) => {
  const link = formatPhoneLink(purchase.phone)
  const lines = [
    '🔄 *Renovação realizada*',
    '',
    `👤 ${purchase.name || 'Desconhecido'}`,
    `📱 ${link}`,
    `🔑 Login: ${purchase.login}`,
    `💎 Plano: ${purchase.plan_label}`
  ]
  await sendAdminText(sock, ADMIN_JID, lines.join('\n'))
}

const handleRenewButton = async ({ sock, jid, phone, isAdmin }) => {
  if (isAdmin) {
    await sendAdminRenewPrompt(sock)
    return true
  }

  const purchase = getLatestCompletedPurchase(phone)
  
  if (!purchase) {
    await sendUserText(sock, jid, '❌ Você ainda não possui compras.')
    return true
  }

  if (!canRenew(purchase)) {
    await sendCannotRenewMessage(sock, jid)
    return true
  }

  await sendRenewMenu(sock, jid, purchase)
  return true
}

const handleRenewConfirm = async ({ sock, jid, purchaseId, phone, isAdmin }) => {
  const purchase = db.purchases.findById(purchaseId)
  
  if (!purchase) {
    await sendUserText(sock, jid, '❌ Compra não encontrada.')
    return true
  }

  if (!isAdmin && !canRenew(purchase)) {
    await sendCannotRenewMessage(sock, jid)
    return true
  }

  await processRenewal(sock, jid, purchase, isAdmin)
  return true
}

const handleAdminRenewByLogin = async (sock, login) => {
  try {
    const userInfo = await panelApi.getUserInfo(login)
    const user = userInfo?.data?.usuarios?.find(u => u.login === login)
    
    if (!user) {
      await sendAdminText(sock, ADMIN_JID, '❌ Login não encontrado no painel.')
      return false
    }

    await panelApi.renewUser({
      login,
      dias: 30,
      limite: user.limite || 1
    })

    await sendAdminText(sock, ADMIN_JID, `✅ Login ${login} renovado com sucesso!`)
    return true
  } catch (error) {
    await sendAdminText(sock, ADMIN_JID, `❌ Erro ao renovar: ${error.message}`)
    return false
  }
}

module.exports = {
  hasPurchaseHistory,
  getLatestCompletedPurchase,
  canRenew,
  handleRenewButton,
  handleRenewConfirm,
  handleAdminRenewByLogin,
  processRenewal
}

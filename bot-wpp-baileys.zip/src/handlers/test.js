const config = require('../config')
const db = require('../database')
const { panelApi } = require('../services')
const { sendUserText } = require('../services/messaging')
const { randomDigits, generateUuid, formatSpDate, formatDuration, formatPhoneLink } = require('../utils')

const buildTestPayload = (name) => ({
  login: `test${randomDigits(3)}`,
  senha: randomDigits(5),
  minutos: config.testMinutes,
  nome: name || 'Usuario',
  tipo: config.testType,
  uuid: generateUuid()
})

const findLatestTest = (jid, phone) => db.tests.findLatest(jid, phone)

const hasActiveTest = (jid, phone) => {
  const test = findLatestTest(jid, phone)
  if (!test) return false
  return !db.tests.isExpired(test)
}

const hasExpiredTest = (jid, phone) => {
  const test = findLatestTest(jid, phone)
  if (!test) return false
  return db.tests.isExpired(test)
}

const recordTest = (jid, phone, payload) => {
  return db.tests.insert({
    jid,
    phone,
    login: payload.login,
    password: payload.senha,
    uuid: payload.uuid,
    minutes: payload.minutos,
    type: payload.tipo,
    name: payload.nome
  })
}

const sendActiveTestInfo = async (sock, jid, test) => {
  const lines = [
    '⚠️ Você já tem um teste ativo.',
    '',
    `👤 Login: ${test.login}`,
    `🔑 Senha: ${test.password}`,
    `🆔 UUID: ${test.uuid}`,
    `⏰ Expira: ${formatSpDate(test.expires_at)}`
  ]
  await sendUserText(sock, jid, lines.join('\n'))
}

const sendExpiredNotice = async (sock, jid) => {
  const lines = [
    '⏰ Seu teste expirou.',
    '',
    '💎 Adquira um plano VIP para continuar!'
  ]
  await sendUserText(sock, jid, lines.join('\n'))
}

const sendCreationConfirmation = async (sock, jid, payload, test) => {
  const lines = [
    '✅ *Teste criado com sucesso!*',
    '',
    `👤 Login: ${payload.login}`,
    `🔑 Senha: ${payload.senha}`,
    `🆔 UUID: ${payload.uuid}`,
    `📱 Tipo: ${payload.tipo}`,
    `⏱️ Duração: ${formatDuration(payload.minutos)}`,
    `⏰ Expira: ${formatSpDate(test.expires_at)}`,
    '',
    `📲 App: ${require('../services/settingsService').getAppLink()}`
  ]
  await sendUserText(sock, jid, lines.join('\n'))
}

const notifyAdminNewTest = async (sock, payload, test, requester) => {
  const adminJid = `${config.adminNumber}@s.whatsapp.net`
  const link = formatPhoneLink(requester.phone)
  const lines = [
    '🚀 *Novo teste criado*',
    '',
    `👤 Por: ${requester.name || 'Desconhecido'}`,
    `📱 Número: ${link}`,
    `🔑 Login: ${payload.login}`,
    `⏰ Expira: ${formatSpDate(test.expires_at)}`
  ]
  await sock.sendMessage(adminJid, { text: lines.join('\n') })
}

const processTestCreation = async ({ sock, jid, name, phone, isAdmin }) => {
  if (!isAdmin && hasActiveTest(jid, phone)) {
    const test = findLatestTest(jid, phone)
    return sendActiveTestInfo(sock, jid, test)
  }

  if (!isAdmin && hasExpiredTest(jid, phone)) {
    return sendExpiredNotice(sock, jid)
  }

  const payload = buildTestPayload(name)
  
  try {
    await panelApi.createTest(payload)
  } catch (error) {
    await sendUserText(sock, jid, `❌ Falha ao criar teste: ${error.message}`)
    return
  }

  const test = isAdmin ? { expires_at: new Date(Date.now() + payload.minutos * 60000).toISOString() } : recordTest(jid, phone, payload)
  
  await sendCreationConfirmation(sock, jid, payload, test)
  await notifyAdminNewTest(sock, payload, test, { jid, name, phone })
}

module.exports = { processTestCreation, findLatestTest, hasActiveTest, hasExpiredTest }

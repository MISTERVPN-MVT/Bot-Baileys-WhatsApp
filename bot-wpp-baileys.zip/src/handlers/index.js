const test = require('./test')
const purchase = require('./purchase')
const support = require('./support')
const renew = require('./renew')
const admin = require('./admin')
const menu = require('./menu')

module.exports = {
  test,
  purchase,
  support,
  renew,
  admin,
  menu
}

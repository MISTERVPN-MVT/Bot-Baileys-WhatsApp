const config = require('../config')
const db = require('../database')
const { mercadopago, panelApi } = require('../services')
const { sendUserText, sendUserButtons } = require('../services/messaging')
const { randomDigits, generateUuid, formatSpDate, formatTimeOnly, formatMoney, formatPhoneLink } = require('../utils')

const STAGES = {
  awaitingEmail: 'awaiting_email',
  pendingPayment: 'pending_payment',
  awaitingUsername: 'awaiting_username',
  completed: 'completed',
  expired: 'expired',
  cancelled: 'cancelled',
  failed: 'failed'
}

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const USERNAME_PATTERN = /^[a-zA-Z]{3,8}$/
const FALLBACK_EMAIL = 'teste@teste.com'

const validEmail = (value) => EMAIL_PATTERN.test(String(value || '').trim())
const normalizeEmail = (value) => String(value || '').trim().toLowerCase()
const validUsername = (value) => USERNAME_PATTERN.test(value || '')

const buildFallbackUsername = () => `vip${randomDigits(crypto.randomInt(2, 5))}`

const createPurchaseFromPlan = ({ plan, phone, jid, name }) => ({
  id: generateUuid(),
  phone,
  jid,
  name: name || '',
  planId: plan.id,
  planLabel: plan.label,
  amount: plan.amount,
  limit: plan.limit,
  days: plan.days,
  status: 'draft',
  stage: STAGES.awaitingEmail
})

const sendPlansMenu = async (sock, jid, backButtonId) => {
  const plans = db.plans.getAll()
  const buttons = plans.map(plan => ({ id: plan.id, text: plan.label }))
  buttons.push({ id: backButtonId, text: '◀️ Voltar' })
  
  const text = [
    '💎 *PLANOS VIP DISPONÍVEIS*',
    '',
    '> _Escolha o plano ideal para você!_',
    '',
    '🔹 Conexão ilimitada',
    '🔹 Suporte prioritário',
    '🔹 Ativação instantânea',
    '',
    '_Selecione uma opção abaixo:_'
  ].join('\n')
  
  await sendUserButtons(sock, jid, { text, footer: '© MASTER BOT', buttons })
}

const sendEmailRequest = async (sock, jid, purchase) => {
  const lines = [
    `💎 *Plano selecionado:* ${purchase.planLabel}`,
    '',
    '📧 *Digite seu e-mail* para gerar o Pix:',
    '',
    '> _Ou envie qualquer texto para continuar_'
  ]
  await sendUserText(sock, jid, lines.join('\n'))
}

const sendPixMessage = async (sock, jid, purchase) => {
  const lines = [
    '✅ *PIX GERADO COM SUCESSO!*',
    '',
    `> 💰 Valor: *${formatMoney(purchase.amount)}*`,
    `> ⏰ Expira às: *${formatTimeOnly(purchase.expires_at)}*`,
    '',
    '📋 *Copie o código abaixo e pague:*'
  ]
  await sendUserText(sock, jid, lines.join('\n'))
  await sendUserText(sock, jid, purchase.qr_code)
}

const sendApprovedMessage = async (sock, jid) => {
  const lines = [
    '✅ *PAGAMENTO APROVADO!*',
    '',
    '🎉 _Obrigado pela confiança!_',
    '',
    '👤 Digite um *nome de usuário* (3-8 letras):',
    '',
    '> _Ou envie qualquer texto para gerar automaticamente_'
  ]
  await sendUserText(sock, jid, lines.join('\n'))
}

const sendVipCreatedMessage = async (sock, jid, { login, password, uuid }) => {
  const lines = [
    '🎉 *ACESSO VIP CRIADO!*',
    '',
    `> 👤 Login: *${login}*`,
    `> 🔑 Senha: *${password}*`,
    `> 🆔 UUID: \`${uuid}\``,
    '',
    `📲 *Baixe o app:* ${require('../services/settingsService').getAppLink()}`,
    '',
    '✨ _Obrigado pela compra!_',
    '_Qualquer dúvida, estamos à disposição._'
  ]
  await sendUserText(sock, jid, lines.join('\n'))
}

const sendExpiredMessage = async (sock, jid) => {
  await sendUserText(sock, jid, [
    '⏰ *Pagamento expirado*',
    '',
    '> _O tempo para pagamento se esgotou._',
    '',
    '_Inicie uma nova compra pelo menu._'
  ].join('\n'))
}

const sendRejectedMessage = async (sock, jid) => {
  await sendUserText(sock, jid, [
    '❌ *Pagamento não aprovado*',
    '',
    '> _O pagamento foi cancelado ou rejeitado._',
    '',
    '_Tente novamente pelo menu._'
  ].join('\n'))
}

const updatePurchase = (purchase, changes) => {
  return db.purchases.patch(purchase, changes)
}

const notifyAdminStart = async (sock, purchase) => {
  if (purchase.notified_admin_start || purchase.notifiedAdminStart) return purchase
  
  const adminJid = `${config.adminNumber}@s.whatsapp.net`
  const link = formatPhoneLink(purchase.phone)
  const lines = [
    '💳 *Nova compra iniciada*',
    '',
    `👤 ${purchase.name || 'Desconhecido'}`,
    `📱 ${link}`,
    `💎 ${purchase.plan_label || purchase.planLabel}`,
    `💰 ${formatMoney(purchase.amount)}`
  ]
  await sock.sendMessage(adminJid, { text: lines.join('\n') })
  return updatePurchase(purchase, { notifiedAdminStart: 1 })
}

const notifyAdminCompleted = async (sock, purchase) => {
  if (purchase.notified_admin_completed || purchase.notifiedAdminCompleted) return purchase
  
  const adminJid = `${config.adminNumber}@s.whatsapp.net`
  const link = formatPhoneLink(purchase.phone)
  const lines = [
    '✅ *Compra finalizada*',
    '',
    `👤 ${purchase.name || 'Desconhecido'}`,
    `📱 ${link}`,
    `💎 ${purchase.plan_label || purchase.planLabel}`,
    `🔑 Login: ${purchase.login}`
  ]
  await sock.sendMessage(adminJid, { text: lines.join('\n') })
  return updatePurchase(purchase, { notifiedAdminCompleted: 1 })
}

const handlePlanSelection = async ({ sock, jid, planId, name, phone }) => {
  const plan = db.plans.findById(planId)
  if (!plan) return false

  const current = db.purchases.findActiveByPhone(phone)
  if (current) {
    await sendUserText(sock, jid, '⚠️ Você já tem uma compra em andamento.')
    return true
  }

  const purchaseData = createPurchaseFromPlan({ plan, phone, jid, name })
  const purchase = db.purchases.create(purchaseData)
  await sendEmailRequest(sock, jid, purchase)
  return true
}

const handleEmailInput = async ({ sock, jid, text, purchase }) => {
  const normalized = normalizeEmail(text)
  const email = validEmail(normalized) ? normalized : FALLBACK_EMAIL

  try {
    const payment = await mercadopago.createPixPayment({
      amount: purchase.amount,
      description: `Plano ${purchase.plan_label || purchase.planLabel}`,
      email,
      externalReference: purchase.id,
      idempotencyKey: purchase.id
    })

    const updated = updatePurchase(purchase, {
      email,
      paymentId: payment.id,
      paymentStatus: payment.status,
      stage: STAGES.pendingPayment,
      status: payment.status,
      expiresAt: payment.expiresAt,
      qrCode: payment.qrCode,
      ticketUrl: payment.ticketUrl
    })

    await sendPixMessage(sock, jid, updated)
    await notifyAdminStart(sock, updated)
    return updated
  } catch (error) {
    updatePurchase(purchase, {
      stage: STAGES.failed,
      status: 'failed'
    })
    await sendUserText(sock, jid, `❌ Falha ao gerar Pix\nStatus: ${error.statusCode || 'N/A'}\nDetalhe: ${error.message}\n\nTente novamente pelo menu.`)
    return null
  }
}

const handleUsernameInput = async ({ sock, jid, text, purchase }) => {
  const base = String(text || '').trim()
  const isValid = validUsername(base)
  const username = isValid ? base : buildFallbackUsername()
  const suffix = isValid ? randomDigits(2) : ''
  const login = `${username}${suffix}`.toLowerCase()
  const password = randomDigits(5)
  const uuid = generateUuid()

  try {
    await panelApi.createUser({
      login,
      senha: password,
      dias: purchase.days,
      limite: purchase.limit,
      nome: login,
      tipo: 'xray',
      uuid
    })

    const updated = updatePurchase(purchase, {
      stage: STAGES.completed,
      status: 'approved',
      login,
      password,
      uuid,
      completedAt: new Date().toISOString()
    })

    await sendVipCreatedMessage(sock, jid, { login, password, uuid })
    await notifyAdminCompleted(sock, updated)
    return updated
  } catch (error) {
    updatePurchase(purchase, {
      stage: STAGES.failed,
      status: 'failed'
    })
    await sendUserText(sock, jid, `❌ Erro ao criar acesso: ${error.message}\n\nTente novamente pelo menu.`)
    return null
  }
}

const handleText = async ({ sock, jid, text, phone }) => {
  const purchase = db.purchases.findActiveByPhone(phone)
  if (!purchase) return false

  if (purchase.stage === STAGES.awaitingEmail) {
    await handleEmailInput({ sock, jid, text, purchase })
    return true
  }

  if (purchase.stage === STAGES.awaitingUsername) {
    await handleUsernameInput({ sock, jid, text, purchase })
    return true
  }

  return false
}

const handlePendingPayment = async (sock, purchase) => {
  const expiresAt = purchase.expires_at || purchase.expiresAt
  const expired = new Date(expiresAt) <= new Date()
  
  if (expired) {
    const updated = updatePurchase(purchase, { stage: STAGES.expired, status: 'expired' })
    if (!purchase.notified_user_expired && !purchase.notifiedUserExpired) {
      await sendExpiredMessage(sock, purchase.jid)
      updatePurchase(updated, { notifiedUserExpired: 1 })
    }
    return updated
  }

  try {
    const paymentId = purchase.payment_id || purchase.paymentId
    const payment = await mercadopago.getPayment(paymentId)
    
    if (payment.status === 'approved') {
      const updated = updatePurchase(purchase, {
        status: 'approved',
        stage: STAGES.awaitingUsername,
        paymentStatus: 'approved'
      })
      if (!purchase.notified_user_approved && !purchase.notifiedUserApproved) {
        await sendApprovedMessage(sock, purchase.jid)
        updatePurchase(updated, { notifiedUserApproved: 1 })
      }
      return updated
    }

    if (payment.status === 'rejected' || payment.status === 'cancelled') {
      const updated = updatePurchase(purchase, {
        status: payment.status,
        stage: STAGES.cancelled,
        paymentStatus: payment.status
      })
      if (!purchase.notified_user_rejected && !purchase.notifiedUserRejected) {
        await sendRejectedMessage(sock, purchase.jid)
        updatePurchase(updated, { notifiedUserRejected: 1 })
      }
      return updated
    }

    return purchase
  } catch {
    return purchase
  }
}

const checkPendingPayments = async (sock) => {
  const pending = db.purchases.findPendingPayments()
  for (const purchase of pending) {
    await handlePendingPayment(sock, purchase)
  }
}

const startPaymentWatcher = (sock) => {
  setInterval(() => checkPendingPayments(sock).catch(() => {}), 20000)
}

module.exports = {
  sendPlansMenu,
  handlePlanSelection,
  handleText,
  startPaymentWatcher,
  STAGES
}

const config = require('../config')
const db = require('../database')
const { sendUserText, sendAdminText, sendAdminButtons } = require('../services/messaging')

const ADMIN_JID = `${config.adminNumber}@s.whatsapp.net`

const buildUserOpenMessage = () => [
  '📨 *Pedido de suporte enviado!*',
  '',
  '✍️ Deixe sua pergunta/dúvida.',
  '⏳ Em breve será respondido.'
].join('\n')

const buildAdminOpenMessage = (support) => [
  '🆘 *Novo pedido de suporte*',
  '',
  `🆔 ID: ${support.id}`,
  `👤 ${support.name || 'Desconhecido'}`,
  `📱 ${support.phone}`
].join('\n')

const buildUserClosedMessage = () => [
  '✅ Seu pedido de suporte foi encerrado.',
  '',
  '📲 Conte conosco!'
].join('\n')

const requestSupport = async ({ sock, jid, phone, name }) => {
  const support = db.supports.insert({ phone, jid, name })
  if (!support) {
    await sendUserText(sock, jid, '⚠️ Você já tem um pedido de suporte em aberto.')
    return null
  }
  
  await sendUserText(sock, jid, buildUserOpenMessage())
  await sendAdminText(sock, ADMIN_JID, buildAdminOpenMessage(support))
  return support
}

const listOpenSupports = async (sock) => {
  const open = db.supports.findAllOpen()
  
  if (open.length === 0) {
    await sendAdminText(sock, ADMIN_JID, '📭 Nenhum pedido de suporte em aberto.')
    return []
  }

  const buttons = open.map(s => ({
    id: `support_close_${s.id}`,
    text: `${s.id} - ${s.name || s.phone}`
  }))

  await sendAdminButtons(sock, ADMIN_JID, {
    text: '📋 *Pedidos de suporte em aberto:*',
    footer: 'Author: @vpnmasternet',
    buttons
  })

  return open
}

const closeSupport = async (sock, supportId) => {
  const closed = db.supports.close(supportId)
  
  if (!closed) {
    await sendAdminText(sock, ADMIN_JID, '❌ Pedido de suporte não encontrado.')
    return null
  }

  await sendAdminText(sock, ADMIN_JID, `✅ Pedido ${supportId} encerrado.`)
  await sendUserText(sock, closed.jid, buildUserClosedMessage())
  return closed
}

const handleAdminCommand = async ({ sock, text }) => {
  if (text !== '.sup') return false
  await listOpenSupports(sock)
  return true
}

const handleAdminButton = async ({ sock, button }) => {
  const id = button?.id || ''
  const prefix = 'support_close_'
  if (!id.startsWith(prefix)) return false
  
  const supportId = id.slice(prefix.length)
  await closeSupport(sock, supportId)
  return true
}

const hasOpenSupport = (phone) => db.supports.hasOpen(phone)

module.exports = {
  requestSupport,
  listOpenSupports,
  closeSupport,
  handleAdminCommand,
  handleAdminButton,
  hasOpenSupport
}
